<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Resultat extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',       // Ajoutez user_id ici
        'examen_id',
        'score',
        'status',
        'total_time',
        'created_at',
        'updated_at',
        'total_questions'
    ];

    
}
