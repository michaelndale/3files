<?php

namespace App\Http\Controllers;

use App\Models\Classe;
use App\Models\Faculte;
use Illuminate\Http\Request;

class Clases extends Controller
{
    public function  liste(string $id)
    {
     $allClasse = Faculte::join('classes', 'facultes.id', 'classes.faculte_id')
                    ->select('classes.*' , 'classes.id as classId')
                    ->where('classes.faculte_id', $id)
                    ->get();

    $faculte =  Faculte::find($id);   //

     return view('Backend.Classes.index',compact('allClasse', 'faculte'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
      return view('Backend.Classes.nouveau');  //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $Classe = new Classe();
        $Classe->libelle =$request->libelle;
        $Classe->faculte_id =$request->faculteid;
        $Classe->save();//
             return redirect()->back()->with('success','Classe creer avec succes');

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
     $oneClasse = Classe::find($id); 
     return view('Backend.Classes.voir',compact('oneClasse'));  //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $oneClasse =Classe::find($id);  //
        return view('Backend.Classes.modifier',compact('oneClasse'));  //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
     $Classe = Classe::findOrFail($id);
     $Classe->libelle =$request->libelle;
     $Classe->Update();//
    return redirect()->route('classe')->with('success','classe modifier avec succes');//
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $Classe = Classe::find($id);
        $Classe->delete();
        return redirect()->route('classe')->with('success','Classe suprimer avec succes'); //
    }


    // 

    
}
