<?php

namespace App\Http\Controllers;

use App\Models\Bibliotheque;
use App\Models\cours;
use App\Models\Etudiants;
use App\Models\Faculte;
use App\Models\Payement;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

abstract class Controller
{
    
    public function index()
    {
    
    $faculte = Faculte::all();

    $cours = cours::all();
    
    $bibliotheque= Bibliotheque::all();
    
    $User = User::join('etudiants', 'etudiants.user_id','users.id')->select('etudiants.*','users.*')->get();
     
    $utilisateursLimites = User::join('etudiants', 'etudiants.user_id','users.id')
                            ->select('etudiants.*','users.*')->orderBy('etudiants.created_at', 'desc')->limit(5)->get();

    $payement = Payement::join('etudiants', 'etudiants.user_id', '=', 'payements.user_id')
     ->select('payements.*', 'etudiants.nom', 'etudiants.prenom')->orderBy('payements.id', 'desc')->limit(5)->get();

     return view('Backend.Home.index',compact('User','faculte','cours', 'bibliotheque','utilisateursLimites', 'payement'));
    }
}
