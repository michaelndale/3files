<?php

namespace App\Http\Controllers;

use App\Models\Bibliotheque;
use App\Models\Blog;
use App\Models\cours;
use App\Models\Etudiants;
use App\Models\Faculte;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\ContactMessage;

class Accueil extends Controller
{

    public function sendMessage(Request $request)
    {
        // Validation des données
        $validated = $request->validate([
            'contact-name' => 'required|string|max:255',
            'contact-email' => 'required|email|max:255',
            'contact-message' => 'required|string|max:1000',
        ]);

        // Si la validation échoue, retour à la page avec un message d'erreur

        // Envoi de l'email
        Mail::to('votreemail@example.com')->send(new ContactMessage($request));

        // Retourner une réponse JSON pour AJAX
        return response()->json([
            'success' => true,
            'message' => 'Votre message a été envoyé avec succès !'
        ]);
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // Récupère toutes les données de la table 'bibliotheques'
        $bibliotheque = Bibliotheque::orderBy('id', 'desc')->where('status','=','public')->take(3)->get();
        $blog = Blog::orderBy('id', 'desc')->take(3)->get();
        $etudiant = Etudiants::all();
        $facultes = Faculte::all();
        $title_ = $active ="Accueil";

        // Retourne la vue 'acceuil' avec les données compactées
        return view('acceuil', compact('bibliotheque','blog', 'etudiant', 'facultes','active','title_'));
    }


    public function appropos()
    {
        
        $title_ = $active="A-propos";
        // Retourne la vue 'acceuil' avec les données compactées
        return view('Frontend.appropo.index', compact('active','title_'));
    }


    public function bibliot()
    {
        $title_ =  $active="Bibliotheque";
        // Récupère toutes les données de la table 'bibliotheques'
        $bibliotheque = Bibliotheque::orderBy('id', 'desc')->take(3)->get();
    
        // Retourne la vue 'acceuil' avec les données compactées
        return view('Frontend.bibliotheque.index', compact('bibliotheque','active','title_'));
    }

    public function cours_pup()
    {
        $title_ =  $active = 'Cours';
        // Récupère toutes les données de la table 'bibliotheques'
        $cours = cours::orderBy('id', 'desc')->get();
        // Retourne la vue 'acceuil' avec les données compactées
        return view('Frontend.cours.index', compact('cours','active','title_'));
    }

    public function blogs()
    {
        // Récupère toutes les données de la table 'bibliotheques'
        $title_ =  $active = 'Blog';
        $blog = Blog::orderBy('id', 'desc')->get();
        // Retourne la vue 'acceuil' avec les données compactées
        return view('Frontend.blog.index', compact('blog','active','title_'));
    }

    public function showblog(string $id)
    {
        $active = 'Blog';
        $blog = Blog::findOrFail($id);
        $title_ = $blog->titre;
        return view('Frontend.blog.voir',compact('blog','active','title_'));  //
    }

    public function contacts()
    {
        // Récupère toutes les données de la table 'bibliotheques'
        $title_= $active = 'Contact';

        // Retourne la vue 'acceuil' avec les données compactées
        return view('Frontend.contact.index', compact('active', 'title_'));
    }


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
