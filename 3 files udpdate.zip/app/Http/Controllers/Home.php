<?php

namespace App\Http\Controllers;

use App\Models\Bibliotheque;
use App\Models\cours;
use App\Models\Etudiants;
use App\Models\examen;
use App\Models\Facturations;
use App\Models\Facultecours;
use App\Models\ModuleCours;
use App\Models\Payement;
use App\Models\Question;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class Home extends Controller
{
    public function bienvenue()
    {

        $examens = examen::where('status', 'ACTIF')->get();
        $bibliotheque = Bibliotheque::where('status', 'public')->get();
        
        $active = "bienvenu";

        $me = Etudiants::join('users', 'etudiants.user_id', 'users.id')
            ->join('transite_faculte_etudiants', 'etudiants.user_id', 'transite_faculte_etudiants.users_id')
            ->join('facultes', 'transite_faculte_etudiants.faculte_id', 'facultes.id')
            ->join('annees', 'transite_faculte_etudiants.annescolaire_id', 'annees.id')
            ->join('classes', 'transite_faculte_etudiants.classe_id', 'classes.id')
            ->select(
                'etudiants.*',
                'etudiants.id as ide',
                'users.id as idu',
                'users.email',
                'users.code',
                'users.status',
                'facultes.libelle as titre_faculte',
                'facultes.id as id_faculte',
                'annees.libelle as libelleannee',
                'annees.id as annen_id',
                'classes.libelle as libelle_classe'
            )
            ->where('users.id', Auth::id())
            ->first();

        $faculteID = $me->id_faculte;
        $anneID = $me->annen_id;
        
    

        $cours = Facultecours::join('cours', 'facultecours.cours_id', 'cours.id')
            ->join('annees', 'facultecours.annescolaire_id', 'annees.id')
            ->select('facultecours.id as idf', 'cours.titre as titre_cours', 'cours.description as description_cours', 'cours.volume as volume_cours', 'annees.libelle as libelle_annee')
            ->where('facultecours.faculte_id', $faculteID)
            ->where('facultecours.annescolaire_id', $anneID)
            ->where('status', 'ACTIF')
            ->get();

        // progression profile

        // Récupérer l'utilisateur connecté
        $user = Auth::user();

        // Récupérer les informations de l'étudiant à partir de l'`user_id`
        $etudiant = DB::table('etudiants')->where('user_id', $user->id)->first();

        // Définir les champs de l'utilisateur
        $userFields = [
            'prenom' => $user->prenom,
            'email' => $user->email,
            'photo' => $user->photo,
            'code' => $user->code,
            'password' => $user->password,
        ];

        // Définir les champs de l'étudiant
        $etudiantFields = [
            'nom' => $etudiant->nom ?? null,
            'prenom' => $etudiant->prenom ?? null,
            'sexe' => $etudiant->sexe ?? null,
            'dateNais' => $etudiant->dateNais ?? null,
            'adresse' => $etudiant->adresse ?? null,
            'nationalite' => $etudiant->nationalite ?? null,
            'tel' => $etudiant->tel ?? null,
            'piece' => $etudiant->piece ?? null,
            'diplomeDetat' => $etudiant->diplomeDetat ?? null,
            'cv' => $etudiant->cv ?? null,
            'lettre' => $etudiant->lettre ?? null,
            'dateEnregitre' => $etudiant->dateEnregitre ?? null,
        ];

        // Compter le nombre de champs dans les deux tables
        $totalFields = count($userFields) + count($etudiantFields);

        // Compter le nombre de champs remplis
        $filledFields = count(array_filter($userFields)) + count(array_filter($etudiantFields));

        // Calculer le pourcentage de complétion
        $completionPercentage = ($filledFields / $totalFields) * 100;

        //fin

        $check_payement = Facturations::where('annee_id', $anneID)->get();

        $VerificationPayement = Payement::where('user_id', $me->idu)->get();

        $libellesCheck = $check_payement->pluck('libelle');
        $libellesVerification = $VerificationPayement->pluck('type_payement');
        
        
        // Trouver les éléments qui sont dans $check_payement mais pas dans $VerificationPayement
        $nonCorrespondants = $check_payement->filter(function ($item) use ($libellesVerification) {
            return !$libellesVerification->contains($item->libelle);
        });
        
       // Filtrer les éléments où la date de la colonne "periode" est strictement passée (avant aujourd'hui)
        $nonCorrespondantsDepasses = $nonCorrespondants->filter(function ($item) {
            return isset($item->periode) && Carbon::parse($item->periode)->isBefore(Carbon::today());
        });

        


        return view('Frontend.etudiant.bienvenu', 
        compact('me', 'cours', 'examens', 'bibliotheque', 
        'completionPercentage', 'user', 'etudiant', 'active',
        'check_payement','VerificationPayement',
        'libellesCheck', 'libellesVerification','nonCorrespondants','nonCorrespondantsDepasses'));
    }

    public function profile()
    {
        $me = Etudiants::join('users', 'etudiants.user_id', 'users.id')
            ->join('transite_faculte_etudiants', 'etudiants.user_id', 'transite_faculte_etudiants.users_id')
            ->join('facultes', 'transite_faculte_etudiants.faculte_id', 'facultes.id')
            ->join('annees', 'transite_faculte_etudiants.annescolaire_id', 'annees.id')
            ->join('classes', 'transite_faculte_etudiants.classe_id', 'classes.id')
            ->select(
                'etudiants.*',
                'etudiants.id as ide',
                'users.id as idu',
                'users.email',
                'users.code',
                'users.status',
                'facultes.libelle as titre_faculte',
                'facultes.id as id_faculte',
                'annees.libelle as libelleannee',
                'annees.id as annen_id',
                'classes.libelle as libelle_classe'
            )
            ->where('users.id', Auth::id())
            ->first();

        $faculteID = $me->id_faculte;
        $anneID = $me->annen_id;

        $cours = Facultecours::join('cours', 'facultecours.cours_id', 'cours.id')
            ->join('annees', 'facultecours.annescolaire_id', 'annees.id')
            ->select('facultecours.id as idf', 'cours.titre as titre_cours', 'cours.description as description_cours', 'cours.volume as volume_cours', 'annees.libelle as libelle_annee')
            ->where('facultecours.faculte_id', $faculteID)
            ->where('facultecours.annescolaire_id', $anneID)
            ->get();


        // progression profile

        // Récupérer l'utilisateur connecté
        $user = Auth::user();

        // Récupérer les informations de l'étudiant à partir de l'`user_id`
        $etudiant = DB::table('etudiants')->where('user_id', $user->id)->first();

        // Définir les champs de l'utilisateur
        $userFields = [
            'prenom' => $user->prenom,
            'email' => $user->email,
            'photo' => $user->photo,
            'code' => $user->code,
            'password' => $user->password,
        ];

        // Définir les champs de l'étudiant
        $etudiantFields = [
            'nom' => $etudiant->nom ?? null,
            'prenom' => $etudiant->prenom ?? null,
            'sexe' => $etudiant->sexe ?? null,
            'dateNais' => $etudiant->dateNais ?? null,
            'adresse' => $etudiant->adresse ?? null,
            'nationalite' => $etudiant->nationalite ?? null,
            'tel' => $etudiant->tel ?? null,
            'piece' => $etudiant->piece ?? null,
            'diplomeDetat' => $etudiant->diplomeDetat ?? null,
            'cv' => $etudiant->cv ?? null,
            'lettre' => $etudiant->lettre ?? null,
            'dateEnregitre' => $etudiant->dateEnregitre ?? null,
        ];

        // Compter le nombre de champs dans les deux tables
        $totalFields = count($userFields) + count($etudiantFields);

        // Compter le nombre de champs remplis
        $filledFields = count(array_filter($userFields)) + count(array_filter($etudiantFields));

        // Calculer le pourcentage de complétion
        $completionPercentage = ($filledFields / $totalFields) * 100;

        $active = "profil";

        $anneID = $me->annen_id;

        $check_payement = Facturations::where('annee_id', $anneID)->get();

        $VerificationPayement = Payement::where('user_id', $me->idu)->get();
        $libellesCheck = $check_payement->pluck('libelle');
        $libellesVerification = $VerificationPayement->pluck('type_payement');
        
        // Trouver les éléments qui sont dans $check_payement mais pas dans $VerificationPayement
        $nonCorrespondants = $check_payement->filter(function ($item) use ($libellesVerification) {
            return !$libellesVerification->contains($item->libelle);
        });
        
       // Filtrer les éléments où la date de la colonne "periode" est strictement passée (avant aujourd'hui)
        $nonCorrespondantsDepasses = $nonCorrespondants->filter(function ($item) {
            return isset($item->periode) && Carbon::parse($item->periode)->isBefore(Carbon::today());
        });

        return view('Frontend.etudiant.profile', compact('me', 'completionPercentage', 'user', 'etudiant', 'active',
        'check_payement','VerificationPayement',
        'libellesCheck', 'libellesVerification','nonCorrespondants','nonCorrespondantsDepasses'));
    }

    public function cours()
    {
        $me = Etudiants::join('users', 'etudiants.user_id', 'users.id')
            ->join('transite_faculte_etudiants', 'etudiants.user_id', 'transite_faculte_etudiants.users_id')
            ->join('facultes', 'transite_faculte_etudiants.faculte_id', 'facultes.id')
            ->join('annees', 'transite_faculte_etudiants.annescolaire_id', 'annees.id')
            ->join('classes', 'transite_faculte_etudiants.classe_id', 'classes.id')
            ->select('etudiants.*', 'etudiants.id as ide', 'users.id as idu', 'facultes.id as idfac', 'annees.id as idannee', 'classes.id as idclass')
            ->where('users.id', Auth::id())
            ->first();

        $active = "Cours";

        $coursetuadiant = Facultecours::join('cours', 'cours.id', 'facultecours.cours_id')
            ->join('facultes', 'facultes.id', 'facultecours.faculte_id')
            ->join('annees', 'annees.id', 'facultecours.annescolaire_id')
            ->join('classes', 'classes.id', 'facultecours.classe_id')
            ->select('cours.*')
            ->where('facultes.id', $me->idfac)
            ->where('classes.id',  $me->idclass)
            ->where('annees.id', $me->idannee)
            ->where('cours.status', 'ACTIF')
            ->get();

            $anneID = $me->annen_id;

            $check_payement = Facturations::where('annee_id', $anneID)->get();

            $VerificationPayement = Payement::where('user_id', $me->idu)->get();    
            $libellesCheck = $check_payement->pluck('libelle');
            $libellesVerification = $VerificationPayement->pluck('type_payement');
            
            // Trouver les éléments qui sont dans $check_payement mais pas dans $VerificationPayement
            $nonCorrespondants = $check_payement->filter(function ($item) use ($libellesVerification) {
                return !$libellesVerification->contains($item->libelle);
            });
            
           // Filtrer les éléments où la date de la colonne "periode" est strictement passée (avant aujourd'hui)
            $nonCorrespondantsDepasses = $nonCorrespondants->filter(function ($item) {
                return isset($item->periode) && Carbon::parse($item->periode)->isBefore(Carbon::today());
            });



        return view('Frontend.etudiant.cours', compact('me', 'coursetuadiant', 'active', 'check_payement','VerificationPayement',
        'libellesCheck', 'libellesVerification','nonCorrespondants','nonCorrespondantsDepasses'));
    }

    public function contenucours(string $slug)
    {
        $me = Etudiants::join('users', 'etudiants.user_id', 'users.id')
            ->select('etudiants.*', 'users.email', 'users.code', 'users.status')
            ->where('users.id', Auth::id())
            ->first();

        $cours = Cours::where('slug', $slug)->first();


        $allmodule = ModuleCours::join('users', 'module_cours.user_id', 'users.id')
            ->where('cours_id', '=', $cours->id)
            ->select('module_cours.*',  'users.prenom as prenomUser',  'users.email as emailUser')
            ->get();

        $cours = cours::find($cours->id);  //

        $active = 'Cours';

        $anneID = $me->annen_id;

        $check_payement = Facturations::where('annee_id', $anneID)->get();

        $VerificationPayement = Payement::where('user_id', $me->idu)->get();

        $libellesCheck = $check_payement->pluck('libelle');
        $libellesVerification = $VerificationPayement->pluck('type_payement');
        
        
        // Trouver les éléments qui sont dans $check_payement mais pas dans $VerificationPayement
        $nonCorrespondants = $check_payement->filter(function ($item) use ($libellesVerification) {
            return !$libellesVerification->contains($item->libelle);
        });
        
       // Filtrer les éléments où la date de la colonne "periode" est strictement passée (avant aujourd'hui)
        $nonCorrespondantsDepasses = $nonCorrespondants->filter(function ($item) {
            return isset($item->periode) && Carbon::parse($item->periode)->isBefore(Carbon::today());
        });


        return view('Frontend.etudiant.contenucours', compact('cours', 'allmodule', 'me', 'active', 'check_payement','VerificationPayement',
        'libellesCheck', 'libellesVerification','nonCorrespondants','nonCorrespondantsDepasses'));  //
    }

    public function payement()
    {

        $me = Etudiants::join('users', 'etudiants.user_id', 'users.id')
            ->join('transite_faculte_etudiants', 'etudiants.user_id', 'transite_faculte_etudiants.users_id')
            ->join('facultes', 'transite_faculte_etudiants.faculte_id', 'facultes.id')
            ->join('annees', 'transite_faculte_etudiants.annescolaire_id', 'annees.id')
            ->join('classes', 'transite_faculte_etudiants.classe_id', 'classes.id')
            ->select(
                'etudiants.*',
                'etudiants.id as ide',
                'users.id as idu',
                'users.email',
                'users.code',
                'users.status',
                'facultes.libelle as titre_faculte',
                'facultes.id as id_faculte',
                'annees.libelle as libelleannee',
                'annees.id as annee_id',
                'classes.libelle as libelle_classe',
                'classes.id as classe_id'
            )
            ->where('users.id', Auth::id())
            ->first();
        $Facturation = Facturations::all();
        $payments = Payement::where('user_id', Auth::id())->get();
        
        $active = 'payement';


        $anneID = $me->annee_id;

        $check_payement = Facturations::where('annee_id', $anneID)->get();

        $VerificationPayement = Payement::where('user_id', $me->idu)->get();

        $libellesCheck = $check_payement->pluck('libelle');
        $libellesVerification = $VerificationPayement->pluck('type_payement');
        
        
        // Trouver les éléments qui sont dans $check_payement mais pas dans $VerificationPayement
        $nonCorrespondants = $check_payement->filter(function ($item) use ($libellesVerification) {
            return !$libellesVerification->contains($item->libelle);
        });
        
       // Filtrer les éléments où la date de la colonne "periode" est strictement passée (avant aujourd'hui)
        $nonCorrespondantsDepasses = $nonCorrespondants->filter(function ($item) {
            return isset($item->periode) && Carbon::parse($item->periode)->isBefore(Carbon::today());
        });

        return view('Frontend.etudiant.payement', compact('me', 'Facturation', 'payments', 'active', 'check_payement','VerificationPayement',
        'libellesCheck', 'libellesVerification','nonCorrespondants','nonCorrespondantsDepasses'));
    }

    public function examens()
    {
        $me = Etudiants::join('users', 'etudiants.user_id', 'users.id')
            ->join('transite_faculte_etudiants', 'etudiants.user_id', 'transite_faculte_etudiants.users_id')
            ->join('facultes', 'transite_faculte_etudiants.faculte_id', 'facultes.id')
            ->join('annees', 'transite_faculte_etudiants.annescolaire_id', 'annees.id')
            ->join('classes', 'transite_faculte_etudiants.classe_id', 'classes.id')
            ->select('etudiants.*', 'etudiants.id as ide', 'users.id as idu', 'facultes.id as idfac', 'annees.id as idannee', 'classes.id as idclass')
            ->where('users.id', Auth::id())
            ->first();

        $examen = examen::join('cours', 'examens.cours_id', 'cours.id')
            ->join('facultecours', 'cours.id', 'facultecours.cours_id')
            ->join('annees', 'annees.id', 'facultecours.annescolaire_id')
            ->select('examens.*', 'cours.titre as titre_cours')
            ->where('annees.id', $me->idannee)
            ->where('examens.status', '=', 'ACTIF')
            ->distinct()
            ->get();

        $active = "Examens";


        $anneID = $me->idannee;

        $check_payement = Facturations::where('annee_id', $anneID)->get();

        $VerificationPayement = Payement::where('user_id', $me->idu)->get();
        $libellesCheck = $check_payement->pluck('libelle');
        $libellesVerification = $VerificationPayement->pluck('type_payement');
        
        // Trouver les éléments qui sont dans $check_payement mais pas dans $VerificationPayement
        $nonCorrespondants = $check_payement->filter(function ($item) use ($libellesVerification) {
            return !$libellesVerification->contains($item->libelle);
        });
        
       // Filtrer les éléments où la date de la colonne "periode" est strictement passée (avant aujourd'hui)
        $nonCorrespondantsDepasses = $nonCorrespondants->filter(function ($item) {
            return isset($item->periode) && Carbon::parse($item->periode)->isBefore(Carbon::today());
        });


        return view('Frontend.etudiant.examen', compact('me', 'examen', 'active', 'check_payement','VerificationPayement',
        'libellesCheck', 'libellesVerification','nonCorrespondants','nonCorrespondantsDepasses'));
    }

    public function bibliotheque()
    {
        $me = Etudiants::join('users', 'etudiants.user_id', 'users.id')
            ->select('etudiants.*', 'users.email', 'users.code', 'users.status')
            ->where('users.id', Auth::id())
            ->first();
        $allBibliotheque  = DB::table('bibliotheques')
            ->join('etudiants', 'bibliotheques.etudiant_id', 'etudiants.id')
            ->select('etudiants.nom', 'etudiants.prenom', 'bibliotheques.*')
            ->where('status', '=', 'public')
            ->get();

        $active = "bibliotheque";

        $anneID = $me->annen_id;

        $check_payement = Facturations::where('annee_id', $anneID)->get();

        $VerificationPayement = Payement::where('user_id', $me->idu)->get();

        $libellesCheck = $check_payement->pluck('libelle');
        $libellesVerification = $VerificationPayement->pluck('type_payement');
        
        
        // Trouver les éléments qui sont dans $check_payement mais pas dans $VerificationPayement
        $nonCorrespondants = $check_payement->filter(function ($item) use ($libellesVerification) {
            return !$libellesVerification->contains($item->libelle);
        });
        
       // Filtrer les éléments où la date de la colonne "periode" est strictement passée (avant aujourd'hui)
        $nonCorrespondantsDepasses = $nonCorrespondants->filter(function ($item) {
            return isset($item->periode) && Carbon::parse($item->periode)->isBefore(Carbon::today());
        });

        

        return view('Frontend.etudiant.bibliotheque', compact('me', 'allBibliotheque', 'active', 'check_payement','VerificationPayement',
        'libellesCheck', 'libellesVerification','nonCorrespondants','nonCorrespondantsDepasses'));
    }

    public function nouveaubibliothequeetudiant()
    {
        $me = Etudiants::join('users', 'etudiants.user_id', 'users.id')
            ->select('etudiants.*', 'etudiants.id as ide', 'users.email', 'users.code', 'users.status')
            ->where('users.id', Auth::id())
            ->first();

        $active = "nouveau bibliotheque";

        $anneID = $me->annen_id;

        $check_payement = Facturations::where('annee_id', $anneID)->get();

        $VerificationPayement = Payement::where('user_id', $me->idu)->get();
        $libellesCheck = $check_payement->pluck('libelle');
        $libellesVerification = $VerificationPayement->pluck('type_payement');
        
        // Trouver les éléments qui sont dans $check_payement mais pas dans $VerificationPayement
        $nonCorrespondants = $check_payement->filter(function ($item) use ($libellesVerification) {
            return !$libellesVerification->contains($item->libelle);
        });
        
       // Filtrer les éléments où la date de la colonne "periode" est strictement passée (avant aujourd'hui)
        $nonCorrespondantsDepasses = $nonCorrespondants->filter(function ($item) {
            return isset($item->periode) && Carbon::parse($item->periode)->isBefore(Carbon::today());
        });

        return view('Frontend.etudiant.bibliothequenouveau', compact('me', 'active', 'check_payement','VerificationPayement',
        'libellesCheck', 'libellesVerification','nonCorrespondants','nonCorrespondantsDepasses'));
    }
}
