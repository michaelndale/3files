<?php

namespace App\Http\Controllers;

use App\Models\Bibliotheque;
use App\Models\Etudiants;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class BibliothequeController extends Controller
{ public function index()
    {
     $allBibliotheque  = DB::table('bibliotheques')
     ->join('etudiants', 'bibliotheques.etudiant_id', 'etudiants.id')
     ->select('etudiants.nom', 'etudiants.prenom', 'bibliotheques.*')
     ->get();
     return view('Backend.Bibliotheques.index',compact('allBibliotheque'));
    }

    public function liste()
    {
     $allBibliotheque  = DB::table('bibliotheques')
     ->join('etudiants', 'bibliotheques.etudiant_id', 'etudiants.id')
     ->select('etudiants.nom', 'etudiants.prenom', 'bibliotheques.*')
     ->get();
     return view('Backend.Bibliotheques.index',compact('allBibliotheque'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
      $allEtudiant = Etudiants::all();
      return view('Backend.Bibliotheques.nouveau',compact('allEtudiant'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

    $imageName=time().'.'.$request->photo->extension();
    $request->photo->move(public_path('images/bibliotheque/'),$imageName);
    $UrlImage="images/bibliotheque/".$imageName;

    $docName=time().'.'.$request->doc->extension();
    $request->doc->move(public_path('document/bibliotheque/'),$docName);
    $UrlDoc="document/bibliotheque/".$docName;

     $biblio = new Bibliotheque ();
     $biblio->titre =$request->titre;
     $biblio->slug = Str::slug($request->titre,"-");
     $biblio->description = $request->description;
     $biblio->photo =  $UrlImage;
     $biblio->document =  $UrlDoc;
     $biblio->etudiant_id = $request->etudiant_id;
     $biblio->save();//
    

    return redirect()->back()->with('success','Bibliotheque '.$request->titre.' creer avec succes');
    }


    public function storeprive(Request $request)
    {

    $imageName=time().'.'.$request->photo->extension();
    $request->photo->move(public_path('images/bibliotheque/'),$imageName);
    $UrlImage="images/bibliotheque/".$imageName;

    $docName=time().'.'.$request->doc->extension();
    $request->doc->move(public_path('document/bibliotheque/'),$docName);
    $UrlDoc="document/bibliotheque/".$docName;



     $biblio = new Bibliotheque ();
     $biblio->titre =$request->titre;
     $biblio->slug = Str::slug($request->titre,"-");
     $biblio->description = $request->description;
     $biblio->photo =  $UrlImage;
     $biblio->document =  $UrlDoc;
     $biblio->status =  'prive';
     $biblio->etudiant_id = $request->etudiant_id;
     $biblio->save();//
    

    return redirect()->back()->with('success','Bibliotheque '.$request->titre.' creer avec succes');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
     $biblio = Bibliotheque ::findOrFail($id);   //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $biblio = Bibliotheque ::findOrFail($id);
        return view('Backend.Bibliotheque s.modifier',compact('Bibliotheque '));  //
    }

     public function update(Request $request, string $id)
    {
        $biblio = Bibliotheque ::findOrFail($id);
        $biblio->titre =$request->titre;
        $biblio->slug = Str::slug($request->titre,"-");
        $biblio->courte = $request->courte;
        $biblio->description = $request->description;
        $biblio->photo = $request->photo;
        $biblio->Update();//
    return redirect()->back()->with('success','Bibliotheque  modifier avec succes');//
    }

    public function publierbiblio(Request $request, string $id)
    {
        $biblio = Bibliotheque ::findOrFail($id);
        $biblio->status = 'public';
        $biblio->Update();//
    return redirect()->back()->with('success','Bibliotheque  publier avec succes');//
    }

    public function bloquerbiblio(Request $request, string $id)
    {
        $biblio = Bibliotheque ::findOrFail($id);
        $biblio->status = 'prive';
        $biblio->Update();//
    return redirect()->back()->with('success','Bibliotheque  bloquer avec succes');//
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $biblio = Bibliotheque::findOrFail($id);
    
        // Vérifier et supprimer l'image si elle existe
        if ($biblio->photo && file_exists(public_path($biblio->photo))) {
            unlink(public_path($biblio->photo));
        }
    
        // Vérifier et supprimer le document si il existe
        if ($biblio->document && file_exists(public_path($biblio->document))) {
            unlink(public_path($biblio->document));
        }
    
        // Supprimer l'enregistrement de la base de données
        $biblio->delete();
    
        return redirect()->back()->with('success', 'Élément de la bibliothèque supprimé avec succès');
    }
    
}
