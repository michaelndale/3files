<?php

namespace App\Http\Controllers;

use App\Models\Fonction as ModelsFonction;
use App\Models\Fonctions;
use Illuminate\Http\Request;

class Fonction extends Controller
{
    public function index()
    {
     $allfonction = ModelsFonction::all();
     return view('Backend.Fonctions.index',compact('allfonction'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
      return view('Backend.Fonctions.nouveau');  //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
     $fonction = new ModelsFonction();
     $fonction->titre =$request->titre;
    $fonction->save();//
    return redirect()->route('fonction')->with('success','utilisateur creer avec succes');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
     $fonction = ModelsFonction::find($id);   //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $fonction = ModelsFonction::find($id);  //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $fonction = ModelsFonction::findOrFail($id);
     $fonction->titre =$request->titre;
    $fonction->Update();//
    return redirect()->route('fonctions.modifier')->with('success','utilisateur modifier avec succes');//
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $fonction = ModelsFonction::find($id);
        $fonction->delete();
        return redirect()->route('fonction')->with('success','utilisateur suprimer avec succes'); //
    }
}
