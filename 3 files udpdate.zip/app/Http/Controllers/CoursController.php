<?php

namespace App\Http\Controllers;

use App\Models\annee;
use App\Models\cours;
use App\Models\DispenseCours;
use App\Models\dispenser_cours;
use App\Models\Faculte;
use App\Models\Facultecours;
use App\Models\ModuleCours;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CoursController extends Controller
{
    public function listecours()
    {
     $allcour = cours::all();
     return view('Backend.Cours.index',compact('allcour'));
    }

    public function mescours()
    {
     $allcour = DB::table('dispenser_cours')
     ->join('cours', 'dispenser_cours.cours_id','cours.id')
     ->join('users', 'dispenser_cours.user_id', 'users.id')
     ->select('cours.*')
     ->where('dispenser_cours.user_id','=', Auth::id())
     ->get();
     return view('Backend.Cours.mescours',compact('allcour'));
    }
    
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
      return view('Backend.Cours.nouveau');  //
    }
    
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $cours = new cours();
        $cours->titre =$request->titre;
        $cours->volume =$request->volume;
        $cours->pondelation =$request->ponderation;
        $cours->description =$request->description;
        $cours->save();//
        return redirect()->back()->with('success', 'Le cours a été créé avec succès.');

    
    }
    
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
     $cours = cours::find($id); 
     return view('Backend.Cours.voir',compact('cours'));  //
    }
    
    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $cours =cours::find($id);  //
        return view('Backend.Cours.modifier',compact('cours'));  //
    }
    
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
     $cours = cours::findOrFail($id);
     $cours->titre =$request->titre;
     $cours->volume =$request->volume;
     $cours->pondelation =$request->ponderation;
     $cours->description =$request->description;
     $cours->Update();//
     return redirect()->back()->with('success', 'Le cours a été modifié avec succès.');

    }
    
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $cours = cours::find($id);
        $cours->delete();
        return redirect()->back()->with('success', 'Le cours a été supprimé avec succès.');

    }




    public function storeModule(Request $request)
    {

    $docName=time().'.'.$request->documentpdf->extension();
    $request->documentpdf->move(public_path('document/modules/'),$docName);
    $UrlDoc="document/modules/".$docName;

     $module = new ModuleCours ();
     $module->cours_id =$request->idcours;
     $module->titre =$request->moduletitre;
     $module->slug = Str::slug($request->moduletitre,"-");
     $module->description = $request->moduledescription;
     $module->url_pdf =  $UrlDoc;
     $module->url_video =  $request->video;
     $module->user_id = Auth::id();
    $module->save();//

    return redirect()->back()->with('success', 'Le module "' . $request->moduletitre . '" a été créé avec succès.');

    }

    public function listemodules($id)
    {
     $allmodule = ModuleCours::join('users', 'module_cours.user_id','users.id')
     ->where('cours_id','=',$id)
     ->select('module_cours.*',  'users.prenom as prenomUser',  'users.email as emailUser')
     ->get();
     $cours =cours::find($id);  //
     return view('Backend.Cours.Modules.index',compact('allmodule','cours'));
    }


    public function meslistemodules($id)
    {
     $allmodule = ModuleCours::join('users', 'module_cours.user_id','users.id')
     ->where('cours_id','=',$id)
     ->select('module_cours.*',  'users.prenom as prenomUser',  'users.email as emailUser')
     ->get();
     $cours =cours::find($id);  //
     return view('Backend.Cours.Modules.mesmodules',compact('allmodule','cours'));
    }

    public function listecoursdispenser()
    {
     $alldispenser = DB::table('dispenser_cours')
                        ->join('users', 'dispenser_cours.user_id',  'users.id')
                        ->join('personnels','users.id', 'personnels.user_id')
                        ->join('cours', 'dispenser_cours.cours_id',  'cours.id')
                        ->select('dispenser_cours.*','cours.titre as CoursTitre',  'personnels.prenom as PrenomUsers','personnels.nomp as nompersonnel')
                        ->get();

                       

    $allcour = cours::all();
    $allProf = User::join('personnels', 'users.id', 'personnels.user_id')
               ->select('users.id as idu', 'personnels.nomp as nom', 'personnels.prenom as prenomp')
               ->get();

     return view('Backend.Cours.Dispenser.index',compact('alldispenser','allcour' , 'allProf'));
    }

    public function storeDispenser(Request $request)
    {
        $disp = new dispenser_cours();
        $disp->user_id = $request->profid;
        $disp->cours_id = $request->coursid;
        $disp->save();//

        return redirect()->back()->with('success', 'La dispensation a été créé  avec succès.');
    
    }
    public function editdispense(string $id)
    {
        $alldispenser =DB::table('dispenser_cours')
        ->join('users', 'dispenser_cours.user_id',  'users.id')
        ->join('personnels', 'users.id', 'personnels.user_id')
        ->join('cours', 'dispenser_cours.cours_id',  'cours.id')
        ->select('dispenser_cours.*','dispenser_cours.id as idD','cours.titre as CoursTitre',  'users.id as idU',  'personnels.nomp as nom', 'personnels.prenom as prenomp')
        ->where('dispenser_cours.id',$id)
        ->first();  //

        $allcour = cours::all();
        $allProf = User::join('personnels', 'users.id', 'personnels.user_id')
        ->select('users.id as idu', 'personnels.nomp as nom', 'personnels.prenom as prenomp')
        ->get();

        return view('Backend.Cours.Dispenser.modifier' ,compact('alldispenser','allcour','allProf'));  //
    }



    public function updatedispense(Request $request, string $id)
    {
        $alldispenser = dispenser_cours::findOrFail($id);
        $alldispenser->user_id = $request->profid;
        $alldispenser->cours_id = $request->coursid;
        $alldispenser->Update();//

        return redirect()->back()->with('success', 'La dispensation a été modifié avec succès.');

    }

    // AFFECTATION DES COURS A LA FACULTE


    public function listeaffectation($id)
    {

     $allcour = cours::all();
     $allanne= annee::all();

     $oneFaculte =  Faculte::find($id);

     $allaffectation = Facultecours::join('cours', 'facultecours.cours_id', 'cours.id')
     ->join('annees', 'facultecours.annescolaire_id','annees.id')
     ->select('facultecours.id as idf' , 'cours.titre as titre_cours', 'annees.libelle as libelle_annee')
     ->where('facultecours.faculte_id', $id)
     ->get();


     return view('Backend.Faculte.affectation.index',compact('allaffectation','oneFaculte','allanne','allcour'));
    }

    public function storeaffectation(Request $request)
    {
        $cours = new Facultecours();
        $cours->cours_id =$request->cours_id;
        $cours->annescolaire_id  =$request->annee_id;
        $cours->faculte_id  =$request->faculte_id ;
   
        $cours->save();//
        return redirect()->back()->with('success', 'L\'affectation a été créée avec succès.');

    
    }


   
    public function destroyDispenser(string $id)
    {
        $dispenser = dispenser_cours::find($id);
        $dispenser->delete();
        return redirect()->back()->with('success', 'La suppression se fait avec succès.');

    }

    public function destroyModule(string $id)
    {
        $dispenser = ModuleCours::find($id);
        $dispenser->delete();
        return redirect()->back()->with('success', 'La suppression se fait avec succès.');

    }


    
    public function blockCours($id)
    {
        // Récupérer l'utilisateur par son ID
        $cours = cours::findOrFail($id);

        // Mettre à jour la colonne 'active' avec le statut 'BLOQUE'
        $cours->status = 'BLOQUE';
        $cours->save();

        // Retourner une redirection avec un message de succès
        return redirect()->back()->with('success', 'Cours bloqué avec succès.');
    }

    public function activeCours($id)
    {
        // Récupérer l'utilisateur par son ID
        $cours = cours::findOrFail($id);

        // Mettre à jour la colonne 'active' avec le statut 'BLOQUE'
        $cours->status = 'ACTIF';
        $cours->save();

        // Retourner une redirection avec un message de succès
        return redirect()->back()->with('success', 'Cours Active avec succès.');
    }
    
    
    
}
