<?php

namespace App\Http\Controllers;

use App\Models\Payement;
use Illuminate\Http\Request;

class PayementController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $payement = Payement::join('users', 'users.id', '=', 'payements.user_id')
        ->join('etudiants', 'users.id', 'etudiants.user_id')
        ->select('payements.*', 'etudiants.nom', 'etudiants.prenom')
        ->orderBy('payements.id', 'desc')->get();

        return view('Backend.Paiement.index', compact('payement'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Créer une nouvelle instance de Payement
        $paie = new Payement();

        // Assigner les valeurs reçues du formulaire à l'objet Payement
        $paie->user_id = $request->client_name;
        $paie->classe_id = $request->class;
        $paie->annee_id = $request->year;
        $paie->type_payement = $request->payment_type;
        $paie->amount = $request->amount;
        $paie->payment_date = $request->payment_date;
        $paie->payment_method = $request->payment_method;
        $paie->reference_number = $request->reference_number;
       
        $paie->description = $request->description;

        // Sauvegarder l'objet dans la base de données
        $paie->save();

        // Retourner à la vue précédente avec un message de succès
        return redirect()->back()->with('success', 'Paiement enregistré avec succès');
    }

    public function checkReference(Request $request)
    {
        // Vérifiez si le numéro de référence existe dans la base de données
        $exists = Payement::where('reference_number', $request->reference_number)->exists();

        return response()->json(['exists' => $exists]);
    }

    public function checkPayment(Request $request)
    {
        // Vérifiez si une entrée correspondante existe
        $exists = Payement::where('etudiant_id', $request->client_name)
                        ->where('annee_id', $request->year)
                        ->where('type_payement', $request->payment_type)
                        ->exists();

        return response()->json(['exists' => $exists]);
    }




    /**
     * Display the specified resource.
     */
    public function show(Payement $payement)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Payement $payement)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Payement $payement)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Payement $payement)
    {
        //
    }

    public function blockPaie($id)
    {
        // Récupérer l'utilisateur par son ID
        $Paie = Payement::findOrFail($id);

        // Mettre à jour la colonne 'active' avec le statut 'BLOQUE'
        $Paie->status = 0;
        $Paie->save();

        // Retourner une redirection avec un message de succès
        return redirect()->back()->with('success', 'Payement bloqué avec succès.');
    }

    public function activePaie($id)
    {
        // Récupérer l'utilisateur par son ID
        $Paie = Payement::findOrFail($id);

        // Mettre à jour la colonne 'active' avec le statut 'BLOQUE'
        $Paie->status = 1;
        $Paie->save();

        // Retourner une redirection avec un message de succès
        return redirect()->back()->with('success', 'Payement valide avec succès.');
    }
}
