<?php

namespace App\Http\Controllers;

use App\Models\annee;
use App\Models\Classe;
use App\Models\cours;
use App\Models\Faculte as ModelsFaculte;
use App\Models\Facultecours;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Faculte extends Controller
{
    public function index()
    {
     $allFaculte = ModelsFaculte::all();
     return view('Backend.Faculte.index',compact('allFaculte'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
      return view('Backend.Faculte.nouveau');  //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $Classe = new  ModelsFaculte();
        $Classe->libelle =$request->libelle;
        $Classe->save();//
             return redirect()->route('faculte')->with('success','Faculte creer avec succes');

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
     $Classe =  ModelsFaculte::find($id);   //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $Classe = ModelsFaculte::find($id);  //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
     $Classe = ModelsFaculte::findOrFail($id);
     $Classe->titre =$request->titre;
     $Classe->Update();//
    return redirect()->route('faculte.modifier')->with('success','Faculte modifier avec succes');//
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $Classe =  ModelsFaculte::find($id);
        $Classe->delete();
        return redirect()->route('faculte')->with('success','Faculte suprimer avec succes'); //
    }




    // 
    public function  liste_cours_classe(string $id)
    {
        $allcour =  DB::table('facultecours') 
                    ->join('cours', 'facultecours.cours_id', 'cours.id')
                    ->join('classes','facultecours.classe_id', 'classes.id')
                    ->join('facultes', 'facultecours.faculte_id', 'facultes.id')
                    ->join('annees','facultecours.annescolaire_id', 'annees.id')
                    ->select('cours.*')
                    ->where('facultecours.classe_id', $id)
                    ->get();

    //$faculte =   ModelsFaculte::find($id);   //
    $cours= cours::all();
    $anne_actif= annee::where('statut','=','ACTIF')->first();

    $classe = DB::table('classes')
                    ->join('facultes', 'classes.faculte_id', 'facultes.id')
                    ->select('classes.libelle as classeNom', 'classes.id as classeId', 'facultes.libelle as faculteNom', 'facultes.id as faculteId')
                    ->where('classes.id', $id)
                    ->first();




     return view('Backend.Faculte.classe.cours.index' ,compact('allcour','cours','anne_actif','classe'));
    }


    public function store_cours_classe(Request $request)
    {
        $Classe = new Facultecours();
        $Classe->cours_id  =$request->courid;
        $Classe->annescolaire_id =$request->anneid;
        $Classe->faculte_id =$request->faculteid;
        $Classe->classe_id =$request->classeid;
        $Classe->save();//
             return redirect()->back()->with('success','Affectation Classe creer avec succes');

    }

}
