@include('Frontend.components.header')
@include('Frontend.components.menu')

	<!-- PhotoSlider Section -->
	<div class="photoslider-section container-fluid no-padding">
		<div id="home-slider" class="carousel slide" data-ride="carousel">
			<div class="carousel-inner" role="listbox">
				<div class="item active">
					<img src="{{ asset('frontend/images/photoslider1.jpg') }}" alt="photoslider1" width="1920" height="801"/>
					<div class="carousel-caption">
						<div class="container">
							<div class="col-md-6 col-sm-8 col-xs-8 ow-pull-right no-padding">
								<h4 data-animation="animated bounceInLeft">Bienvenu</h4>
								<h3 data-animation="animated fadeInDown">À notre<span>Université</span></h3>
								<p data-animation="animated bounceInRight">Nous pensons que rien n'est plus important que l'éducation. La meilleure institution d'apprentissage</p>
								<a href="{{ route('inscription') }}" title="Pour aller plus loin" data-animation="animated zoomInUp">Apprendre encore plus</a>
							</div>
						</div>
					</div>
				</div>
				<div class="item">
					<img src="{{ asset('frontend/images/photoslider2.jpg') }}" alt="photoslider2" width="1920" height="801"/>
					<div class="carousel-caption">
						<div class="container">
							<div class="col-md-6 col-sm-8 col-xs-8 ow-pull-left no-padding">
								<h4 data-animation="animated bounceInLeft">Bienvenu</h4>
								<h3 data-animation="animated fadeInDown">À notre<span>Université</span></h3>
								<p data-animation="animated bounceInRight">Nous pensons que rien n'est plus important que l'éducation. La meilleure institution d'apprentissage</p>
								<a href="{{ route('inscription') }}" title="Pour aller plus loin" data-animation="animated zoomInUp">Apprendre encore plus</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<a class="left carousel-control" href="#home-slider" role="button" data-slide="prev">
				<i class="fa fa-angle-left"></i>
			</a>
			<a class="right carousel-control" href="#home-slider" role="button" data-slide="next">
				<i class="fa fa-angle-right"></i>
			</a>
		</div>
	</div><!-- PhotoSlider Section /- -->	
	<!-- Welcome Section -->
	<div class="container welcome-section">
		<div class="section-padding"></div>
		<div class="section-header">
			<h3>Populaire <span>Facultés</span></h3>
			<p>Une formation, un métier, un avenir
			Offre-toi la possibilité de faire le métier qui te plait</p>
		</div>
		<div class="row">
			<div class="col-md-4 col-sm-6 col-xs-6">
				<div class="welcome-box">
					<img src="{{ asset('frontend/images/welcome1.jpg') }}" alt="welcome1" width="370" height="440"/>
					<div class="welcome-title">
						<h3>GENI INFORMATIQUE</h3>
					</div>	
					<div class="welcome-content">
						<span>(Walter White)</span>
						<p>Puis un jour, il tirait sur lui, quand le contre lui bouillonnait</p>
						<ul class="course-detail">
							<li><i class="fa fa-calendar" aria-hidden="true"></i>Durée du cours : <span>3 ans</span></li>
							<li><i class="fa fa-graduation-cap" aria-hidden="true"></i>Niveau de diplôme : <span>Baccalaureat</span></li>
						</ul>
						<ul class="course-rating">
							<li><a href="#" title="1 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="2 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="3 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="4 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="5 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
						</ul>
						<a href="coursesdetails-page.html" title="Apply now">Postulez maintenant</a>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-6 col-xs-6">
				<div class="welcome-box">
					<img src="{{ asset('frontend/images/welcome2.jpg') }}" alt="welcome2" width="370" height="440"/>
					<div class="welcome-title">
						<h3>TELECOMMUNICATION</h3>
					</div>	
					<div class="welcome-content">
						<span>(Sarah Jhinson)</span>
						<p>Puis un jour, il tirait sur lui, quand le contre lui bouillonnait</p>
						<ul class="course-detail">
							<li><i class="fa fa-calendar" aria-hidden="true"></i>Durée du cours : <span>3 ans</span></li>
							<li><i class="fa fa-graduation-cap" aria-hidden="true"></i>Niveau de diplôme : <span>maîtrise</span></li>
						</ul>
						<ul class="course-rating">
							<li><a href="#" title="1 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="2 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="3 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="4 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="5 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
						</ul>
						<a href="coursesdetails-page.html" title="Apply now">Postulez maintenant</a>
					</div>
				</div>
			</div>
			<div class="col-md-4 col-sm-6 col-xs-6">
				<div class="welcome-box">
					<img src="{{ asset('frontend/images/welcome3.jpg') }}" alt="welcome3" width="370" height="440"/>
					<div class="welcome-title">
						<h3>RESEAU INFORMATIQUE</h3>
					</div>	
					<div class="welcome-content">
						<span>(Ethan Elon)</span>
						<p>Puis un jour, il tirait sur lui, quand le contre lui bouillonnait</p>
						<ul class="course-detail">
							<li><i class="fa fa-calendar" aria-hidden="true"></i>Durée du cours : <span>3 ans</span></li>
							<li><i class="fa fa-graduation-cap" aria-hidden="true"></i>Niveau de diplôme : <span>Baccalaureat</span></li>
						</ul>
						<ul class="course-rating">
							<li><a href="#" title="1 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="2 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="3 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="4 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
							<li><a href="#" title="5 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a></li>
						</ul>
						<a href="coursesdetails-page.html" title="Apply now">Postulez maintenant</a>
					</div>
				</div>
			</div>
		</div>
		<div class="section-padding"></div>
	</div><!-- Welcome Section /- -->
	
	<!-- Parallax Section -->
	<div class="container-fluid no-padding parallax-section">
		<div class="parallax-carousel">
			<div class="parallax-block">
				<div class="parallax-box">
					<img src="{{ asset('frontend/images/parallax-bg.jpg') }}" alt="parallax" width="1920" height="600"/>
				</div>
				<div class="parallax-content">
					<h3>Apprendre des cours en ligne</h3>
					<h3>Seules la patience et la persévérance donnent <span>Bon résultat</span></h3>
					<p>Le plus grand centre de livres et de bibliothèques au monde se trouve ici où vous pourrez étudier les dernières tendances en matière d'éducation.</p>
					<a href="#" title="Find More About Us">En savoir plus sur nous</a>
					<ul>
						<li><img src="{{ asset('frontend/images/parallax-thumb1.jpg') }}" alt="parallax-thumb1" width="100" height="80"/></li>
						<li><img src="{{ asset('frontend/images/parallax-thumb2.jpg') }}" alt="parallax-thumb2" width="100" height="80"/></li>
						<li><img src="{{ asset('frontend/images/parallax-thumb3.jpg') }}" alt="parallax-thumb3" width="100" height="80"/></li>
					</ul>
				</div>
			</div>			
			<div class="parallax-block">
				<div class="parallax-box">
					<img src="{{ asset('frontend/images/parallax-bg.jpg') }}" alt="parallax" width="1920" height="600"/>
				</div>
				<div class="parallax-content">
					<h3>Learn Online</h3>
					<h3>Only patience & persistence give <span>Good Result 2</span></h3>
					<p>World Largest books and library center is here where you can study the latest trends of the education. Curabitur rutrum faucibus elitconvallis diam mattis eget. Nullam vulputate nibh at nisi consectetur.</p>
					<a href="#" title="Find More About Us">Find More About Us</a>
					<ul>
						<li><img src="{{ asset('frontend/images/parallax-thumb1.jpg') }}" alt="parallax-thumb1" width="100" height="80"/></li>
						<li><img src="{{ asset('frontend/images/parallax-thumb2.jpg') }}" alt="parallax-thumb2" width="100" height="80"/></li>
						<li><img src="{{ asset('frontend/images/parallax-thumb3.jpg') }}" alt="parallax-thumb3" width="100" height="80"/></li>
					</ul>
				</div>
			</div>
			<div class="parallax-block">
				<div class="parallax-box">
					<img src="{{ asset('frontend/images/parallax-bg.jpg') }}" alt="parallax" width="1920" height="600"/>
				</div>
				<div class="parallax-content">
					<h3>Learn Courses</h3>
					<h3>Only patience & persistence give <span>Good Result 3</span></h3>
					<p>World Largest books and library center is here where you can study the latest trends of the education. Curabitur rutrum faucibus elitconvallis diam mattis eget. Nullam vulputate nibh at nisi consectetur.</p>
					<a href="#" title="Find More About Us">Find More About Us</a>
					<ul>
						<li><img src="{{ asset('frontend/images/parallax-thumb1.jpg') }}" alt="parallax-thumb1" width="100" height="80"/></li>
						<li><img src="{{ asset('frontend/images/parallax-thumb2.jpg') }}" alt="parallax-thumb2" width="100" height="80"/></li>
						<li><img src="{{ asset('frontend/images/parallax-thumb3.jpg') }}" alt="parallax-thumb3" width="100" height="80"/></li>
					</ul>
				</div>
			</div>
			<div class="parallax-block">
				<div class="parallax-box">
					<img src="{{ asset('frontend/images/parallax-bg.jpg') }}" alt="parallax" width="1920" height="600"/>
				</div>
				<div class="parallax-content">
					<h3>Learn Online Courses</h3>
					<h3>Only patience & persistence give <span>Good Result 4</span></h3>
					<p>World Largest books and library center is here where you can study the latest trends of the education. Curabitur rutrum faucibus elitconvallis diam mattis eget. Nullam vulputate nibh at nisi consectetur.</p>
					<a href="#" title="Find More About Us">Find More About Us</a>
					<ul>
						<li><img src="{{ asset('frontend/images/parallax-thumb1.jpg') }}" alt="parallax-thumb1" width="100" height="80"/></li>
						<li><img src="{{ asset('frontend/images/parallax-thumb2.jpg') }}" alt="parallax-thumb2" width="100" height="80"/></li>
						<li><img src="{{ asset('frontend/images/parallax-thumb3.jpg') }}" alt="parallax-thumb3" width="100" height="80"/></li>
					</ul>
				</div>
			</div>
		</div>
	</div><!-- Parallax Section /- -->
	
	<!-- Event Section -->
	<div class="container event-section">
		<div class="section-padding"></div>	
		<div class="section-header-block">
			<div class="section-header">
				<h3>Notre <span>Bibliothèque</span></h3>
				<p>Les livres de memoir des etudiants finaliste disponibles en ligne<p>
			</div>
			<a href="{{ route('bibliotheque.public') }}" title="Tout afficher">Tout afficher</a>
		</div>
		<div class="event-block">
			@forelse ($bibliotheque as $bibliotheques)

			<div class="event-box">
				<div class="row">
					<div class="col-md-3 col-sm-4 col-xs-5">
						<img src="{{ asset($bibliotheques->photo) }}" alt="event1" width="260" height="160"/>

					</div>
					<div class="col-md-7 col-sm-6 col-xs-7">
						<h3><a href="javascript::void(0)" title="{{ $bibliotheques->titre }}">{{ $bibliotheques->titre }}</a></h3>
						<div class="event-meta">
						
							<span><i aria-hidden="true" class="fa fa-map-marker"></i>Bujumbura</span>
						</div>
						<p>{{ $bibliotheques->description }}</p>
					</div>
					<div class="col-md-2 col-sm-2 col-xs-12">
						<a href="{{ route('portailetudiant') }}" class="readmore" title="Read More">Voir plus</a>
					</div>
				</div>
			</div>

				
			@empty
				
			@endforelse
			

		
		</div>
		<div class="section-padding"></div>
	</div><!-- Event Section /- -->	
	
	<!-- Search Courses -->
	<div class="container-fluid no-padding searchcourses"
			<div class="search-content">
				<div class="searchcourses-block">
					
						<h3>
							Bienvenue ! Plus de {{ $etudiant->count() }} étudiants nous font déjà confiance. Rejoignez-nous et profitez d’un apprentissage flexible et accessible à tout moment. Inscrivez-vous dès maintenant pour suivre vos cours en ligne dans la classe de votre choix, où que vous soyez, et avancez à votre rythme vers vos objectifs.

							
						</h3>

				</div>
				
				
			</div>
	
	</div><!-- Search Courses /- -->
	
	<!-- Video Testimonial Section 
	<div class="container-fluid no-padding video-testimonial-section">
		<div class="container">
			<div class="section-padding"></div>
			<div class="section-header">
				<h3>Our <span>Education Events</span></h3>
				<p>Achieving the desired success requires patience and persistence your goals need time</p>
			</div>
			<div class="row">
				<div class="col-md-6 col-sm-12">
					<div class="video-block video-block-lg">
						<a title="Paly Video" class="popup-youtube" href="http://www.youtube.com/watch?v=0O2aH4XLbto"><i class="fa fa-play" aria-hidden="true"></i></a>
						<img  src="{{ asset('frontend/images/video-poster-1.jpg') }}" width="570" height="400" alt="Video Poster-1"/>
						<div class="video-content">
							<h3>Your Career Starts Here</h3>
							<p>Achieving the desired success requires patience and persistence.</p>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-12">
					<div class="testimonial-block">
						<div id="testimonial-slider" class="carousel slide" data-ride="carousel">
							<ol class="carousel-indicators">
								<li data-target="#testimonial-slider" data-slide-to="0" class="active"></li>
								<li data-target="#testimonial-slider" data-slide-to="1"></li>
							</ol>
							<div class="carousel-inner" role="listbox">
								<div class="item active">
									<div class="testimonial-box">
										<div class="testimonial-content">
											<p>Credibly innovate granular internal or organic sources whereas high standards in web-readiness fully researched growth.</p>
										</div>
										<div class="testimonial-author">
											<img src="{{ asset('frontend/images/testimonial-thumb-1.jpg') }}" alt="testimonial-thumb-1" width="96" height="96"/>
											<p>Darly Dixon, <span>Designing Staff</span></p>
										</div>
									</div>
									<div class="testimonial-box">
										<div class="testimonial-content">
											<p>Credibly innovate granular internal or organic sources whereas high standards in web-readiness fully researched growth.</p>
										</div>
										<div class="testimonial-author">
											<img src="{{ asset('frontend/images/testimonial-thumb-2.jpg') }}" alt="testimonial-thumb-2" width="96" height="96"/>
											<p>Josh Austin,<span>Project Manager</span></p>
										</div>
									</div>
								</div>
								<div class="item">
									<div class="testimonial-box">
										<div class="testimonial-content">
											<p>Credibly innovate granular internal or organic sources whereas high standards in web-readiness fully researched growth.</p>
										</div>
										<div class="testimonial-author">
											<img src="{{ asset('frontend/images/testimonial-thumb-1.jpg') }}" alt="testimonial-thumb-1" width="96" height="96"/>
											<p>Darly Dixon <span>Designing Staff</span></p>
										</div>
									</div>
									<div class="testimonial-box">
										<div class="testimonial-content">
											<p>Credibly innovate granular internal or organic sources whereas high standards in web-readiness fully researched growth.</p>
										</div>
										<div class="testimonial-author">
											<img src="{{ asset('frontend/images/testimonial-thumb-2.jpg') }}" alt="testimonial-thumb-2" width="96" height="96"/>
											<p>Josh Austin ,<span>Project Manager</span></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="section-padding"></div>
		</div>
	</div> Video Testimonial Section /- -->	
	
	<!-- LatestBlog Section -->
	<div class="container-fulid no-padding latestblog-section">
		<div class="section-padding"></div>
		<div class="container">
			<div class="section-header">
				<h3>Dernières <span> Actualités  </span></h3>
			
			</div>
			<div class="row">
				@forelse ($blog as $blogs)
				<div class="col-md-4 col-sm-6 col-xs-6">

					<article class="type-post">
						<div class="entry-cover">
							<a title="Cover" href="{{ route('voir.blog.public', $blogs->id )}}">
								<img width="363" height="261" alt="latestnews" src="{{ asset('images/blogs/' . $blogs->photo) }}">
							</a>
							
						</div>
						<div class="entry-block">
							<div class="entry-contentblock">
								<div class="entry-meta">
									<span class="postdate">{{ date('d-m-Y', strtotime($blogs->created_at)) }} </span>
									<span class="postby">{{ $blogs->courte}}</span>
								</div>
								<div class="entry-block">
									<div class="entry-title">
										<a title="{{ $blogs->titre}}" href="{{ route('voir.blog.public', $blogs->id )}}"><h3>{{ $blogs->titre}}</h3></a>
									</div>
								</div>
							</div>
							
						</div>
					</article>
				</div>
				
				@empty
					
				@endforelse
				
				
			</div>
			<div class="post-viewall">
				<a href="{{ route('blog.public') }}"  title="View All post">Voir plus</a>
			</div>
		</div>
		<div class="section-padding"></div>
	</div><!-- LatestBlog Section -->
		<!-- Footer Main -->

       @include('Frontend.components.footer')
	