@include('Frontend.components.header')
@include('Frontend.components.menu')

<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content">
            <h3>{{ $blog->titre }}</h3>
            <ol class="breadcrumb">
                <li><a href="/">Accueil</a></li>
                <li>Blog</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->

<div class="container coursesdetail-section">
    <div class="section-padding"></div>
        <div class="row">
            <div class="col-md-9 col-sm-8 event-contentarea">
                <div class="coursesdetail-block">
                    <img src="{{ asset('images/blogs/' . $blog->photo) }}" alt="event-coursesdetail" />
                    <div class="course-description">
                        <h3 class="course-title">{{ $blog->titre }}</h3>
                        <p>
                            {{ $blog->description }}
                        </p>
                       
                    </div>
                   
                    
                    
                </div>
              
            </div>
          
        </div>
    <div class="section-padding"></div>
</div>

@include('Frontend.components.footer')
