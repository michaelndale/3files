@include('Frontend.components.header')
@include('Frontend.components.menu')

<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content">
            <h3>Bibliotheque</h3>
            <ol class="breadcrumb">
                <li><a href="/">Accueil</a></li>
                <li>Bibliotheque</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->

<div class="container event-section">
    <div class="section-padding"></div>	
    <div class="section-header-block">
        <div class="section-header">
            <h3>Notre <span>Bibliotheque</span></h3>
            <p>Les livres de memoir des etudiants finaliste disponibles en ligne<p>
        </div>
       
    </div>
    <div class="event-block">
        @forelse ($bibliotheque as $bibliotheques)

        <div class="event-box">
            <div class="row">
                <div class="col-md-3 col-sm-4 col-xs-5">
                    <img src="{{ asset($bibliotheques->photo) }}" alt="event1" width="260" height="160"/>

                </div>
                <div class="col-md-7 col-sm-6 col-xs-7">
                    <h3><a href="javascript::void(0)" title="{{ $bibliotheques->titre }}">{{ $bibliotheques->titre }}</a></h3>
                    <div class="event-meta">
                    
                        <span><i aria-hidden="true" class="fa fa-map-marker"></i>Bujumbura</span>
                    </div>
                    <p>{{ $bibliotheques->description }}</p>
                </div>
                <div class="col-md-2 col-sm-2 col-xs-12">
                    <a href="{{ route('portailetudiant') }}" class="readmore" title="Read More">Voir plus</a>
                </div>
            </div>
        </div>

            
        @empty
            
        @endforelse
        

    
    </div>
    <div class="section-padding"></div>
</div><!-- Event Section /- -->	


	
@include('Frontend.components.footer')
