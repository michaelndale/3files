@include('Frontend.components.header')
@include('Frontend.components.menu')
<!-- PageBanner -->
<div class="container-fluid no-padding pagebanner" >
		<div class="container" >
			<div class="pagebanner-content" style="height:10px">
				<h3> Bibliotheques</h3>
				<ol class="breadcrumb">
					<li><a href="index.html">Code matricule</a></li>
					<li>{{ $me->code  }}</li>
					<li>Bienvenu</li>
				</ol>
			</div>
		</div>
	</div><!-- PageBanner /- -->
<div class="container coursesdetail-section">
		<div class="section-padding"></div>
			<div class="row">

				
				@php
				$nombre_livre  = DB::table('bibliotheques')
					 ->where('status', '=', 'public')
					 ->count()
				
					 
				@endphp
				
				<div class="col-md-3 col-sm-4 event-sidebar">
					<div class="courses-features">
					<div class="featuresbox"><a href="{{ route('bienvenue') }}"> <img src="{{ asset('frontend/images/user-ic.png')}}" alt="user-ic" width="22" height="22" />
								<h3>Accuiel </h3>
							</a></div>
					
						
				
							@if($me->libelle_classe !== 'Terminer')
				
						  
				
							@if ($nonCorrespondantsDepasses->isNotEmpty() )
				
									<div class="featuresbox"><a href="{{ route('mescours') }}"><img src="{{ asset('frontend/images/codepen-ic.png')}}" alt="codepen-ic" width="22" height="22" />
										<h3>Cours </h3> </a>
									</div>
				
									
								
									<div class="featuresbox"><a href="{{ route('mesexamens') }}"><img src="{{ asset('frontend/images/codepen-ic.png')}}" alt="codepen-ic" width="22" height="22" />
										<h3>Examens </h3> </a>
									</div>
				
									<div class="featuresbox"><a href="{{ route('forum') }}"><img src="{{ asset('frontend/images/codepen-ic.png')}}" alt="codepen-ic" width="22" height="22" />
										<h3>Forum </h3> </a>
									</div>
								@endif
							@endif
				
					@if($me->libelle_classe !== 'Terminer')
						  
						<div class="featuresbox"><a href="{{ route('mespayements') }}"><img src="{{ asset('frontend/images/dolar-ic.png')}}" alt="dolar-ic" width="27" height="27" />
							<h3>Payement </h3></a>
						</div>
				
					 
				
					
						<div class="featuresbox"><a href="{{ route('mesbibliotheques') }}"><img src="{{ asset('frontend/images/cup-ic.png')}}" alt="cup-ic" width="24" height="23" />
							<h3>Bibliotrheque </h3> </a><span> ({{ $nombre_livre }})</span>
						</div>
						@endif
						<div class="featuresbox"><a href="{{ route('profile') }}"> <img src="{{ asset('frontend/images/user-ic.png')}}" alt="user-ic" width="22" height="22" />
								<h3>Profile </h3>
							</a></div>
				
					</div>
					
				</div>

				

				<div class="col-md-9 col-sm-8 event-contentarea">
					
                   
						<div class="courses-curriculum">
								<div class="row">
								<div class="col-md-9">
									<h3 class="course-title">Bibliotheques des livres de memoires des etudiants</h3>
								</div>
								<div class="col-md-3">
									<a href="{{ route('nouveaubibliothequeetudiant') }}" class="btn btn-primary" style="width:100%"><i class="fa fa-plus-circle" > </i> Envoyer le memoire </a> 
								</div>
								</div>
								<div class="courses-sections-block">
									@foreach ($allBibliotheque as $allBibliotheques)
										<div class="courses-lecture-box">
											<i class="fa fa-file-o" aria-hidden="true"></i>
											<span class="lecture-no">
												<b>
													<a href="javascript:void(0);" class="openModal" 
													data-title="{{ $allBibliotheques->titre }}" 
													data-document="{{ asset($allBibliotheques->document) }}">
														{{ $allBibliotheques->titre }}
													</a>
												</b>
											</span>
											<span class="lecture-time">{{ $allBibliotheques->nom }} {{ $allBibliotheques->prenom }}</span>
										</div>
									@endforeach

								</div>
								
							
						</div>
				
					
				</div>
				
			</div>

	</div>

	<!-- Modal Structure -->
	<!-- Modal HTML (only one modal for all items) -->
<div class="modal fade" id="pdfModal" tabindex="-1" role="dialog" aria-labelledby="pdfModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="pdfModalLabel">Document Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="pdfViewer" class="pdf-container">
                    <iframe id="coursePdf" width="100%" height="600px" frameborder="0"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JavaScript to handle the modal functionality -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Modal PDF
        const pdfModal = document.getElementById('pdfModal');
        const pdfModalLabel = document.getElementById('pdfModalLabel');
        const coursePdf = document.getElementById('coursePdf');

        // Open the PDF modal when a link is clicked
        document.querySelectorAll('.openModal').forEach(courseLink => {
            courseLink.addEventListener('click', function(event) {
                event.preventDefault();

                const title = this.getAttribute('data-title');
                const url_pdf = this.getAttribute('data-document');

                // Update modal content
                pdfModalLabel.textContent = title;
                coursePdf.src = url_pdf;

                // Show the modal
                $('#pdfModal').modal('show');
            });
        });

        // Clear the PDF source when the modal is closed
        $('#pdfModal').on('hidden.bs.modal', function () {
            coursePdf.src = '';
        });
    });
</script>
	
@include('Frontend.components.footer')
	