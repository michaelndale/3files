@include('Backend.components.header')

<div id="layout-wrapper">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">

               <div class="col-xl-6" style="margin:auto">
                <div class="card">
                    <!-- Barre de progression collée en haut et en bas -->
                    <div class="progress" style="height: 20px; margin-bottom: 0; border-radius:0%">
                        <div class="progress-bar" id="progress-bar" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                            0%
                        </div>
                    </div>
                
                    <div class="card-body" style="padding-bottom: 0; padding-top: 0;">
                        <br>
                        <h4 class="card-title"><b>Examens du cours: {{ $examen->titre_cours }}</b></h4>
                        <p class="card-subtitle mb-4">
                            <p>Question <span id="question-number">1</span> sur <span id="total-questions">{{ $questions->count() }}</span></p>
                        </p>
                        
                        <!-- Formulaire pour afficher une question à la fois -->
                        <form id="exam-form" action="{{ route('examen.repondre', ['id' => $examen->id]) }}" method="POST">
                            @csrf
                            <input type="hidden" id="question-id" name="question_id">
                            <input type="hidden" id="answer-id" name="answer_id">
                
                            <div class="question-box">
                                <h4 id="question"></h4>
                                <div id="choices"></div>
                            </div>
                            <br>
                            <button type="button" class="btn btn-primary" id="next-button" onclick="showNextQuestion()" disabled>Suivant</button>
                        </form>
                        <br>
                    </div>
                </div>
                </div>

            </div>
        </div>
    </div>
</div>



<script>
    const questions = @json($questions); // Charger toutes les questions dans un tableau
    let currentIndex = 0;

    // Fonction pour afficher la prochaine question
    function showNextQuestion() {
        // Désactiver le bouton "Suivant" pour éviter plusieurs clics
        document.getElementById('next-button').disabled = true;

        if (currentIndex < questions.length) {
            const question = questions[currentIndex];

            // Mettre à jour la question
            document.getElementById('question').innerText = `Question ${currentIndex + 1}: ${question.titre}`;

            // Mettre à jour les choix de réponse
            let choicesHtml = '';
            question.choixes.forEach(choix => {
                choicesHtml += `
                    <div style="padding-left: 20px;">
                        <input type="radio" name="reponse" value="${choix.id}" required onchange="enableNextButton()">
                        <label>${choix.titre}</label>
                    </div>
                `;
            });
            document.getElementById('choices').innerHTML = choicesHtml;

            // Mettre à jour le numéro de la question
            document.getElementById('question-number').innerText = currentIndex + 1;

            // Calculer la progression
            const progressPercentage = ((currentIndex + 1) / questions.length) * 100;
            document.getElementById('progress-bar').style.width = `${progressPercentage}%`;
            document.getElementById('progress-bar').setAttribute('aria-valuenow', progressPercentage);
            document.getElementById('progress-bar').innerText = `${Math.round(progressPercentage)}%`;

            // Incrémenter l'index pour la prochaine question
            currentIndex++;

            // Si c'est la dernière question, changer le texte du bouton
            if (currentIndex === questions.length) {
                document.getElementById('next-button').innerText = 'Terminer';
            }
        } else {
            // Si l'examen est terminé
            alert('Vous avez terminé l\'examen');
            document.getElementById('exam-form').submit();  // Soumettre le formulaire pour terminer l'examen
        }
    }

    // Fonction pour activer le bouton "Suivant" lorsque la réponse est choisie
    function enableNextButton() {
        document.getElementById('next-button').disabled = false;
    }

    // Afficher la première question au chargement de la page
    window.onload = function() {
        showNextQuestion();
    };
</script>

@include('Backend.components.footer')












