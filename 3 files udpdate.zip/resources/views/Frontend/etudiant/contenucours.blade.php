@include('Frontend.components.header')
@include('Frontend.components.menu')



<!-- PageBanner -->
<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content" style="height:10px">
            <h3> {{ $me->nom }} {{ $me->prenom }}</h3>
            <ol class="breadcrumb">
                <li><a href="index.html">Code matricule</a></li>
                <li>{{ $me->code }}</li>
                <li>Bienvenu</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->
<!-- Table des modules -->
<!-- Modal pour la vidéo -->
<div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="videoModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="videoModalLabel">Course Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="video-container mb-3">
                    <iframe id="courseVideo" width="100%" height="500" frameborder="0" allow="encrypted-media" allowfullscreen></iframe>
                </div>
                <p id="courseDescription"></p>
            </div>
        </div>
    </div>
</div>

<!-- Modal pour le document PDF -->
<div class="modal fade" id="pdfModal" tabindex="-1" role="dialog" aria-labelledby="pdfModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="pdfModalLabel">Document Title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="pdfViewer" class="pdf-container">
                    <iframe id="coursePdf" width="100%" height="600px" frameborder="0"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Table des modules -->
<div class="container coursesdetail-section">
    <div class="section-padding"></div>
    <div class="row">
        @include('Frontend.components.menuetudiant')

        <div class="col-md-9 col-sm-8 event-contentarea">
            <div class="courses-curriculum">
                <h3 class="course-title"> {{ $cours->titre }}</h3>

                <div class="courses-sections-block">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Titre</th>
                                <th>Video</th>
                                <th>Document</th>
                                <th>Heure</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($allmodule as $allmodules)
                                <tr>
                                    <td>{{ $allmodules->titre }}</td>
                                    <td>
                                        <a href="#" class="open-video-modal" 
                                           data-title="{{ $allmodules->titre }}" 
                                           data-description="{{ $allmodules->description }}" 
                                           data-url_video="{{ $allmodules->url_video }}" 
                                           title="{{ $allmodules->titre }}">
                                            <i class="fa fa-video-camera" aria-hidden="true"></i> Video
                                        </a>
                                    </td>
                                    <td>
                                        <a href="#" class="open-pdf-modal" 
                                           data-title="{{ $allmodules->titre }}" 
                                           data-url_pdf="{{ asset($allmodules->url_pdf) }}">
                                            <i class="fa fa-file-pdf-o" aria-hidden="true"></i> Document
                                        </a>
                                    </td>
                                    <td>{{ $allmodules->heure }} H</td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="text-center">
                                        <div class="alert alert-danger">
                                            <i class="fa fa-times-circle"></i>
                                            Pas de cours disponible pour cette faculté, revenez plus tard.
                                        </div>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Modal vidéo
        const videoModal = document.getElementById('videoModal');
        const videoModalLabel = document.getElementById('videoModalLabel');
        const courseVideo = document.getElementById('courseVideo');
        const courseDescription = document.getElementById('courseDescription');

        // Modal PDF
        const pdfModal = document.getElementById('pdfModal');
        const pdfModalLabel = document.getElementById('pdfModalLabel');
        const coursePdf = document.getElementById('coursePdf');

        // Ouvrir le modal vidéo
        document.querySelectorAll('.open-video-modal').forEach(courseLink => {
            courseLink.addEventListener('click', function(event) {
                event.preventDefault();

                const title = this.getAttribute('data-title');
                const description = this.getAttribute('data-description');
                const fullVideoUrl = this.getAttribute('data-url_video');

                // Mettre à jour les données dans la modale
                videoModalLabel.textContent = title;
                courseDescription.textContent = description;

                // Extraire l'ID de la vidéo YouTube
                const videoIdMatch = fullVideoUrl.match(/(?:https?:\/\/)?(?:www\.)?youtube\.com\/watch\?v=([a-zA-Z0-9_-]+)/);
                const videoId = videoIdMatch ? videoIdMatch[1] : null;

                if (videoId) {
                    const embedUrl = `https://www.youtube.com/embed/${videoId}?rel=0&modestbranding=1&controls=0&disablekb=1&fs=0`;
                    courseVideo.src = embedUrl;
                    courseVideo.parentNode.style.display = 'block';
                } else {
                    courseVideo.parentNode.style.display = 'none';
                }

                // Afficher la modale vidéo
                $('#videoModal').modal('show');
            });
        });

        // Ouvrir le modal PDF
        document.querySelectorAll('.open-pdf-modal').forEach(courseLink => {
            courseLink.addEventListener('click', function(event) {
                event.preventDefault();

                const title = this.getAttribute('data-title');
                const url_pdf = this.getAttribute('data-url_pdf');

                // Mettre à jour les données dans la modale
                pdfModalLabel.textContent = title;
                coursePdf.src = url_pdf;

                // Afficher la modale PDF
                $('#pdfModal').modal('show');
            });
        });

        // Nettoyer les sources vidéo et PDF lorsque les modales sont fermées
        $('#videoModal').on('hidden.bs.modal', function () {
            courseVideo.src = '';
        });

        $('#pdfModal').on('hidden.bs.modal', function () {
            coursePdf.src = '';
        });
    });
</script>





@include('Frontend.components.footer')
