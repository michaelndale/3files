@include('Frontend.components.header')
@include('Frontend.components.menu')
<!-- PageBanner -->
<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content" style="height:10px">
            <h3>Paiement</h3>
            <ol class="breadcrumb">
                <li><a href="index.html">Code matricule</a></li>
                <li>{{ $me->code }}</li>
                <li>Bienvenu</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->
<div class="container coursesdetail-section">
    <div class="section-padding"></div>
    <div class="row">
		
        @include('Frontend.components.menuetudiant')


        <div class="col-md-9 col-sm-8 event-contentarea">
            <div class="row">
                <div class="col-lg-12">
                    <div class="col-md-9">
                        <h3 class="course-title">Historique payement</h3>
                    </div>
                    <div class="col-md-3">
                        <button type="button" class="btn btn-primary" style="width:100%" data-toggle="modal" data-target="#paymentModal">
							<i class="fa fa-plus-circle"> </i> Faire un payement
						</button>
                    </div>
                </div>

				<div class="col-lg-12">
					@include('Backend.components.messagre')

					<div class="alert alert-info">
						<i class="fa fa-info-circle"></i> Le paiement est considéré comme validé quand le statut du ligne de payement est verifier par l'adminitration
					</div>

					<table class="table table-striped">
						<thead>
							<tr>
								<th>Date de Paiement</th>
								<th>Type de Paiement</th>
								<th>Montant</th>
								<th>Méthode de Paiement</th>
								<th>Numéro de Référence</th>
								<th>Description</th>
								<th>Statut</th> <!-- Added Statut column -->
							</tr>
						</thead>
						<tbody>
							@forelse ($payments as $payment)
								<tr>
									<td>{{ date('d-m-Y', strtotime($payment->payment_date)) }}</td>
									<td>{{ $payment->type_payement }}</td>
									<td style="width:10%" align='right'>{{ number_format($payment->amount, 0, ',', ' ') }}</td> <!-- Format du montant -->
									<td>{{ $payment->payment_method }}</td>
									<td>{{ $payment->reference_number }}</td>
									<td>{{ $payment->description }}</td>
									<td>
										@if ($payment->status == 1)
											<i class="fa fa-check-circle text-success"></i> <!-- Green success icon -->
										@else
											<i class="fa fa-times-circle text-danger" title="encours de verification" ></i> <!-- Red danger icon -->
										@endif
									</td>
								</tr>
							@empty
								<tr>
									<td colspan="7">Aucun paiement trouvé</td>
								</tr>
							@endforelse
						</tbody>
					</table>
					
					
				</div>

                <br><br>
            </div>
        </div>
    </div>
    <div class="section-padding"></div>
</div>

<!-- Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1" role="dialog" aria-labelledby="paymentModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="paymentModalLabel">Ajouter un paiement</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form method="POST" action="{{ route('payment.store') }}" id="paymentForm">
					@csrf
				
					<input type="hidden" value="{{ $me->idu }}" class="form-control" id="client_name" name="client_name" required>
					<input type="hidden" value="{{ $me->classe_id }}" class="form-control" id="class" name="class" required>
					<input type="hidden" value="{{ $me->annee_id}}" class="form-control" id="year" name="year" required>
				
					<div class="form-group">
						<label for="payment_type">Type de Paiement</label>
						<select class="form-control select" id="payment_type" name="payment_type">
							<option value="">Sélectionner</option>
							@forelse ($Facturation as $Facturations)
								<option value="{{ $Facturations->libelle }}" data-amount="{{ $Facturations->montant }}">
									{{ $Facturations->libelle }}
								</option>
							@empty
								<option value="">Aucun type de paiement disponible</option>
							@endforelse
						</select>
						<small id="payment_error" style="color: red; display: none;">Ce paiement a déjà été effectué .</small>
					</div>
				
					<div class="form-row">
						<div class="form-group col-md-6">
							<label for="amount">Montant</label>
							<input type="number" class="form-control" id="amount" name="amount" required readonly>
						</div>
						<div class="form-group col-md-6">
							<label for="payment_date">Date de Paiement</label>
							<input type="date" class="form-control" id="payment_date" name="payment_date" required>
						</div>
					</div>
				
					<div class="form-group">
						<label for="payment_method">Méthode de Paiement</label>
						<select class="form-control" id="payment_method" name="payment_method" required>
							<option value="">Sélectionner une méthode de paiement</option>
							<option value="Espèces">Espèces</option>
							<option value="Lumicash">Lumicash</option>
							<option value="Ecocash">Ecocash</option>
							<option value="Carte de Crédit">Carte de Crédit</option>
							<option value="Virement Bancaire">Virement Bancaire</option>
							<option value="paypal">PayPal</option>
							<option value="cheque">Chèque</option>
						</select>
					</div>
					
				
					<div class="form-group">
						<label for="reference_number">Numéro de Référence, code transaction</label>
						<input type="text" class="form-control" id="reference_number" name="reference_number" required>
						<small id="reference_error" style="color: red; display: none;">Le numéro de référence est déjà utilisé.</small>
					</div>
				
					<div class="form-group">
						<label for="description">Description</label>
						<textarea class="form-control" id="description" name="description" rows="3" ></textarea>
					</div>
				
					<button type="submit" class="btn btn-success">Enregistrer le paiement</button>
				</form>
				
			</div>
		</div>
	</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $(document).ready(function() {
        // Payment Type Selection
        $('#payment_type').change(function() {
            var clientName = $('#client_name').val();
            var year = $('#year').val();
            var paymentType = $(this).val();

            // Validate if clientName, year, and paymentType are selected
            if (clientName && year && paymentType) {
                $.ajax({
                    url: '{{ route('check.payment') }}',
                    method: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        client_name: clientName,
                        year: year,
                        payment_type: paymentType
                    },
                    success: function(response) {
                        if (response.exists) {
                            $('#payment_error').show();
                            $('button[type="submit"]').prop('disabled', true);
                        } else {
                            $('#payment_error').hide();
                            $('button[type="submit"]').prop('disabled', false);
                        }
                    }
                });
            }
        });

        // Reference Number Input Check
        $('#reference_number').on('input', function() {
            var reference = $(this).val();
            if (reference) {
                $.ajax({
                    url: '{{ route('check.reference') }}',
                    method: 'POST',
                    data: {
                        _token: '{{ csrf_token() }}',
                        reference_number: reference
                    },
                    success: function(response) {
                        if (response.exists) {
                            $('#reference_error').show();
                            $('button[type="submit"]').prop('disabled', true);
                        } else {
                            $('#reference_error').hide();
                            $('button[type="submit"]').prop('disabled', false);
                        }
                    }
                });
            } else {
                $('#reference_error').hide();
                $('button[type="submit"]').prop('disabled', false);
            }
        });

        // Update Amount Field on Payment Type Selection
        $('#payment_type').change(function() {
            var selectedOption = this.options[this.selectedIndex];
            var amount = selectedOption.getAttribute('data-amount');
            $('#amount').val(amount || '');
        });

        // Form Submission Block if Errors Exist
        $('#paymentForm').submit(function(event) {
            if ($('#payment_error').is(':visible') || $('#reference_error').is(':visible')) {
                event.preventDefault();
                alert('Veuillez résoudre les erreurs avant de soumettre.');
            }
        });
    });
</script>


@include('Frontend.components.footer')
