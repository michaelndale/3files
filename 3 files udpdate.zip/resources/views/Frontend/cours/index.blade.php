@include('Frontend.components.header')
@include('Frontend.components.menu')
<style>
    .pagebanner 
    {
        background-color: black;
    }
</style>

<div class="container-fluid no-padding pagebanner">
    <div class="container" >
        <div class="pagebanner-content">
            <h3>Nos Cours</h3>
            <ol class="breadcrumb">
                <li><a href="/">Accueil</a></li>
                <li>Nos cours</li>
            </ol>
        </div>
    </div>
</div>

<!-- PageBanner /- -->

<div class="container-fluid no-padding contactus-section">
    <div class="contactdetail-block">
        <div class="container">
            @forelse ($cours as $cour)
                <div class="col-md-3 col-sm-3 col-xs-6 contactinfo-box">
                    <span class="icon icon-File"></span>
                    <h3> {{ $cour->titre }}</h3>
                    <p> {{ $cour->description }} </p>
                    <a href="#" title="{{ $cour->titre }}">Volume : {{ $cour->volume }} H </a>
                </div>
            @empty
                
            @endforelse
         
        </div>
    </div>
</div>
<!-- ContactUs Section /- -->	

	
	
@include('Frontend.components.footer')
