@include('Frontend.components.header')
@include('Frontend.components.menu')

<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content">
            <h3>Nous Contactez</h3>
            <ol class="breadcrumb">
                <li><a href="/">Accueil</a></li>
                <li>Nous contactez</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->

<div class="container-fluid no-padding contactus-section">
    <div class="container">
        <div class="section-padding"></div>
        <div class="row">
            <div class="col-md-6">
                <div class="map">
                    <div class="map">
                        <div id="map-canvas-contact" class="map-canvas" 
                             data-lat="-3.3794" 
                             data-lng="29.9182" 
                             data-string="Ngagara, Bujumbura, Burundi" 
                             data-zoom="12"></div>
                    </div>
                    
                </div>
                
            </div>
            <div class="col-md-6">
                <div class="getintouch">
                    <h3>Contactez-nous </h3>
                    <p>Que vous ayez besoin d'informations sur nos services, d'une assistance technique, ou que vous souhaitiez simplement en savoir plus sur ce que nous offrons, notre équipe est à votre écoute. Votre satisfaction est notre priorité.</p>
            <p>Vous pouvez nous joindre par téléphone, par email ou via notre formulaire de contact. Nous faisons de notre mieux pour répondre à toutes vos demandes dans les plus brefs délais.</p>
            <p>Suivez-nous également sur nos réseaux sociaux pour rester informé des dernières nouveautés et pour entrer en contact avec notre communauté.</p>
                    
            <form class="contactus-form" id="contact-form" method="POST" action="/send-message">
                @csrf <!-- Si vous utilisez Laravel, pour la protection CSRF -->
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <input type="text" required="" placeholder="Nom" id="input_name" class="form-control" name="contact-name">
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <input type="email" required="" placeholder="Email" id="input_email" class="form-control" name="contact-email">
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <textarea placeholder="Message" id="textarea_message" class="form-control" name="contact-message" rows="5"></textarea>
                        </div>
                    </div>  
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <input type="submit" name="post" title="Envoyer" id="btn_submit" value="Envoyer">
                        </div>
                    </div>
                    <div class="alert-msg" id="alert-msg"></div>
                </div>
            </form>
            


                </div>
            </div>
        </div>
        <div class="section-padding"></div>
    </div>
    <div class="contactdetail-block">
        <div class="container">
            <div class="col-md-3 col-sm-3 col-xs-6 contactinfo-box">
                <span class="icon icon-Pointer"></span>
                <h3>Where We Are?</h3>
                <p>2901 Marmora road, Glassgow, Seattle, WA 98122</p>
                <a href="#" title="MORE ABOUT US ">MORE ABOUT US </a>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6 contactinfo-box">
                <span class="icon icon-Phone2"></span>
                <h3>Give us a Call</h3>
                <p>Consectetuer ux adipis cing elit sed dolor sit amet.</p>
                <a href="tel:+4301234321243" title="+4301234321243">+43 (0) 123 432 12 43</a>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6 contactinfo-box">
                <span class="icon icon-Printer"></span>
                <h3>Vist Our Office</h3>
                <p>Consectetuer ux adipis cing elit sed dolor sit amet.</p>
                <a href="#" title="Get Direction">Get Direction</a>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6 contactinfo-box">
                <span class="icon icon-Imbox"></span>
                <h3>Drop us a Line</h3>
                <p>Consectetuer ux adipis cing elit sed dolor sit amet.</p>
                <a href="mailto:Support@EduMax.Com" title="Support@EduMax.Com">Support@EduMax.Com</a>
            </div>
        </div>
    </div>
</div><!-- ContactUs Section /- -->	

<!-- Inclure l'API Google Maps -->
<script src="https://maps.googleapis.com/maps/api/js?key=VOTRE_CLÉ_API&callback=initMap" async defer></script>

<!-- Inclure l'API Google Maps -->
<script src="https://maps.googleapis.com/maps/api/js?key=VOTRE_CLÉ_API&callback=initMap" async defer></script>

<script>
    function initMap() {
        var lat = document.getElementById('map-canvas-contact').getAttribute('data-lat');
        var lng = document.getElementById('map-canvas-contact').getAttribute('data-lng');
        var zoom = document.getElementById('map-canvas-contact').getAttribute('data-zoom');

        var location = { lat: parseFloat(lat), lng: parseFloat(lng) };

        var map = new google.maps.Map(document.getElementById('map-canvas-contact'), {
            zoom: parseInt(zoom),
            center: location
        });

        var marker = new google.maps.Marker({
            position: location,
            map: map,
            title: 'Ngagara, Bujumbura, Burundi'
        });
    }
</script>




<script>
    $(document).ready(function() {
        $("#contact-form").submit(function(e) {
            e.preventDefault(); // Empêche l'envoi du formulaire classique

            // Récupérer les données du formulaire
            var formData = $(this).serialize();

            // Afficher un message de chargement
            $('#alert-msg').html('<div class="alert alert-info">Envoi en cours...</div>');

            // Envoi des données via AJAX
            $.ajax({
                type: "POST",
                url: $(this).attr('action'),  // Utilise l'URL de l'action (dans le formulaire)
                data: formData,
                success: function(response) {
                    if (response.success) {
                        // Afficher un message de succès
                        $('#alert-msg').html('<div class="alert alert-success">' + response.message + '</div>');
                    } else {
                        // Afficher un message d'erreur
                        $('#alert-msg').html('<div class="alert alert-danger">' + response.message + '</div>');
                    }
                },
                error: function() {
                    // Afficher un message d'erreur si la requête échoue
                    $('#alert-msg').html('<div class="alert alert-danger">Erreur lors de l\'envoi du message. Essayez à nouveau plus tard.</div>');
                }
            });
        });
    });
</script>


	
	
@include('Frontend.components.footer')
