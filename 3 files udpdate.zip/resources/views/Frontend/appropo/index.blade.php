@include('Frontend.components.header')
@include('Frontend.components.menu')

<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content">
            <h3>A Propos</h3>
            <ol class="breadcrumb">
                <li><a href="/">Accueil</a></li>
                <li>A Propos</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->


<div class="container coursesdetail-section">
    <div class="section-padding"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 event-contentarea">
                <div class="coursesdetail-block">
                    <img src="images/event-coursesdetail.jpg" alt="event-coursesdetail" width="860" height="500"/>
                    <div class="course-description">
                        <h3 class="course-title">Courses Description</h3>
                        <p>Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit.Sed non mauris vitae erat consequat auctor eu in elit. Class aptent taciti.Neque porro quisquam est qui dolorem ipsum quia dolor sit amet consectetur adipisci velit sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam quis nostrum exercitationem ullam corporis suscipit.</p>
                        <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi id est laborum et dolorum fuga.</p>
                    </div>
                   
                    
                </div>
                
            </div>
           
        </div>
    <div class="section-padding"></div>
</div>

	
	
@include('Frontend.components.footer')
