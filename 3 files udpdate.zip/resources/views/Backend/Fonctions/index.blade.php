@include('Backend.components.header');
<!-- Plugins css -->

@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

<div class="col-6" style="margin:auto">
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-8">
                    <h4 class="card-title"><i class="fa fa-list"></i> Fonctions</h4>
                </div>
                <div class="col-lg-4">
                    <div class="text-lg-right mt-3 mt-lg-0">
                        <a href="{{ route('nouvelle.fonction') }}" class="btn btn-primary">
                            <i class="mdi mdi-plus-circle mr-1"></i> Nouvelle fonction
                        </a>
                    </div>
                </div><!-- end col-->
            </div> <!-- end row -->
            <br>
            <table class="table table-striped dt-responsive nowrap">
                <thead>
                    <tr>
                        <th>Titre</th>
                        <th>Créé le</th>
                        <th style="width:10%">Actions</th>
                    </tr>
                </thead>


                <tbody>
                    @forelse ($allfonction as $allfonctions)
                        <tr>

                            <td>{{ $allfonctions->titre }} </td>
                            <td>{{ date('d/m/Y', strtotime($allfonctions->created_at)) }}


                            <td>

                                <div class="btn-group" role="group" aria-label="Button group with nested dropdown">

                                    <div class="btn-group btn-group-sm" role="group">
                                        <button id="btnGroupDrop1" type="button"
                                            class="btn btn-outline-secondary dropdown-toggle " data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            Options <i class="mdi mdi-chevron-down"></i>
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                            <!--  <a class="dropdown-item" href="#"><i class="fas fa-eye "></i> Voir</a>
                                                    <a class="dropdown-item" href="#"><i class="fa fa-edit "></i> Mofifier</a> -->

                                            <form action="{{ route('deletefonction', $allfonctions->id) }}"
                                                method="post">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="dropdown-item"
                                                    title="Supprimer le fonction"
                                                    style="background-color:red;color:white"><i
                                                        class="fas fa-trash-alt "></i> Supprimer
                                            </form>

                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    @empty
                        la liste des fonction est vide
                    @endforelse
                </tbody>
            </table>
        </div> <!-- end card body-->
    </div> <!-- end card -->
</div>


@include('Backend.components.footer')

