<div class="modal fade" id="etudiantModale" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">

        <form class="needs-validation" novalidate action="{{ route('saveetudiantinterne')}}" method="POST">
            @csrf

            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i> Ajouter Etudiant</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <div class="row">

                        <div class="col-md-6 mb-12">
                            <label for="validationTooltip01">Nom </label>
                            <input type="text" name="nom" class="form-control" id="validationTooltip01"  value="{{ old('nom') }}" placeholder="Nom" required>
                            <div class="invalid-tooltip">
                                Veuillez entrer le Nom.
                            </div>
                        </div>

                        <div class="col-md-6 mb-12">
                            <label for="validationTooltip02">Prenom</label>
                            <input type="text" name="prenom" class="form-control" id="validationTooltip02"  value="{{ old('prenom') }}" placeholder="Premon" required>
                            <div class="invalid-tooltip">
                                Veuillez entrer le Prenom.
                            </div>
                        </div>

                        <div class="col-md-6 mb-12">
                            <label for="validationTooltip02">Genre</label>
                            <select type="text" name="genre" class="form-control" id="validationTooltip02" placeholder="Prenom" required>
                                <option value="" selected disabled>Choisie le genre</option>
                                <option value="Homme"> Homme </option>
                                <option value="Femme"> Femme </option>

                            </select>
                            <div class="invalid-tooltip">
                                Veuillez entrer le genre.
                            </div>
                        </div>

                        <div class="col-md-6 mb-12">
                            <label for="validationTooltip02">Date de naissance</label>
                            <input type="date" name="datenaissance" value="{{ old('datenaissance') }}" class="form-control" id="validationTooltip02" placeholder="Date de naissance" required>
                            <div class="invalid-tooltip">
                                Veuillez entrer la Date de naissance
                            </div>
                        </div>

                        <div class="col-md-12 mb-12">
                            <label for="validationTooltip02">Adresse</label>
                            <input type="text" name="adresse" value="{{ old('adresse') }}" class="form-control" id="validationTooltip02" placeholder="Adresse" required>
                            <div class="invalid-tooltip">
                                Veuillez entrer le Adresse.
                            </div>
                        </div>

                        <div class="col-md-6 mb-12">
                            <label for="validationTooltip02">Pays Origine</label>
                            <!--<input type="text" name="nationalite" class="form-control" id="validationTooltip02" placeholder="Pays Origine"  required>-->

                            <div class="invalid-tooltip">
                                Veuillez entrer le Pays Origine.
                            </div>
                            @include('Backend.components.pays')
                            <!--<input type="text" name="nationalite" class="form-control" id="validationTooltip02" placeholder="Pays Origine"  required>-->
                        </div>

                        <div class="col-md-6 mb-12">
                            <label for="validationTooltip02">Telephone</label>
                            <input type="text" name="tel"  value="{{ old('tel') }}" class="form-control" id="validationTooltip02" placeholder="Telephone" required>
                            <div class="invalid-tooltip">
                                Veuillez entrer le telephone.
                            </div>
                        </div>

                        <div class="col-md-12 mb-12">
                            <label for="validationTooltip02">Email</label>
                            <input type="text" name="email"  value="{{ old('email') }}" class="form-control" id="validationTooltip02" placeholder="Email" required>
                            <div class="invalid-tooltip">
                                Veuillez entrer le email.
                            </div>
                        </div>

                        <div class="col-md-12 mb-12">
                            <label for="validationTooltip02">Mot de passe</label>
                            <input type="text" name="password"  value="{{   $generatepassword }}" class="form-control" id="validationTooltip02" placeholder="Mot de passe" required readonly>
                           
                        </div>

                      

                        <div class="col-md-6 mb-12">
                            <label for="validationTooltip02">Date d'inscription</label>
                            <input type="date" name="date_enr"  value="{{ old('date_enr') }}" class="form-control" id="validationTooltip02" placeholder="Date d'inscription" required>
                            <div class="invalid-tooltip">
                                Veuillez entrer Date d'inscription
                            </div>
                        </div>

                        <div class="col-md-6 mb-12">
                            <label for="validationTooltip02">Annee scolaire</label>
                            <input type="text" class="form-control form-control-user" id="validationTooltip04" value="Anne scolaire: {{ $anneScolaire->libelle }}" required readonly>
                            <input type="hidden" name="annee_id" value="{{ $anneScolaire->id }}" />
                            <div class="invalid-tooltip">
                                Veuillez entrer le genre.
                            </div>
                        </div>

                        <div class="col-md-6 mb-12">
                            <label for="faculteid">Facultes</label>
                            <select name="faculte_id" class="form-control" id="faculteid" required onchange="fetchClasses()">
                                <option value="" selected disabled>Choisie la faculte</option>
                                @forelse ($faculte as $facultes)
                                <option value="{{ $facultes->id }}"> {{ $facultes->libelle }} </option>
                                @empty
                                <option disabled>La liste est vide</option>
                                @endforelse
                            </select>
                        </div>

                        <div class="col-md-6 mb-12">
                            <label for="classeid">Classes</label>
                            <select name="classe_id" class="form-control" id="classeid" required>
                                <option value="" selected disabled>Choisie la classe</option>
                            </select>
                        </div>

                    </div>

                </div>


                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>
                    <button class="btn btn-primary" name="saveData" type="submit">Enregistrer</button>
                </div>
            </div>
        </form>


    </div>
</div>


<script>
    function fetchClasses() {
        const faculteId = document.getElementById('faculteid').value;
        const classeSelect = document.getElementById('classeid');
        classeSelect.innerHTML = '<option value="" selected disabled>Chargement...</option>'; // Show loading option

        // Generate the route URL using Blade syntax
        const url = '{{ route("getFaculteClasse") }}?faculte_id=' + faculteId;

        fetch(url)
            .then(response => response.json())
            .then(data => {
                classeSelect.innerHTML = '<option value="" selected disabled>Choisie la classe</option>'; // Reset options

                if (data.length === 0) {
                    classeSelect.innerHTML += '<option disabled>Aucune classe disponible</option>'; // No classes available
                } else {
                    data.forEach(classe => {
                        classeSelect.innerHTML += `<option value="${classe.id}">${classe.libelle}</option>`;
                    });
                }
            })
            .catch(error => {
                console.error('Error fetching classes:', error);
                classeSelect.innerHTML = '<option disabled>Error loading classes</option>'; // Show error
            });
    }
</script>

<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>