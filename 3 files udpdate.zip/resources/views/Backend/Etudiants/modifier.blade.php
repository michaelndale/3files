@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

@if (session()->has('success'))
 <div class="col-lg-9">
    <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
 </div>
@endif

<div class="col-xl-4 col-lg-5">
    <div class="card">
        <div class="card-body">
            <form class="contactus-form" novalidate action="{{ route('save.image.etudiant', $Etudiants->idu )}}" method="POST" enctype="multipart/form-data">
                @csrf
            <h4 class="card-title"><i class="fa fa-user-edit"></i> Mon profile</h4>
            <div class="row">

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <center>
                        <img src="{{ asset($Etudiants->photos) }}" alt="staff" width="275" class="img-fluid rounded-circle" width="120" height="288" /> 
                        <br><br>
                        <input  type="file" name="photopassport" required accept=".png, .jpg, .jpeg" class="form-control" id="photopassport">
                        <div class="invalid-feedback" id="photoFeedback" style="color: red;">

                        </div>
                    </center>
                    </div>
                </div>

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <input class="btn btn-primary"  type="submit" name="post" title="Send" value="Envoyer photo" id="submitButton" >
                    </div>
                </div>
                <div class="alert-msg" id="alert-msg"></div>
            </div>
            </form>
        </div>
    </div>
</div>

<div class="col-5" >
<div class="card">
    <div class="card-body">
        <h4 class="card-title"><i class="fa fa-edit"></i> Modifier Etudiant </h4>

    <form class="needs-validation" novalidate action="{{ route('update.etudiant',$Etudiants->idu )}}" method="POST">
            @csrf
            @method('PUT')
        
            <div class="form-row">
            <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Nom </label>
                    
                    <input type="text" name="nom" class="form-control" id="validationTooltip01" placeholder="Nom" value="{{ $Etudiants->nom }}" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le Nom.
                        </div>
                </div>
               
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Prenom</label>
                    <input type="text" name="prenom" class="form-control" id="validationTooltip02" placeholder="Premon" value="{{ $Etudiants->prenom }}" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le Prenom.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Genre</label>
                    <select type="text" name="genre" class="form-control" id="validationTooltip02" placeholder="Prenom"  required>
                        <option  value= "{{ $Etudiants->sexe }}">{{ $Etudiants->sexe }}</option>
                        <option value="Homme"> Homme </option>
                        <option value="Femme"> Femme </option>
                        <option value="Transgenre"> Transgenre </option>
                        <option value="Autres"> Autres   </option>
                    </select>
                    <div class="invalid-tooltip">
                            Veuillez entrer le genre.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Date de naissance</label>
                    <input type="date" name="datenaissance" class="form-control" id="validationTooltip02" placeholder="Date de naissance" value="{{ $Etudiants->dateNais}}" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer la Date de naissance
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Adresse</label>
                    <input type="text" name="adresse" class="form-control" id="validationTooltip02" placeholder="Adresse" value="{{ $Etudiants->adresse }}" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le Adresse.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Pays Origine</label>
                    <input type="text" name="nationalite" class="form-control" id="validationTooltip02" placeholder="Pays Origine" value="{{ $Etudiants->nationalite }}" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le Pays Origine.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Telephone</label>
                    <input type="number" name="tel" class="form-control" id="validationTooltip02" placeholder="Telephone" value="{{ $Etudiants->tel }}" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le telephone.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Email</label>
                    <input type="text" name="email" class="form-control" id="validationTooltip02" placeholder="Email" value="{{ $Etudiants->email }}" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le email.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Date d'inscription</label>
                    <input type="date" name="date_enr" class="form-control" id="validationTooltip02" placeholder="Date d'inscription" value="{{ $Etudiants->dateEnregitre }}" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer Date d'inscription
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Statut</label>
                    <select type="text" name="statut" class="form-control" id="validationTooltip02" placeholder="Prenom"  required>
                        <option  value= "{{ $Etudiants->status }}">{{ $Etudiants->status }}</option>
                        <option value="ACTIF"> ACTIF </option>
                        <option value="INACTIF"> INACTIF </option>
                    </select>
                    <div class="invalid-tooltip">
                            Veuillez entrer le genre.
                        </div>
                </div>

            </div>
           
           
            <div class="modal-footer">
                <button class="btn btn-primary" name="saveData"  type="submit">Enregistrer</button>
            </div>
        </div>
    </form>


    </div>
</div>
















<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>

@include('Backend.components.footer')
<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>