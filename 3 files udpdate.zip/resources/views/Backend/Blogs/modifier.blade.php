@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

<div class="col-12" style="margin:auto">
    @if (session()->has('success'))
        <div class="col-lg-12">
            <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
        </div>
    @endif
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <!-- Display Exception Errors -->
    @if ($errors->has('exception'))
        <div class="alert alert-danger">
            <strong>{{ $errors->first('exception') }}</strong>
        </div>
    @endif

    <div class="card">
        <div class="card-body">
            <h4 class="card-title"><i class="fa fa-edit"></i> Modifier le Blog</h4>

            <form class="needs-validation" novalidate action="{{ route('update.blog', $blog->id) }}" method="POST"
                enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="form-row">
                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip01">Titre </label>
                        <input type="text" name="titre" class="form-control" value="{{ $blog->titre }}"
                            id="validationTooltip01" placeholder="Titre" required>
                        <div class="invalid-tooltip">
                            Veuillez entrer le Titre.
                        </div>
                    </div>

                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip01">Courte description </label>
                        <textarea type="text" name="courte" class="form-control" id="validationTooltip01" maxlength="255"
                            placeholder="Courte" required> {{ $blog->courte }} </textarea>
                        <div class="invalid-tooltip">
                            Veuillez entrer la courte Description.
                        </div>
                    </div>


                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip01">Description </label>
                        <textarea type="text" name="description" class="form-control" id="validationTooltip01" placeholder="description"
                            required style="height:250px">  {{ $blog->description }} </textarea>
                        <div class="invalid-tooltip">
                            Veuillez entrer la Description.
                        </div>
                    </div>

                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip01">Couvertire </label>
                        <input type="file" name="photo" class="form-control" accept="image/*">
                        <input type="hidden" name="oldImage" value="{{ $blog->photo }}" />
                    </div>
                </div>
                <br>
                <button class="btn btn-primary" name="saveData" type="submit">Enregistrer</button>
            </form>
        </div> <!-- end card-body-->
    </div> <!-- end card -->
</div>

@include('Backend.components.footer')
<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js') }}"></script>
