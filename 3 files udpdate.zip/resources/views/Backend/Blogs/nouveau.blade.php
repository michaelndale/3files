@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')
<div class="col-12" style="margin:auto">

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<!-- Display Exception Errors -->
@if ($errors->has('exception'))
    <div class="alert alert-danger">
        <strong>{{ $errors->first('exception') }}</strong>
    </div>
@endif

<div class="card">
    <div class="card-body">
        <h4 class="card-title"><i class="fa fa-edit"></i> Nouveau Blog</h4>
      
        <form class="needs-validation" novalidate action="{{ route('save.blog')}}" method="POST" enctype="multipart/form-data">
            @csrf
            
            <div class="form-row">
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Titre </label>
                    <input type="text" name="titre" class="form-control" id="validationTooltip01" placeholder="Titre" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le Titre.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Courte description </label>
                    <textarea type="text" name="courte" class="form-control" id="validationTooltip01" maxlength="255" placeholder="Courte" required> </textarea>
                    <div class="invalid-tooltip">
                            Veuillez entrer la courte Description.
                        </div>
                </div>


                <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Description </label>
                    <textarea type="text" name="description" class="form-control" id="validationTooltip01" placeholder="description" required style="height:250px"> </textarea>
                    <div class="invalid-tooltip">
                            Veuillez entrer la Description.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Couvertise </label>
                    <input type="file" name="photo" class="form-control" id="validationTooltip01" placeholder="Titre" accept="image/*" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le couverture.
                        </div>
                        
                </div>
             



            </div>
         
            <br>
            <button class="btn btn-primary" name="saveData"  type="submit">Enregistrer</button>
        </form>

    </div> <!-- end card-body-->
</div> <!-- end card -->
</div>

@include('Backend.components.footer')
<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>