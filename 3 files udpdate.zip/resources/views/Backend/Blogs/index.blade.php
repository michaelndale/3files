@include('Backend.components.header');
<!-- Plugins css -->
<link href="{{ asset('backend/plugins/datatables/dataTables.bootstrap4.css') }}')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/responsive.bootstrap4.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/buttons.bootstrap4.css') }}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/select.bootstrap4.css') }}" rel="stylesheet" type="text/css" />

@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

@if (session()->has('success'))
    <div class="col-lg-12">
        <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
    </div>
@endif


<div class="col-12">
    <div class="card">
        <div class="card-body">
            <div class="row">
            <div class="col-lg-6">
                <h4 class="card-title"><i class="feather-message-square"></i>
                    Liste du blogs</h4>
            </div>
         
            <div class="col-lg-6">
                <div class="text-lg-right mt-3 mt-lg-0">
                    <a href="{{ route('nouveau.blog') }}" class="btn btn-primary" >
                        <i class="mdi mdi-plus-circle mr-1"></i> Nouveau 
                    </a>
                </div>
            </div><!-- end col-->
      
        </div> <!-- end row -->
<br>
            



            @if ($allBlog->count() > 0)
                <table class="table table-striped dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>Titre</th>
                            <th>Prenom </th>
                            <th>Creer le</th>
                            <th style="width:10%">Actions</th>
                        </tr>
                    </thead>


                    <tbody>
                        @forelse ($allBlog as $allBlogs)
                            <tr>

                                <td>{{ $allBlogs->titre }}</td>
                                <td>{{ $allBlogs->nom }} {{ $allBlogs->prenom }} </td>
                              
                                <td>{{ date('d-m-Y', strtotime($allBlogs->updated_at)) }} </td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <button id="btnGroupDrop1" type="button"
                                            class="btn btn-outline-secondary dropdown-toggle " data-toggle="dropdown"
                                            aria-haspopup="true" aria-expanded="false">
                                            Options <i class="mdi mdi-chevron-down"></i>
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                            <a class="dropdown-item" href="#"><i class="fas fa-eye "></i> Voir</a>
                                            <a class="dropdown-item" href="{{ route('edit.blog', $allBlogs->id) }}"><i
                                                    class="fa fa-edit "></i> Modifier</a>

                                            <form action="{{ route('deleteblog', $allBlogs->id) }}" method="post">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="dropdown-item"
                                                    title="Supprimer l'etudiant"
                                                    style="background-color:red;color:white"><i
                                                        class="fas fa-trash-alt "></i> Supprimer
                                            </form>

                                        </div>
                                    </div>

                                    
                                </td>


                            </tr>
                        @empty

                            <div class="col-lg-12">
                                <div class="alert alert-danger"> <i class="fa fa-times-circle"></i> la liste des blog
                                    est vide
                                </div>
                            </div>
                        @endforelse




                    </tbody>
                </table>
            @else
                <div class="col-lg-12">
                    <div class="alert alert-danger"> <i class="fa fa-times-circle"></i> la liste des blog est vide
                    </div>
                </div>
            @endif
        </div> <!-- end card body-->
    </div> <!-- end card -->
</div>

@include('Backend.components.footer')
<script src="{{ asset('backend/plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/dataTables.bootstrap4.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/responsive.bootstrap4.min.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/dataTables.buttons.min.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/buttons.bootstrap4.min.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/buttons.html5.min.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/buttons.flash.min.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/buttons.print.min.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/dataTables.keyTable.min.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/dataTables.select.min.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/pdfmake.min.js') }}"></script>
<script src="{{ asset('backend/plugins/datatables/vfs_fonts.js') }}"></script>
<script src="{{ asset('backend/pages/datatables-demo.js') }}"></script>
