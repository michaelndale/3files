@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

    <div class="col-3">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><i class="fa fa-user"></i> Image profile </h4>
                <center>
                    <img src="{{ asset( $user->photo) }}" alt="table-user" class="img-fluid rounded-circle" width="210" >
                </center>
               
            </div>
        </div>
    </div>


    <div class="col-6">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><i class="fa fa-info-circle"></i> Detail Personnel </h4>


                <div class="form-row">

                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip01">Matricule : </label>
                        {{ $user->code }}
                    </div>


                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip01">Nom : </label>
                        {{ $user->nomp }}
                    </div>

                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip02">Prenom : </label>
                        {{ $user->prenom }}

                    </div>

                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip02">Genre :</label>
                        {{ $user->sexe }}

                    </div>



                    <div class="col-md-12 mb-12">
                        <label for="validationTooltipUsername">Email :</label>
                      
                            {{ $user->email }}
                    
                    </div>


                </div>
                <div class="form-row">
                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip03">Telephone :</label>
                        {{ $user->tel }}
                    </div>

                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip02">Fonction :</label>
                        {{ $user->titreFonction }}
                    </div>

                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip02">Statut :</label>
                        {{ $user->status }}

                    </div>

                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip02">Biographie:</label>
                        {{ $user->bio }}
                    </div>





                </div>


            </div>
        </div>
    </div>
</div>

<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>

@include('Backend.components.footer')
<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>