@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')
<div class="col-6" style="margin:auto">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title"><i class="fa fa-user-plus"></i> Nouveau personnel</h4>



            <form class="needs-validation" novalidate action="{{ route('save.personnel')}}" method="POST">
                @csrf
                
                <div class="form-row">
                    <div class="col-md-12 mb-12">
                        <label for="validationTooltipNom">Nom</label>
                        <input type="text" name="nom" class="form-control" id="validationTooltipNom" placeholder="Nom" required autocomplete="off">
                        <div class="invalid-tooltip">
                            Veuillez entrer le nom.
                        </div>
                    </div>
                   
                    <div class="col-md-12 mb-12">
                        <label for="validationTooltipPrenom">Prénom</label>
                        <input type="text" name="prenom" class="form-control" id="validationTooltipPrenom" placeholder="Prénom" required autocomplete="off">
                        <div class="invalid-tooltip">
                            Veuillez entrer le prénom.
                        </div>
                    </div>
            
                    <div class="col-md-6 mb-12">
                        <label for="validationTooltipGenre">Genre</label>
                        <select name="genre" class="form-control" id="validationTooltipGenre" required>
                            <option value="" selected disabled>Choisissez le genre</option>
                            <option value="Homme">Homme</option>
                            <option value="Femme">Femme</option>
                        </select>
                        <div class="invalid-tooltip">
                            Veuillez entrer le genre.
                        </div>
                    </div>
                    <div class="col-md-6 mb-12">
                        <label for="validationTooltipTelephone">Téléphone</label>
                        <input type="text" name="tel" class="form-control" id="validationTooltipTelephone" placeholder="Téléphone" required autocomplete="off">
                        <div class="invalid-tooltip">
                            Veuillez entrer le numéro de téléphone.
                        </div>
                    </div>
            
                    <div class="col-md-6 mb-12">
                        <label for="validationTooltipEmail">Email</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="validationTooltipEmailPrepend">@</span>
                            </div>
                            <input type="email" name="email" class="form-control" id="validationTooltipEmail" placeholder="Email" aria-describedby="validationTooltipEmailPrepend" required autocomplete="new-email">
                            <div class="invalid-tooltip">
                                Veuillez entrer un email correct.
                            </div>
                        </div>
                    </div>
            
                    <div class="col-md-6 mb-12">
                        <label for="validationTooltipPassword">Mot de Passe</label>
                        <input type="password" name="password" class="form-control" id="validationTooltipPassword" placeholder="Mot de Passe" required autocomplete="new-password">
                        <div class="invalid-tooltip">
                            Veuillez entrer le mot de passe.
                        </div>
                    </div>
                </div>
            
                <div class="form-row">
                    
            
                    <div class="col-md-12 mb-12">
                        <label for="validationTooltipFonction">Fonction</label>
                        <select name="fonction" class="form-control" id="validationTooltipFonction" required>
                            <option value="" selected disabled>Choisissez la fonction</option>
                            @forelse ($fonction as $fonctions)
                                @if ($fonctions->titre !== 'ETUDIANT')
                                    <option value="{{ $fonctions->id }}"> {{ $fonctions->titre }} </option>
                                @endif
                            @empty
                                <option>Aucune fonction disponible</option>
                            @endforelse
                            </select>
                        <div class="invalid-tooltip">
                            Veuillez choisir la fonction.
                        </div>
                    </div>
                </div>
                <br>
                <button class="btn btn-primary" name="saveData" type="submit">Enregistrer</button>
            </form>
            


        </div> <!-- end card-body-->
    </div> <!-- end card -->
</div>


<script>
    document.addEventListener("DOMContentLoaded", function() {
        document.getElementById("validationTooltip01").focus();
    });
</script>

@include('Backend.components.footer')
<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js') }}"></script>
