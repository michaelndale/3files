@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

@if (session()->has('success'))
<div class="col-lg-12">
    <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }}
    </div>
</div>
@endif


    <div class="col-xl-4 col-lg-5">
        <div class="card">
            <div class="card-body">
                <form class="contactus-form" novalidate action="{{ route('save.image.etudiant', Auth::user()->id )}}" method="POST" enctype="multipart/form-data">
                    @csrf
                <h4 class="card-title"><i class="fa fa-edit"></i> Mon profile</h4>
                <div class="row">

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <center>
                            <img src="{{ asset(Auth::user()->photo) }}" alt="staff" width="275" class="img-fluid rounded-circle" width="120" height="288" /> 
                            <br><br>
                            <input  type="file" name="photopassport" required accept=".png, .jpg, .jpeg" class="form-control" id="photopassport">
                            <div class="invalid-feedback" id="photoFeedback" style="color: red;">

                            </div>
                        </center>
                        </div>
                    </div>

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <input class="btn btn-primary"  type="submit" name="post" title="Send" value="Envoyer photo" id="submitButton" >
                        </div>
                    </div>
                    <div class="alert-msg" id="alert-msg"></div>
                </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-xl-6" >
       

        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><i class="fa fa-user-edit"></i> Mon details sur l'utilisateur</h4>

                <form class="needs-validation" novalidate action="{{ route('update.personnel', $user->idu) }}"
                    method="POST">
                    @csrf
                    @method('PUT')
                    <div class="form-row">
                        <div class="col-md-12 mb-12">
                            <label for="validationTooltip01">Nom </label>
                            <input type="text" name="nom" class="form-control" id="validationTooltip01"
                                placeholder="Nom" value="{{ $user->nomp }}" required>
                            <div class="invalid-tooltip">
                                Veuillez entrer le nom.
                            </div>
                        </div>

                        <div class="col-md-12 mb-12">
                            <label for="validationTooltip02">Prenom</label>
                            <input type="text" name="prenom" class="form-control" id="validationTooltip02"
                                placeholder="Prenom" value="{{ $user->prenom }}" required>
                            <div class="invalid-tooltip">
                                Veuillez entrer le prenom.
                            </div>
                        </div>

                        <div class="col-md-12 mb-12">
                            <label for="validationTooltip02">Genre</label>
                            <select type="text" name="genre" class="form-control" id="validationTooltip02"
                                placeholder="Prenom" required>
                                <option value="{{ $user->sexe }}">{{ $user->sexe }}</option>
                                <option value="Homme"> Homme </option>
                                <option value="Femme"> Femme </option>

                            </select>
                            <div class="invalid-tooltip">
                                Veuillez entrer le genre.
                            </div>
                        </div>



                        <div class="col-md-12 mb-12">
                            <label for="validationTooltipUsername">Email</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="validationTooltipUsernamePrepend">@</span>
                                </div>
                                <input type="email" name="email" class="form-control" id="validationTooltipUsername"
                                    placeholder="Email"
                                    aria-describedby="validationTooltipUsernamePrepend"value="{{ $user->email }}"
                                    required>
                                <div class="invalid-tooltip">
                                    Veuillez entrere l'email corret
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="form-row">
                        <div class="col-md-12 mb-12">
                            <label for="validationTooltip03">Telephone</label>
                            <input type="text" name="tel" class="form-control" id="validationTooltip03"
                                placeholder="Telephone" value="{{ $user->tel }}" required>
                            <div class="invalid-tooltip">
                                Veuillez entrer le numero de telephone.
                            </div>
                        </div>

                        <input type="hidden" name="fonction" value="{{ $user->idfonction }}" />
                        <input type="hidden" name="statut" value="{{ $user->status }}" />






                    </div>
                    <br>

                    <button class="btn btn-primary" name="saveData" type="submit">Enregistrer</button>
                </form>

            </div>
        </div>
    </div>

</div>



<script>
    const fileInputs = document.querySelectorAll('input[type="file"]');
    const maxSize = 2 * 1024 * 1024; // 2 Mo en octets

    fileInputs.forEach(input => {
        input.addEventListener('change', function() {
            const feedback = document.getElementById(input.name + 'Feedback');
            feedback.textContent = ''; // Réinitialise le message d'erreur
            if (input.files.length > 0) {
                const file = input.files[0];
                if (file.size > maxSize) {
                    feedback.textContent = 'Le fichier ne doit pas dépasser 2 Mo.';
                    input.value = ''; // Réinitialise le champ de fichier
                }
            }
        });
    });
</script>

<script>
    const fileInput = document.getElementById('photopassport');
    const submitButton = document.getElementById('submitButton');
    const feedback = document.getElementById('photoFeedback');
    const maxSizes = 2 * 1024 * 1024; // 2 Mo en octets

    fileInput.addEventListener('change', function() {
        feedback.textContent = ''; // Réinitialiser le message d'erreur
        submitButton.disabled = true; // Désactiver le bouton par défaut

        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            if (file.size > maxSizes) {
                feedback.textContent = 'La photo ne doit pas dépasser 2 Mo.';
                fileInput.value = ''; // Réinitialiser le champ de fichier
            } else {
                submitButton.disabled = false; // Activer le bouton si le fichier est valide
            }
        }
    });
</script>

<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js') }}"></script>

@include('Backend.components.footer')
<!-- Validation custom js-->

