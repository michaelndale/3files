@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')
<div class="col-5" style="margin:auto">
@if (session()->has('success'))
 <div class="col-lg-12">
    <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
 </div>
@endif
<div class="card">
    <div class="card-body">
        <h4 class="card-title"><i class="fa fa-edit"></i> Modifier Personnels </h4>

        <form class="needs-validation" novalidate action="{{ route('update.personnel', $user->idu)}}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-row">
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Nom </label>
                    <input type="text" name="nom" class="form-control" id="validationTooltip01" placeholder="Nom" value="{{ $user->nomp }}" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le nom.
                        </div>
                </div>
               
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Prenom</label>
                    <input type="text" name="prenom" class="form-control" id="validationTooltip02" placeholder="Prenom" value="{{ $user->prenom }}" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le prenom.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Genre</label>
                    <select type="text" name="genre" class="form-control" id="validationTooltip02" placeholder="Prenom"  required>
                        <option  value="{{ $user->sexe }}" >{{ $user->sexe }}</option>
                        <option value="Homme"> Homme </option>
                        <option value="Femme"> Femme </option>
                        <option value="Transgenre"> Transgenre </option>
                        <option value="Autres"> Autres   </option>
                    </select>
                    <div class="invalid-tooltip">
                            Veuillez entrer le genre.
                        </div>
                </div>



                <div class="col-md-12 mb-12">
                    <label for="validationTooltipUsername">Email</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="validationTooltipUsernamePrepend">@</span>
                        </div>
                        <input type="email" name="email" class="form-control" id="validationTooltipUsername" placeholder="Email" aria-describedby="validationTooltipUsernamePrepend"value="{{ $user->email }}" required>
                        <div class="invalid-tooltip">
                           Veuillez entrere l'email corret
                        </div>
                    </div>
                </div>

              
            </div>
            <div class="form-row">
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip03">Telephone</label>
                    <input type="text" name="tel" class="form-control" id="validationTooltip03" placeholder="Telephone" value="{{ $user->tel }}" required>
                    <div class="invalid-tooltip">
                        Veuillez entrer le numero de telephone.
                    </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Fonction </label>
                    <select type="text" name="fonction" class="form-control" id="validationTooltip02" placeholder="Prenom"  required>
                        <option  value="{{ $user->idfonction }}" selected >  {{ $user->titreFonction }}</option>
                       @forelse ($fonction as $fonctions)
                       <option value="{{ $fonctions->id }}"> {{ $fonctions->titre }} </option> 
                       @empty
                           La liste est vide
                       @endforelse
                       
                    </select>
                    <div class="invalid-tooltip">
                            Veuillez choisir la fonction.
                    </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Statut </label>
                    <select type="text" name="statut" class="form-control" id="validationTooltip02" placeholder="Prenom"  required>
                        <option  value="{{ $user->status }}" selected>{{ $user->status }}</option>
                        <option value="ACTIF">ACTIF</option>
                        <option value="INACTIF">INACTIF</option>
                       
                    </select>
                    <div class="invalid-tooltip">
                            Veuillez choisir la fonction.
                    </div>
                </div>



                
               
            </div>
            <br>
            
            <button class="btn btn-primary" name="saveData"  type="submit">Enregistrer</button>
        </form>

    </div>
    </div>
</div>
















<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>

@include('Backend.components.footer')
<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>