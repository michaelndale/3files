@include('Backend.components.header');
<!-- Plugins css -->


@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

@include('Backend.components.messagre')

<div class="col-6" style="margin:auto">
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-8">
                    <h4 class="card-title"><i class="fa fa-list"></i> Facultés</h4>

                </div>
                <div class="col-lg-4">
                    <div class="text-lg-right mt-3 mt-lg-0">


                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#classeModale">
                            <i class="mdi mdi-plus-circle mr-1"></i> Nouvelle faculté

                        </button>
                    </div>
                </div><!-- end col-->
            </div> <!-- end row -->
            <br>
            <table class="table table-striped dt-responsive nowrap">
                <thead>
                    <tr>
                        <th>Libellé</th>
                        <th>Créé le</th>
                        <th style="width:10%">Actions</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse ($allFaculte as $allFacultes)
                        <tr>
                            <td> <a href="{{ route('classe', $allFacultes->id) }}"> {{ $allFacultes->libelle }} </a>
                            </td>
                            <td>{{ date('d/m/Y', strtotime($allFacultes->created_at)) }} </td>
                            <td>

                                <div class="btn-group btn-group-sm" role="group">
                                    <button id="btnGroupDrop1" type="button"
                                        class="btn btn-outline-secondary dropdown-toggle " data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        Options <i class="mdi mdi-chevron-down"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">

                                        <form action="{{ route('deletefaculte', $allFacultes->id) }}" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="dropdown-item" title="Supprimer la faculté"
                                                style="background-color:red;color:white"><i
                                                    class="fas fa-trash-alt "></i> Supprimer
                                        </form>

                                    </div>
                                </div>


                                </form>

                            </td>
                        </tr>
                    @empty
                        la liste des classes est vide
                    @endforelse
                </tbody>
            </table>
        </div> <!-- end card body-->
    </div> <!-- end card -->
</div>
@include('Backend.Faculte..nouveau')
@include('Backend.components.footer')

