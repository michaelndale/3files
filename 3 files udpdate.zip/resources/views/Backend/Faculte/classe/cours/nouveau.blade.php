<div class="modal fade" id="coursModale" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <form class="needs-validation" novalidate action="{{ route('save_couus_classe')}}" method="POST">
            @csrf
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i> Affectation cous dans la faculte et classe </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

         
            <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Cours </label>
                    <select type="text" name="courid" class="form-control" id="validationTooltip02" placeholder="Prenom"  required>
                        <option  value="" selected disabled>Choisie la cours</option>
                        @forelse ($cours as $courss)
                       <option value="{{ $courss->id }}">{{ $courss->titre }} </option> 
                       @empty
                           La liste est vide
                       @endforelse
                    </select>
                   
                    <div class="invalid-tooltip">
                            Veuillez choisir le cours.
                    </div>
                </div>
               
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Annee en cours</label>
                    <input type="tetx"  class="form-control" id="validationTooltip02" placeholder="volume" value="{{ $anne_actif->libelle }}"   readonly>
                    <input type="hidden" name="anneid"  value="{{ $anne_actif->id }}"   readonly>
                    <div class="invalid-tooltip">
                            Veuillez entrer le anne .
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Faculte</label>
                    <input type="tetx"  class="form-control" id="validationTooltip02" placeholder="volume" value="{{ $classe->faculteNom }}"   readonly>
                   
                    <div class="invalid-tooltip">
                            Veuillez entrer le classe.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Classe</label>
                    <input type="tetx"  class="form-control" id="validationTooltip02" placeholder="volume" value="{{ $classe->classeNom }}"   readonly>
                   
                    <div class="invalid-tooltip">
                            Veuillez entrer le classe.
                        </div>
                </div>

                <input type="hidden" name="classeid" value="{{ $classe->classeId }}">

                <input type="hidden" name="faculteid" value="{{ $classe->faculteId }}">

            </div>
           
           
            <div class="modal-footer">
                <button type="button" class="btn btn-denger" data-dismiss="modal">Annuler</button>
                <button class="btn btn-primary" name="saveData"  type="submit">Enregistrer</button>
            </div>
        </div>
    </form>


    </div>
</div>





<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>