@include('Backend.components.header');
@include('Backend.components.menu');
@include('Backend.components.menu_vertical')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

@if (Auth::user()->idfonction != 3)

    <div class="col-lg-6 col-xl-3">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <h6 class="text-uppercase font-size-12 text-muted mb-3">Etudiant</h6>
                        <span class="h3 mb-0"> @php $Etudiant = $User->where('idfonction', '=', 7)->count() @endphp
                            {{ $Etudiant }}
                        </span>
                    </div>
                    <div class="col-auto">
                        <span class="badge badge-soft-success">100%</span>
                    </div>
                </div> <!-- end row -->


            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->

    <div class="col-lg-6 col-xl-3">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <h6 class="text-uppercase font-size-12 text-muted mb-3">Etudiant Actif</h6>
                        <span class="h3 mb-0"> @php
                            $etudiantActif = $User->where('idfonction', '=', 7)->where('status', '=', 'ACTIF')->count();
                        @endphp

                            {{ $etudiantActif }}

                        </span>
                    </div>
                    <div class="col-auto">
                        <span class="badge badge-soft-danger">{{ round(($etudiantActif * 100) / $Etudiant) }}
                            %</span>
                    </div>
                </div> <!-- end row -->


            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->

    <div class="col-lg-6 col-xl-3">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <h6 class="text-uppercase font-size-12 text-muted mb-3">Etudiant Non Actif</h6>
                        <span class="h3 mb-0"> @php
                            $etudiantNonActif = $User
                                ->where('idfonction', '=', 7)
                                ->where('status', '!=', 'ACTIF')
                                ->count();
                        @endphp

                            {{ $etudiantNonActif }} </span>
                    </div>
                    <div class="col-auto">
                        <span class="badge badge-soft-success">{{  round(($etudiantNonActif * 100) / $Etudiant) }}%</span>
                    </div>
                </div> <!-- end row -->


            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->

    <div class="col-lg-6 col-xl-3">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <h6 class="text-uppercase font-size-12 text-muted mb-3">Facultes</h6>
                        <span class="h3 mb-0"> {{ $faculte->count() }} </span>
                    </div>

                </div> <!-- end row -->


            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->

    <div class="col-lg-6 col-xl-3">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <h6 class="text-uppercase font-size-12 text-muted mb-3">Cours</h6>
                        <span class="h3 mb-0"> {{ $cours->count() }} </span>
                    </div>

                </div> <!-- end row -->


            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->

    <div class="col-lg-6 col-xl-3">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <h6 class="text-uppercase font-size-12 text-muted mb-3">Biliotheques</h6>
                        <span class="h3 mb-0"> {{ $bibliotheque->count() }} </span>
                    </div>
                    <div class="col-auto">
                        <span class="badge badge-soft-danger">100%</span>
                    </div>
                </div> <!-- end row -->


            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->

    <div class="col-lg-6 col-xl-3">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <h6 class="text-uppercase font-size-12 text-muted mb-3">Bibliotheque Actif</h6>
                        <span class="h3 mb-0">
                            @php
                                $allbil = $bibliotheque->where('status', '=', 'public')->count();
                            @endphp
                            {{ $allbil }} </span>
                    </div>
                    <div class="col-auto">
                        <span class="badge badge-soft-success"> {{ ($allbil * 100) / $bibliotheque->count() }}</span>
                    </div>
                </div> <!-- end row -->


            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->

    <div class="col-lg-6 col-xl-3">
        <div class="card">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <h6 class="text-uppercase font-size-12 text-muted mb-3">Bibliotheque NON Actif</h6>
                        <span class="h3 mb-0">
                            @php
                                $allbilNONACTIF = $bibliotheque->where('status', '!=', 'public')->count();
                            @endphp
                            {{ $allbilNONACTIF }} </span>
                    </div>
                    <div class="col-auto">
                        <span class="badge badge-soft-success">
                            {{ ($allbilNONACTIF * 100) / $bibliotheque->count() }}</span>
                    </div>
                </div> <!-- end row -->


            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->



    </div>



    <div class="row">
        <div class="col-xl-6">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">les cinq derniers étudiants inscrits</h4>
                    <p class="card-subtitle mb-4">Transaction period from 21 July to 25 Aug</p>

                    <div class="table-responsive">
                        <table class="table table-centered table-striped table-nowrap">
                            <thead>
                                <tr>
                                    <th>Etudiants</th>
                                    <th>Telephone</th>
                                    <th>Email</th>
                                    <th>Code</th>
                                    <th>Date de creation</th>
                                </tr>
                            </thead>
                            <tbody>

                                @forelse ($utilisateursLimites as $Users)
                                    <tr>
                                        <td class="table-user">
                                            <img src="{{ asset($Users->photo) }}" alt="table-user"
                                                class="mr-2 avatar-xs rounded-circle">
                                            <a href="javascript:void(0);"
                                                class="text-body font-weight-semibold">{{ $Users->nom }}
                                                {{ $Users->prenom }}</a>
                                        </td>
                                        <td>
                                            {{ $Users->tel }}
                                        </td>
                                        <td>
                                            {{ $Users->email }}
                                        </td>
                                        <td>
                                            {{ $Users->code }}
                                        </td>
                                        <td>
                                            {{ $Users->created_at }}
                                        </td>
                                    </tr>

                                @empty
                                @endforelse




                            </tbody>
                        </table>
                    </div>

                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->

        <div class="col-xl-6">
            <div class="card">
                <div class="card-body">

                    <h4 class="card-title">Transactions du Compte</h4>
                    <p class="card-subtitle mb-4">Transaction period from 21 July to 25 Aug</p>

                    <div class="table-responsive">
                        <table class="table table-borderless table-hover table-centered table-nowrap mb-0">
                            <tbody>

                                @forelse ($payement as $payements)

                                <tr>
                                    <td>
                                        <h5 class="font-size-15 mb-1 font-weight-normal">{{ substr($payements->reference_number, 0, 4) . ' **** **** ' . substr($payements->reference_number, -4) }}
                                        </h5>
                                        <span class="text-muted font-size-12">{{ $payements->payment_date}}</span>
                                    </td>
                                    <td>
                                        <h5 class="font-size-15 mb-1 font-weight-normal">{{ round($payements->amount) }}                                        </h5>
                                        <span class="text-muted font-size-12">Montant</span>
                                    </td>
                                    <td>
                                        <h5 class="font-size-17 mb-1 font-weight-normal"><i
                                                class="fab fa-cc-visa"></i></h5>
                                        <span class="text-muted font-size-12">{{ $payements->payment_method }}</span>
                                    </td>
                                    <td>
                                        <h5 class="font-size-15 mb-1 font-weight-normal">{{ $payements->nom }} {{ $payements->prenom }} </h5>
                                        <span class="text-muted font-size-12">Payer par</span>
                                    </td>
                                </tr>
                                    
                                @empty
                                    
                                @endforelse
                               

                              

                            </tbody>
                        </table>
                    </div>

                </div> <!-- end card-body-->
            </div> <!-- end card-->
        </div> <!-- end col -->
    </div>
    <!-- end row-->

    </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->
@else
    <div class="col-md-4">
        <a href="{{ route('mes.cours') }}">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Cours</h5>
                    <p class="card-text"> ours spécifique que vous enseignez,
                        d’un cours en ligne ou en présentiel </p>
                    <p class="card-text">
                        <small class="text-muted">Liste des cours</small>
                    </p>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-4">
        <a href="{{ route('listes.resultat') }}">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Examen</h5>
                    <p class="card-text"> une évaluation formelle destinée à mesurer les connaissances, compétences des
                        questions </p>
                    <p class="card-text">
                        <small class="text-muted">Liste des examens</small>
                    </p>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-4">
        <a href="{{ route('listes.resultat') }}">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Resultat des evaluations </h5>
                    <p class="card-text"> Les résultats peuvent être donnés sous forme de notes, mentions</p>
                    <p class="card-text">
                        <small class="text-muted">Recherche sur la resultat</small>
                    </p>
                </div>
            </div>
        </a>
    </div>





@endif




<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                2019 © Drezoc.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-right d-none d-sm-block">
                    Design & Develop by Myra
                </div>
            </div>
        </div>
    </div>
</footer>

</div>


@include('Backend.components.footer');
