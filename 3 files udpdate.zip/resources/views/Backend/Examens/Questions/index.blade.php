@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

@if (session()->has('success'))
    <div class="col-lg-12">
        <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
    </div>
@endif

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<!-- Display Exception Errors -->
@if ($errors->has('exception'))
    <div class="alert alert-danger">
        <strong>{{ $errors->first('exception') }}</strong>
    </div>
@endif

<div class="col-12">
    <div class="card">
        <div class="card-body">

            <div class="row">
                <div class="col-lg-6">
                    <h4 class="card-title"><i class="fa fa-file"></i> Liste des questions de l'examens
                        {{ $examens->titre_cours }} ( {{ $questions->count() }} ) </h4>
                </div>
                @if (Auth::user()->idfonction != 3)
                    <div class="col-lg-6">
                        <div class="text-lg-right mt-3 mt-lg-0">
                            <button type="button" class="btn btn-primary" data-toggle="modal"
                                data-target="#coursModale">
                                <i class="mdi mdi-plus-circle mr-1"></i> Nouvel Questions
                            </button>
                        </div>
                    </div><!-- end col-->
                @endif
            </div> <!-- end row -->



            <br>
            <div class="row">
                @foreach ($questions as $index => $question)
                    <div class="col-md-12">
                        <div class="card mb-3">
                            <!-- En-tête avec titre et informations -->
                            <div class="card-header">
                                <strong>Question {{ $index + 1 }} :</strong> {{ $question->titre }}
                                <p class="mt-1 mb-0" style="font-size: 0.9rem; color: #555;">
                                    <strong>Point :</strong> {{ $question->point }},
                                    <strong>Temps limite :</strong> {{ $question->temps_limite }}
                                </p>
                            </div>
            
                            <!-- Tableau des choix directement sous l'en-tête -->
                            <table class="table table-bordered table-sm mb-0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Choix</th>
                                        <th> <center> Correct ? </center></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @php
                                        $num = 1;
                                    @endphp
                                    @foreach ($question->choixes as $choice)
                                        <tr>
                                            <td style="width:30px">{{ $num }} </td>
                                            <td>{{ $choice->titre }}</td>
                                            <td style="width:100px">
                                                <center>
                                                    @if ($choice->is_correct)
                                                        <span class="badge badge-success">Oui</span>
                                                    @else
                                                        <span class="badge badge-secondary">Non</span>
                                                    @endif
                                                </center>
                                             
                                            </td>
                                        </tr>
                                        @php
                                            $num++;
                                        @endphp
                                    @endforeach
                                </tbody>
                            </table>
            
                            <!-- Pied de carte -->
                            <div class="card-footer">
                                <form action="{{ route('deleteQuestion', $question->id) }}" method="post" style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        <i class="fas fa-trash-alt"></i> Supprimer
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
            
            
            
            
            
            
        </div> <!-- end card body-->
    </div> <!-- end card -->
</div>

@include('Backend.Examens.Questions.nouveau')
@include('Backend.components.footer')

