</div>
</div>
</div>
</div>
<div class="menu-overlay">

</div>
<!-- jQuery  -->
<script src="{{ asset('backend/js/jquery.min.js')}}"></script>
<script src="{{ asset('backend/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{ asset('backend/js/metismenu.min.js')}}"></script>
<script src="{{ asset('backend/js/waves.js')}}"></script>
<script src="{{ asset('backend/js/simplebar.min.js')}}"></script>

<!-- Sparkline Js-->
<script src="{{ asset('backend/plugins/jquery-sparkline/jquery.sparkline.min.js')}}"></script>

<!-- Morris Js-->
<script src="{{ asset('backend/plugins/morris-js/morris.min.js')}}"></script>
<!-- Raphael Js-->
<script src="{{ asset('backend/plugins/raphael/raphael.min.js')}}"></script>

<!-- Custom Js -->
<script src="{{ asset('backend/pages/dashboard-demo.js')}}"></script>

<!-- App js -->
<script src="{{ asset('backend/js/theme.js')}}"></script>

</body>

</html>