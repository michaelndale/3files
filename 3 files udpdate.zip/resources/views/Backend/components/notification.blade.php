@php
    $notificatio = DB::table('etudiants')->join('users', 'etudiants.user_id', 'users.id')
            ->select('etudiants.*', 'users.id as idu', 'users.code', 'users.status', 'users.photo as photos')
            ->where('users.status', '!=', 'ACTIF')
            ->get();
            
@endphp


<div class="dropdown d-inline-block ml-2">
    <button type="button" class="btn header-item noti-icon" id="page-header-notifications-dropdown" data-toggle="dropdown"
        aria-haspopup="true" aria-expanded="false">
        <i class="mdi mdi-bell-outline"></i>
        <span class="badge badge-danger badge-pill">{{ $notificatio->count() }}</span>
    </button>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right p-0"
        aria-labelledby="page-header-notifications-dropdown">
        @foreach ($notificatio as $notification)
        <div data-simplebar style="max-height: 230px;">
            <a href="#" class="text-reset">
                <div class="media py-2 px-3">
                    <img src="{{ asset($notification->photos) }}" class="mr-3 rounded-circle avatar-xs" alt="user-pic">
                    <div class="media-body">
                        <h6 class="mt-0 mb-1">{{ $notification->nom }} {{ $notification->prenom }}</h6>
                        <p class="font-size-12 mb-1">{{ $notification->code }} </p>
                        <p class="font-size-12 mb-0 text-muted"><i class="mdi mdi-clock-outline"></i> {{ $notification->created_at }} </p>
                    </div>
                </div>
            </a>
        </div>
            
        @endforeach
       
        <div class="p-2 border-top">
            <a class="btn btn-sm btn-light btn-block text-center" href="{{ route('listes.etudiant') }}">
                <i class="mdi mdi-arrow-down-circle mr-1"></i> Voir plus..
            </a>
        </div>
    </div>
</div>
