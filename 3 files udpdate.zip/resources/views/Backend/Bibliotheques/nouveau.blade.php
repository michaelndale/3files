@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

@if (session()->has('success'))
 <div class="col-lg-12">
    <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
 </div>
@endif

<div class="col-12" style="margin:auto">
<div class="card">
    <div class="card-body">
        <h4 class="card-title"><i class="fa fa-edit"></i> Nouveau Bibiotheque</h4>
      
        <form class="needs-validation" novalidate action="{{ route('save.bibliotheque')}}" method="POST" enctype="multipart/form-data">
            @csrf
            
            <div class="form-row">

            <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Etudiant </label>
                    <select type="text" name="etudiant_id" class="form-control" id="validationTooltip02" placeholder="Prenom"  required>
                        <option  value="" selected disabled>Choisie un etudiant</option>
                        @forelse ($allEtudiant as  $allEtudiants)
                            <option value="{{ $allEtudiants->id }}"> {{ $allEtudiants->nom }}  {{ $allEtudiants->prenom }} </option>
                        @empty
                            La liste est vide
                        @endforelse
                    </select>
                    <div class="invalid-tooltip">
                            Veuillez choisir la fonction.
                    </div>
                </div>
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Titre </label>
                    <input type="text" name="titre" class="form-control" id="validationTooltip01" placeholder="Titre" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le Titre.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                <br>
                    <label for="validationTooltip01">Couvertise <small>(Format IMAGE "png,jpg,gif")</small> </label></label>
                    <input type="file" name="photo" class="form-control" id="validationTooltip01" placeholder="Titre" accept="image/*" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le couverture.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                <br>
                    <label for="validationTooltip01">Document <small>(Format PDF)</small> </label>
                    <input type="file" name="doc" class="form-control" id="validationTooltip01" placeholder="Titre" accept=".pdf" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le Document.
                        </div>
                </div>

             


                <div class="col-md-12 mb-12">
                <br>
                    <label for="validationTooltip01">Description </label>
                    <textarea type="text" name="description" class="form-control" id="validationTooltip01" placeholder="description" required style="height:250px"> </textarea>
                    <div class="invalid-tooltip">
                            Veuillez entrer la Description.
                        </div>
                </div>

             
             



            </div>
         
            <br>
            <button class="btn btn-primary" name="saveData"  type="submit">Enregistrer</button>
        </form>

    </div> <!-- end card-body-->
</div> <!-- end card -->
</div>

@include('Backend.components.footer')
<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>