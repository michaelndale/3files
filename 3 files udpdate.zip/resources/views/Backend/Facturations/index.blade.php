@include('Backend.components.header')
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')


<div class="col-6" style="margin:auto">
    @include('Backend.components.messagre')
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-lg-8">
                    <h4 class="card-title"><i class="fa fa-list"></i> Facturation par nnées Scolaires</h4>
                </div>
                <div class="col-lg-4">
                    <div class="text-lg-right mt-3 mt-lg-0">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#classeModale">
                            <i class="mdi mdi-plus-circle mr-1"></i>  Créer
                        </button>
                    </div>
                </div><!-- end col-->
            </div>
            <br>

            <table class="table table-striped dt-responsive nowrap">
                <thead>
                    <tr>

                        <th>Année Scolaire</th>
                        <th>Statut</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($anneScolaires as $annee)
                        <tr>
                            <td>
                                <a href="javascript:void(0)" class="open-facturation-modal"
                                    data-annee-id="{{ $annee->id }}">{{ $annee->libelle }}</a>
                            </td>
                            <td>{{ $annee->statut }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div> <!-- end card body-->
    </div> <!-- end card -->
</div>

<!-- Modal pour afficher les facturations -->
<div class="modal fade" id="facturationModal" tabindex="-1" role="dialog" aria-labelledby="facturationModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="facturationModalLabel">Facturations</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Libellé</th>
                            <th>Montant</th>
                            <th>Période</th>
                            <th>Créé le</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="facturation-list">
                        <!-- Les facturations seront chargées ici -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Ajout du script AJAX -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Lorsque l'on clique sur une année scolaire
        $('.open-facturation-modal').click(function() {
            var anneeId = $(this).data('annee-id');

            // Utilisation de route() pour générer l'URL dynamiquement
            var url = "{{ route('facturations', ':annee_id') }}";
            url = url.replace(':annee_id', anneeId); // Remplacer :annee_id par la valeur réelle

            // Requête AJAX pour récupérer les facturations pour l'année sélectionnée
            $.ajax({
                url: url, // URL générée dynamiquement avec route()
                type: 'GET',
                success: function(data) {
                    // Vider la liste des facturations dans le modal
                    $('#facturation-list').empty();

                    // Ajouter les facturations dans le modal
                    if (data.length > 0) {
                        data.forEach(function(facturation) {
                            // Formater le montant avec des espaces pour séparer les milliers
                            var montantFormatted = parseFloat(facturation.montant)
                                .toLocaleString('fr-FR');

                            // Formater les dates (création et période)
                            var createdAtFormatted = new Date(facturation
                                .created_at);
                            var periodeFormatted = new Date(facturation.periode);

                            // Fonction pour formater la date au format 'd/m/Y'
                            function formatDate(date) {
                                var day = date.getDate();
                                var month = date.getMonth() +
                                    1; // Mois commence à 0
                                var year = date.getFullYear();

                                return day + '/' + month + '/' + year;
                            }

                            var row = `<tr>
                                            <td>${facturation.libelle}</td>
                                            <td>${montantFormatted}</td>
                                            <td>${formatDate(periodeFormatted)}</td>
                                            <td>${formatDate(createdAtFormatted)}</td>
                                            <td>
                                                <button class="btn btn-warning btn-sm modify-btn" data-id="${facturation.id}">Modifier</button>
                                                <button class="btn btn-danger btn-sm delete-btn" data-id="${facturation.id}">Supprimer</button>
                                            </td>
                                        </tr>`;
                            $('#facturation-list').append(row);
                        });

                    } else {
                        $('#facturation-list').append(
                            '<tr><td colspan="4">Aucune facturation trouvée pour cette année.</td></tr>'
                        );
                    }

                    // Afficher le modal
                    $('#facturationModal').modal('show');
                },
                error: function() {
                    alert('Une erreur est survenue, veuillez réessayer.');
                }
            });
        });

        // Lorsque l'on clique sur le bouton de suppression

        // Lorsque l'on clique sur un bouton "Modifier"
        $(document).on('click', '.modify-btn', function() {
            var facturationId = $(this).data('id');

            // Récupérer les informations de facturation et afficher dans un formulaire (modal) pour modification
            // Exemple : ouvrir un modal pour la modification
            $.ajax({
                url: '/facturations/' + facturationId +
                '/edit', // Remplacer par l'URL de l'édition
                type: 'GET',
                success: function(data) {
                    // Remplir le formulaire de modification avec les données récupérées
                    $('#editFacturationModal #libelle').val(data.libelle);
                    $('#editFacturationModal #montant').val(data.montant);
                    $('#editFacturationModal #periode').val(data.periode);
                    $('#editFacturationModal #facturationId').val(data.id);
                    $('#editFacturationModal').modal('show');
                },
                error: function() {
                    alert('Erreur lors de la récupération des données pour modification.');
                }
            });
        });

        // Lorsque l'on clique sur un bouton "Supprimer"
        $(document).on('click', '.delete-btn', function() {
            var facturationId = $(this).data('id');

            // Demander une confirmation avant de supprimer
            if (confirm('Êtes-vous sûr de vouloir supprimer cette facturation ?')) {
                $.ajax({
                    url: '/facturations/' + facturationId, // Remplacer par l'URL de suppression
                    type: 'DELETE',
                    data: {
                        _token: '{{ csrf_token() }}',
                    },
                    success: function(response) {
                        // Supprimer la ligne du tableau après suppression réussie
                        alert('Facturation supprimée avec succès.');
                        $('tr').find(`button[data-id="${facturationId}"]`).closest('tr')
                            .remove();
                    },
                    error: function() {
                        alert('Erreur lors de la suppression de la facturation.');
                    }
                });
            }
        });

    });
</script>

@include('Backend.Facturations.nouveau')
@include('Backend.components.footer')
