<div class="modal fade" id="classeModale" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">

    <form class="needs-validation" novalidate action="{{ route('save.Facturation')}}" method="POST">
            @csrf
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>  Nouvelle facturation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>


            
            <div class="modal-body">

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Annee scolaire</label>
                    <input type="text" class="form-control form-control-user" id="validationTooltip04" value="Anne scolaire: {{ $anneActif->libelle }}" required readonly>
                    <input type="hidden" name="annee_id" value="{{ $anneActif->id }}" />
                    <div class="invalid-tooltip">
                        Veuillez entrer le genre.
                    </div>
                    <br>
                </div>

            <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Libellé des paiements </label>
                    <input type="text" name="libelle" class="form-control" id="validationTooltip01" placeholder="Libelle" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le libelle.
                        </div>
                        <br>
                </div>
          

          
            <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Montant  </label>
                    <input type="text" name="montant" class="form-control" id="validationTooltip01" placeholder="Libelle" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le montant.
                        </div>
                        <br>
                </div>
          

            <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Période  echeance du payement </label>
                    <input type="date" name="periode" class="form-control" id="validationTooltip01" placeholder="Libelle" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le Periode.
                        </div>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button class="btn btn-primary" name="saveData"  type="submit">Enregistrer</button>
            </div>
        </div>
    </form>


    </div>
</div>


<div class="modal fade" id="editFacturationModal" tabindex="-1" role="dialog" aria-labelledby="editFacturationModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editFacturationModalLabel">Modifier la Facturation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="editFacturationForm" method="POST" action="{{ route('update.facturation') }}">
                @csrf
                <input type="hidden" id="facturation_id" name="facturation_id">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="libelle">Libellé</label>
                        <input type="text" class="form-control" id="libelle" name="libelle" required>
                    </div>
                    <div class="form-group">
                        <label for="montant">Montant</label>
                        <input type="text" class="form-control" id="montant" name="montant" required>
                    </div>
                    <div class="form-group">
                        <label for="periode">Période</label>
                        <input type="date" class="form-control" id="periode" name="periode" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                    <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                </div>
            </form>
        </div>
    </div>
</div>
