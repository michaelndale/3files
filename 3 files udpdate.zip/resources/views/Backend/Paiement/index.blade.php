@include('Backend.components.header');
@include('Backend.components.menu');
@include('Backend.components.menu_vertical')

<div class="col-xl-12">
    <div class="card">
        <div class="card-body">

            <h4 class="card-title">Historique de Transactions de payement </h4>
         
            <div class="table-responsive">

                <table class="table table-striped dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>Nom Prenom </th>
                            <th>Code</th>
                            <th>Payement date</th>
                            <th>Montant</th>
                            <th>Methode</th>
                         
                            <th>Statut</th> 
                            <th>Créé le</th>
                            <th style="width:10%">Actions</th>
                        </tr>
                    </thead>
                    


                    <tbody>
                        @forelse ($payement as $payements)
                        <tr>
                            <td>{{ $payements->nom }} {{ $payements->prenom }}</td>
                            <td>{{ $payements->reference_number }}</td>
                            <td>{{ $payements->payment_date}}</td>
                            <td>{{ round($payements->amount) }}  </td>
                            <td>{{ $payements->payment_method }}</td>
                            
                            <td>
                                @if ( $payements->status==1)
                                    <i class="fas fa-check-circle" style="color:green"></i>
                                @else
                                    <i class="fas fa-times-circle" style="color:red"></i>
                                @endif

                            </td>
                          
                         
                            <td>{{ date('d-m-Y', strtotime($payements->created_at)) }} </td>
                            <td>
                                <div class="btn-group btn-group-sm" role="group">
                                    <button id="btnGroupDrop1" type="button"
                                        class="btn btn-outline-secondary dropdown-toggle " data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        Options <i class="mdi mdi-chevron-down"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                       
                                        @if ($payements->status==1)

                                        <form action="{{ route('blockPayement', $payements->id) }}" method="POST" style="display: inline;"
                                            onsubmit="return confirm('Êtes-vous sûr de vouloir bloquer le payement ?');">
                                            @csrf
                                            <button type="submit" class="dropdown-item" title="Bloquer le payement">
                                                <i class="fas fa-times-circle" style="color:red"></i> Bloquer de l'exame
                                            </button>
                                        </form>
                                            
                                        @else
    
                                        <form action="{{ route('activePayement', $payements->id) }}" method="POST" style="display: inline;"
                                            onsubmit="return confirm('Êtes-vous sûr de vouloir active le payement ?');">
                                            @csrf
                                            <button type="submit" class="dropdown-item" title="Bloquer le payement ">
                                                <i class="fas fa-check-circle" style="color:green"></i> Valider le payement
                                            </button>
                                        </form>
    
                                            
                                        @endif


                                    
                                    </div>
                                </div>

                            </td>


                        </tr>
                        @empty
                        la liste des Cours est vide
                        @endforelse
                    </tbody>
                </table>



               
            </div>

        </div> <!-- end card-body-->
    </div> <!-- end card-->
</div> <!-- end col -->

<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                2019 © Drezoc.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-right d-none d-sm-block">
                    Design & Develop by Myra
                </div>
            </div>
        </div>
    </div>
</footer>

</div>


@include('Backend.components.footer');
