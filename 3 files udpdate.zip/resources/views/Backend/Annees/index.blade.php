@include('Backend.components.header')

@include('Backend.components.menu')
@include('Backend.components.menu_vertical')


    <div class="col-6" style="margin:auto">
        
        <div class="card">
            
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-8">
                        <h4 class="card-title"><i class="fa fa-list"></i> Années scolaire</h4>
                    </div>
                    <div class="col-lg-4">
                        <div class="text-lg-right mt-3 mt-lg-0">


                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#classeModale">
                                <i class="mdi mdi-plus-circle mr-1"></i> Créer
                            </button>
                            
                        </div>
                    </div><!-- end col-->
                </div> <!-- end row -->
                <br>
                <table id="datatable-buttons" class="table table-striped dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>Libellé</th>
                            <th>Date début</th>
                            <th>Date fin</th>
                            <th>Statut</th>
                            <th style="width:10%">Actions</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        @forelse ($allAnnee as $allAnnees )
                        <tr>
                            <td>{{ $allAnnees->libelle }} </td>
                       
                            <td>{{ date('d-m-Y', strtotime($allAnnees->date_debut)) }} </td>
                            <td>{{ date('d-m-Y', strtotime($allAnnees->date_fin)) }} </td>
                        
                            <td>{{ $allAnnees->statut }} </td>
                            <td>

                                <div class="btn-group btn-group-sm" role="group">
                                    <button id="btnGroupDrop1" type="button" class="btn btn-outline-secondary dropdown-toggle " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Options <i class="mdi mdi-chevron-down"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                        <a class="dropdown-item" href="{{ route('voir.annee', $allAnnees->id) }}"><i class="fas fa-eye "></i> Voir</a>
                                        <a class="dropdown-item" href="{{ route('edit.annee', $allAnnees->id) }}"><i class="fa fa-edit "></i> Mofifier</a>

                                        <form action="{{ route('deleteannee', $allAnnees->id) }}" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="dropdown-item" title="Supprimer le personnel" style="background-color:red;color:white"><i class="fas fa-trash-alt "></i> Supprimer
                                        </form>

                                    </div>
                                </div>


                                </form>

                            </td>
                        </tr>
                        @empty
                        la liste des classes est vide
                        @endforelse
                    </tbody>
                </table>
            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div>
    @include('Backend.Annees.nouveau')
    @include('Backend.components.footer')
 