@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

@if (session()->has('success'))
    <div class="col-lg-12">
        <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
    </div>
@endif

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<!-- Display Exception Errors -->
@if ($errors->has('exception'))
    <div class="alert alert-danger">
        <strong>{{ $errors->first('exception') }}</strong>
    </div>
@endif

<div class="col-12">
    <div class="card">
        <div class="card-body">

            <div class="row">
                <div class="col-lg-6">
                    <h4 class="card-title"><i class="fa fa-file"></i> Liste des questions de l'examens
                        {{ $examens->titre_cours }} ( {{ $questions->count() }} ) </h4>
                </div>
                @if (Auth::user()->idfonction != 3)
                    <div class="col-lg-6">
                        <div class="text-lg-right mt-3 mt-lg-0">
                            <button type="button" class="btn btn-primary" data-toggle="modal"
                                data-target="#coursModale">
                                <i class="mdi mdi-plus-circle mr-1"></i> Nouvel Questions
                            </button>
                        </div>
                    </div><!-- end col-->
                @endif
            </div> <!-- end row -->



            <br>
            <table class="table table-striped dt-responsive nowrap">
                <thead>
                    <tr>
                        <th>Titre</th>
                        <th>Point</th>
                        <th>Temps limite</th>
                        <th>Choix</th>
                        <th style="width:10%">Actions</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse ($questions as $question)
                        @php
                            $idq = $question->id;
                            $choix = DB::table('choixes')->where('question_id', '=', $idq)->get();
                        @endphp
                        <tr>
                            <td>{{ $question->titre }}</td>
                            <td>{{ $question->point }}</td>
                            <td>{{ $question->temps_limite }}</td>
                            <td>
                                <ul style="list-style-type: decimal;">
                                    @foreach ($choix as $choice)
                                        <li >
                                            {{ $choice->titre }}
                                            @if ($choice->is_correct)
                                                <span class="badge badge-success">Correct</span>
                                            @endif
                                        </li>
                                    @endforeach
                                </ul>
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm" role="group">
                                    <button id="btnGroupDrop1" type="button"
                                        class="btn btn-outline-secondary dropdown-toggle" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        Options <i class="mdi mdi-chevron-down"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                       
                                        @if (Auth::user()->idfonction != 3)
                                          

                                            <form action="{{ route('deleteQuestion', $question->id) }}" method="post"
                                                style="display:inline;">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="dropdown-item"
                                                    title="Supprimer le question"
                                                    style="background-color:red;color:white"><i
                                                        class="fas fa-trash-alt"></i> Supprimer</button>
                                            </form>
                                        @endif
                                    </div>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5">La liste des Cours est vide</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div> <!-- end card body-->
    </div> <!-- end card -->
</div>

@include('Backend.Examens.Questions.nouveau')
@include('Backend.components.footer')

