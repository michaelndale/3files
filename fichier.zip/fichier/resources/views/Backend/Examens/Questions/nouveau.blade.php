<div class="modal fade" id="coursModale" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <form class="needs-validation" novalidate action="{{ route('save.question', $examens->id) }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i> Ajouter une Question à l'Examen</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 mb-12">
                            <label for="validationTooltip01">Questions</label>
                            <textarea name="titre" class="form-control" id="validationTooltip01" placeholder="Question" required></textarea>
                            <div class="invalid-tooltip">Veuillez entrer la question.</div>
                        </div>

                        <div class="col-md-6 mb-12">
                            <br>
                            <label for="validationTooltip02">Point de la question</label>
                            <input type="number" name="point" class="form-control" id="validationTooltip03" placeholder="Point" required>
                            <div class="invalid-tooltip">Veuillez entrer le point.</div>
                        </div>

                        <div class="col-md-6 mb-12">
                            <br>
                            <label for="validationTooltip02">Minutes</label>
                            <input type="number" name="temps" class="form-control" id="validationTooltip03" placeholder="Minutes" min="10" required>
                            <div class="invalid-tooltip">Veuillez entrer le temps (minimum 10 minutes).</div>
                        </div>

                        <div class="col-md-12 mb-12">
                            <br><br>
                            <h5>Choix de réponse</h5>
                            <div id="choices">
                                <div class="choice-item">
                                    <label>
                                        <input type="hidden" name="choices[0][is_correct]" value="0"> <!-- Champ caché -->
                                        <input type="checkbox" name="choices[0][is_correct]" value="1"> Correct   <span class="badge badge-secondary">Choix 1</span>
                                    </label>
                                    <input type="text" name="choices[0][text]" placeholder="Texte du choix" class="form-control mb-2" required>
                                  
                                </div>
                            </div>
                            <button type="button" class="btn btn-success" onclick="addChoice()"><i class="fa fa-plus-circle"></i> Ajouter un choix</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>
                    <button class="btn btn-primary" name="saveData" type="submit">Enregistrer</button>
                </div>
            </div>
        </form>
    </div>
</div>



<script>
    let choiceIndex = 1;

    function addChoice() {
        const choicesDiv = document.getElementById('choices');
        const choiceItem = document.createElement('div');
        choiceItem.classList.add('choice-item', 'mt-3');

        choiceItem.innerHTML = `
            <label>
                <input type="hidden" name="choices[${choiceIndex}][is_correct]" value="0"> <!-- Champ caché -->
                 
                <input type="checkbox" name="choices[${choiceIndex}][is_correct]" value="1"> Correct  <span class="badge badge-secondary">Choix ${choiceIndex + 1}</span>
            </label>
            <input type="text" name="choices[${choiceIndex}][text]" placeholder="Texte du choix" class="form-control mb-2" required>
          
        `;
        
        choicesDiv.appendChild(choiceItem);
        choiceIndex++;
    }
</script>


<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>