@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

@if (session()->has('success'))
    <div class="col-lg-12">
        <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
    </div>
@endif

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="col-6" style="margin:auto">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title"><i class="fa fa-search"></i> Element de la recherche</h4>
            <form class="needs-validation" novalidate action="{{ route('save.fonction')}}" method="POST">
                @csrf
                
                <div class="form-row">
                    <div class="col-md-6 mb-6>
                        <label for="validationTooltip01">Facultés </label>
                        <input type="text" name="titre" class="form-control" id="validationTooltip01" placeholder="Titre" required>
                        <div class="invalid-tooltip">
                                Veuillez entrer le transliterator_create.
                            </div>
                    </div>

                    <div class="col-md-6 mb-6>
                        <label for="validationTooltip01">Classes </label>
                        <input type="text" name="titre" class="form-control" id="validationTooltip01" placeholder="Titre" required>
                        <div class="invalid-tooltip">
                                Veuillez entrer le transliterator_create.
                            </div>
                    </div>

                    <div class="col-md-6 mb-6>
                        <label for="validationTooltip01">Classes </label>
                        <input type="text" name="titre" class="form-control" id="validationTooltip01" placeholder="Titre" required>
                        <div class="invalid-tooltip">
                                Veuillez entrer le transliterator_create.
                            </div>
                    </div>

                    <div class="col-md-6 mb-6>
                        <label for="validationTooltip01">Annee Scolaire </label>
                        <input type="text" name="titre" class="form-control" id="validationTooltip01" placeholder="Titre" required>
                        <div class="invalid-tooltip">
                                Veuillez entrer le transliterator_create.
                            </div>
                    </div>
                </div>
                <br>
                <button class="btn btn-primary" name="saveData"  type="submit">Recherche </button>
            </form>

        </div> <!-- end card-body-->
    </div> <!-- end card -->
</div>

<!-- Display Exception Errors -->
@if ($errors->has('exception'))
    <div class="alert alert-danger">
        <strong>{{ $errors->first('exception') }}</strong>
    </div>
@endif


@include('Backend.components.footer')

