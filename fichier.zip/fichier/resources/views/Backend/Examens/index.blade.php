@include('Backend.components.header');
<!-- Plugins css -->
<link href="{{ asset('backend/plugins/datatables/dataTables.bootstrap4.css')}}')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/responsive.bootstrap4.css')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/buttons.bootstrap4.css')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/select.bootstrap4.css')}}" rel="stylesheet" type="text/css" />
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

@if (session()->has('success'))
 <div class="col-lg-12">
    <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
 </div>
@endif

@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<!-- Display Exception Errors -->
@if ($errors->has('exception'))
    <div class="alert alert-danger">
        <strong>{{ $errors->first('exception') }}</strong>
    </div>
@endif

    <div class="col-12">
        <div class="card">
            <div class="card-body">

            <div class="row">
                    <div class="col-lg-6">
                        <h4 class="card-title"><i class="fa fa-list"></i> Liste des examens</h4>
                    </div>
                    @if (Auth::user()->idfonction != 3)
                    <div class="col-lg-6">
                        <div class="text-lg-right mt-3 mt-lg-0">
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#coursModale">
                                <i class="mdi mdi-plus-circle mr-1"></i> Nouveau examen
                            </button>
                        </div>
                    </div><!-- end col-->
                    @endif
                </div> <!-- end row -->


            <br>

                <table class="table table-striped dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>Titre</th>
                            <th>Cours</th>
                            <th>Questions</th>
                            <th>Points</th>
                            <th>Date de l'examen</th>
                            <th>Début</th>
                            <th>Fin</th>
                            <th>Statut</th> 
                            <th>Créé le</th>
                            <th style="width:10%">Actions</th>
                        </tr>
                    </thead>
                    


                    <tbody>
                        @forelse ($examens as $examen )
                        <tr>
                            <td><a href="{{ route('listes.question', $examen->id) }}">{{ $examen->titre }}</a> </td>
                            <td>{{ $examen->titre_cours }}</td>
                            <td>{{ $examen->nombreQuestion }}</td>
                            <td>{{ $examen->pointQuestion }}</td>
                          
                            <td>{{ date('d/m/Y', strtotime($examen->dateexamen)) }} </td>
                            <td>{{ $examen->heuredebut }}</td>
                            <td>{{ $examen->heurefin }}</td>
                            <td>{{ $examen->status }}</td>
                          
                         
                            <td>{{ date('d/m/Y', strtotime($examen->created_at)) }} </td>
                            <td>
                                <div class="btn-group btn-group-sm" role="group">
                                    <button id="btnGroupDrop1" type="button"
                                        class="btn btn-outline-secondary dropdown-toggle " data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        Options <i class="mdi mdi-chevron-down"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                        <a class="dropdown-item" href="{{ route('listes.question', $examen->id) }}"><i class="fa fa-edit "></i> Listes des questions</a>
                                        @if (Auth::user()->idfonction != 3)

                                        <form action="{{ route('deleteExamen', $examen->id) }}" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="dropdown-item" title="Supprimer l'examen" style="background-color:red;color:white"><i class="fas fa-trash-alt "></i> Supprimer
                                        </form>

                                        @endif

                                    </div>
                                </div>

                            </td>


                        </tr>
                        @empty
                        la liste des Cours est vide
                        @endforelse
                    </tbody>
                </table>
            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div>

    @include('Backend.Examens.nouveau')
    @include('Backend.components.footer')
    <script src="{{ asset('backend/plugins/datatables/jquery.dataTables.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.bootstrap4.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.responsive.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.buttons.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.html5.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.flash.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.print.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.keyTable.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.select.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/pdfmake.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/vfs_fonts.js')}}"></script>
    <script src="{{ asset('backend/pages/datatables-demo.js')}}"></script>