@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')
<div class="row">

    <div class="col-xl-3 col-lg-3">
        <div class="card">
            <div class="card-body">

                <h4 class="card-title"><i class="fa fa-edit"></i> Mon profile</h4>
                <div class="row">

                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="form-group">
                            <center>
                                <img src="{{ asset($Etudiants->photos) }}" alt="staff" width="210"
                                    class="img-fluid rounded-circle"   />
                                <br><br>

                            </center>
                        </div>
                    </div>


                </div>

            </div>
        </div>
    </div>

    <div class="col-xl-8">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><i class="fa fa-edit"></i> Profile de l'Etudiant </h4>

                <div class="form-row">
                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip01">Code : </label>
                        {{ $Etudiants->code }}
                    </div>

                    <div class="form-row">
                        <div class="col-md-12 mb-12">
                            <label for="validationTooltip01">Nom : </label>
                            {{ $Etudiants->nom }}
                        </div>

                        <div class="col-md-12 mb-12">
                            <label >Prenom : </label>
                            {{ $Etudiants->prenom }}

                        </div>

                        <div class="col-md-12 mb-12">
                            <label >Genre :</label>
                            {{ $Etudiants->sexe }}

                        </div>



                        <div class="col-md-12 mb-12">
                            <label >Email :</label>
                           
                                {{ $Etudiants->email }}
                      
                        </div>


                    </div>
                    <div class="form-row">
                        <div class="col-md-12 mb-12">
                            <label >Telephone :</label>
                            {{ $Etudiants->tel }}
                        </div>

                        <div class="col-md-12 mb-12">
                            <label >Pays d'Origine :</label>
                            {{ $Etudiants->nationalite }}
                        </div>

                        <div class="col-md-12 mb-12">
                            <label >Statut :</label>
                            {{ $Etudiants->status }}

                        </div>

                        <div class="col-md-12 mb-12">
                            <label >Faculte :</label>
                            {{ $Etudiants->titre_faculte }}

                        </div>

                        <div class="col-md-12 mb-12">
                            <label >Annee :</label>
                            {{ $Etudiants->libelleannee }}

                        </div>

                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Validation custom js-->
    <script src="{{ asset('backend/pages/validation-demo.js') }}"></script>

    @include('Backend.components.footer')
    <!-- Validation custom js-->
    <script src="{{ asset('backend/pages/validation-demo.js') }}"></script>
