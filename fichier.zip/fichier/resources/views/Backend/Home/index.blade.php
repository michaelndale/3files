@include('Backend.components.header');
@include('Backend.components.menu');
@include('Backend.components.menu_vertical')

            <div class="col-lg-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase font-size-12 text-muted mb-3">Etudiant</h6>
                                <span class="h3 mb-0"> @php $Etudiant = $User->where('idfonction', '=', 7)->count() @endphp
                                    {{ $Etudiant }}
                            </span>
                            </div>
                            <div class="col-auto">
                                <span class="badge badge-soft-success">100%</span>
                            </div>
                        </div> <!-- end row -->

                       
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col-->
            
            <div class="col-lg-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase font-size-12 text-muted mb-3">Etudiant Actif</h6>
                                <span class="h3 mb-0"> @php
                                                         $etudiantActif =$User->where('idfonction', '=', 7)->where('status', '=', 'ACTIF')->count()
                                                        @endphp 

                                                        {{ $etudiantActif  }}
                                                    
                                                    </span>
                            </div>
                            <div class="col-auto">
                                <span class="badge badge-soft-danger">{{ ($etudiantActif*100)/$Etudiant }}%</span>
                            </div>
                        </div> <!-- end row -->

                       
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col-->

            <div class="col-lg-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase font-size-12 text-muted mb-3">Etudiant Non Actif</h6>
                                <span class="h3 mb-0">  @php
                                                         $etudiantNonActif =$User->where('idfonction', '=', 7)->where('status', '!=', 'ACTIF')->count()
                                                        @endphp 

                                                        {{ $etudiantNonActif  }} </span>
                            </div>
                            <div class="col-auto">
                                <span class="badge badge-soft-success">{{ ($etudiantNonActif*100)/$Etudiant }}%</span>
                            </div>
                        </div> <!-- end row -->

                     
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col-->

            <div class="col-lg-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase font-size-12 text-muted mb-3">Facultes</h6>
                                <span class="h3 mb-0"> {{ $faculte->count() }} </span>
                            </div>
                            
                        </div> <!-- end row -->

                       
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col-->

            <div class="col-lg-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase font-size-12 text-muted mb-3">Cours</h6>
                                <span class="h3 mb-0"> {{ $cours->count() }} </span>
                            </div>
                           
                        </div> <!-- end row -->

                      
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col-->
            
            <div class="col-lg-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase font-size-12 text-muted mb-3">Biliotheques</h6>
                                <span class="h3 mb-0"> {{ $bibliotheque->count() }} </span>
                            </div>
                            <div class="col-auto">
                                <span class="badge badge-soft-danger">100%</span>
                            </div>
                        </div> <!-- end row -->

                      
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col-->

            <div class="col-lg-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase font-size-12 text-muted mb-3">Bibliotheque Actif</h6>
                                <span class="h3 mb-0">
                                    @php
                                        $allbil= $bibliotheque->where('status','=','public')->count()
                                    @endphp
                                     {{ $allbil  }} </span>
                            </div>
                            <div class="col-auto">
                                <span class="badge badge-soft-success"> {{ ($allbil*100)/$bibliotheque->count() }}</span>
                            </div>
                        </div> <!-- end row -->

                       
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col-->

            <div class="col-lg-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase font-size-12 text-muted mb-3">Bibliotheque NON Actif</h6>
                                <span class="h3 mb-0">
                                    @php
                                        $allbilNONACTIF= $bibliotheque->where('status','!=','public')->count()
                                    @endphp
                                     {{ $allbilNONACTIF  }} </span>
                            </div>
                            <div class="col-auto">
                                <span class="badge badge-soft-success"> {{ ($allbilNONACTIF*100)/$bibliotheque->count() }}</span>
                            </div>
                        </div> <!-- end row -->

                     
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col-->



        </div>
        
        <!-- end row-->

        <div class="row">
           
            <div class="col-xl-12 col-lg-7">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Courbe de payement annuel</h4>
                        <p class="card-subtitle mb-4">Annee encours </p>

                        <div id="morris-bar-example" class="morris-chart"></div>

                    </div>
                </div>
            </div> <!-- end col-->
        </div>
        <!-- end row-->

        <div class="row">
            <div class="col-xl-6">
                <div class="card">
                    <div class="card-body">
        
                        <h4 class="card-title">les cinq derniers étudiants inscrits</h4>
                        <p class="card-subtitle mb-4">Transaction period from 21 July to 25 Aug</p>
                        
                        <div class="table-responsive">
                            <table class="table table-centered table-striped table-nowrap">
                                <thead>
                                    <tr>
                                        <th>Etudiants</th>
                                        <th>Telephone</th>
                                        <th>Email</th>
                                        <th>Code</th>
                                        <th>Date de creation</th>
                                    </tr>
                                </thead>
                                <tbody>
                                  
                                    @forelse ($utilisateursLimites as $Users)

                                    <tr>
                                        <td class="table-user">
                                        <img src="{{ asset( $Users->photo) }}" alt="table-user" class="mr-2 avatar-xs rounded-circle">
                                            <a href="javascript:void(0);" class="text-body font-weight-semibold">{{ $Users->nom }} {{ $Users->prenom }}</a>
                                        </td>
                                        <td>
                                        {{ $Users->tel }}
                                        </td>
                                        <td>
                                        {{ $Users->email }}
                                        </td>
                                        <td>
                                        {{ $Users->code }}
                                        </td>
                                        <td>
                                        {{ $Users->created_at }}
                                        </td>
                                    </tr>
                                        
                                    @empty
                                        
                                    @endforelse
                                    
                                    
                                  
                                    
                                </tbody>
                            </table>
                        </div>

                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col -->
            
            <div class="col-xl-6">
                <div class="card">
                    <div class="card-body">
        
                        <h4 class="card-title">Account Transactions</h4>
                        <p class="card-subtitle mb-4">Transaction period from 21 July to 25 Aug</p>
                        
                        <div class="table-responsive">
                            <table class="table table-borderless table-hover table-centered table-nowrap mb-0">
                                <tbody>
                                    <tr>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">4257 **** **** 7852</h5>
                                            <span class="text-muted font-size-12">11 April 2019</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">$79.49</h5>
                                            <span class="text-muted font-size-12">Amount</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-17 mb-1 font-weight-normal"><i class="fab fa-cc-visa"></i></h5>
                                            <span class="text-muted font-size-12">Card</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">Helen Warren</h5>
                                            <span class="text-muted font-size-12">Pay</span>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">4265 **** **** 0025</h5>
                                            <span class="text-muted font-size-12">28 Jan 2019</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">$1254.00</h5>
                                            <span class="text-muted font-size-12">Amount</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-17 mb-1 font-weight-normal"><i class="fab fa-cc-stripe"></i></h5>
                                            <span class="text-muted font-size-12">Card</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">Kayla Lambie</h5>
                                            <span class="text-muted font-size-12">Pay</span>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">5570 **** **** 8547</h5>
                                            <span class="text-muted font-size-12">08 Dec 2018</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">$784.25</h5>
                                            <span class="text-muted font-size-12">Amount</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-17 mb-1 font-weight-normal"><i class="fab fa-cc-amazon-pay"></i></h5>
                                            <span class="text-muted font-size-12">Card</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">Hugo Lavarack</h5>
                                            <span class="text-muted font-size-12">Pay</span>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">7845 **** **** 5214</h5>
                                            <span class="text-muted font-size-12">03 Dec 2018</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">$485.24</h5>
                                            <span class="text-muted font-size-12">Amount</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-17 mb-1 font-weight-normal"><i class="fab fa-cc-visa"></i></h5>
                                            <span class="text-muted font-size-12">Card</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">Amber Scurry</h5>
                                            <span class="text-muted font-size-12">Pay</span>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">4257 **** **** 7852</h5>
                                            <span class="text-muted font-size-12">12 Nov 2018</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">$8964.04</h5>
                                            <span class="text-muted font-size-12">Amount</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-17 mb-1 font-weight-normal"><i class="fab fa-cc-visa"></i></h5>
                                            <span class="text-muted font-size-12">Card</span>
                                        </td>
                                        <td>
                                            <h5 class="font-size-15 mb-1 font-weight-normal">Caitlyn Gibney</h5>
                                            <span class="text-muted font-size-12">Pay</span>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>

                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col -->
        </div>
        <!-- end row-->

    </div> <!-- container-fluid -->
</div>
<!-- End Page-content -->

<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                2019 © Drezoc.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-right d-none d-sm-block">
                    Design & Develop by Myra
                </div>
            </div>
        </div>
    </div>
</footer>

</div>
@include('Backend.components.footer');