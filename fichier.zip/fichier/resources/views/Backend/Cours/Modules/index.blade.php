@include('Backend.components.header');
<!-- Plugins css -->
<link href="{{ asset('backend/plugins/datatables/dataTables.bootstrap4.css')}}')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/responsive.bootstrap4.css')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/buttons.bootstrap4.css')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/select.bootstrap4.css')}}" rel="stylesheet" type="text/css" />
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

  

    @if (session()->has('success'))
    <div class="col-lg-12">
        <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
    </div>
    @endif

    <div class="col-12">
        <div class="card">
            <div class="card-body">

            <div class="row">
                    <div class="col-lg-6">
                        <h4 class="card-title"><i class="fa fa-folder-open"></i> Liste des Modules du cours : {{ $cours->titre }} </h4><br>
                    </div>
                   
                </div> <!-- end row -->

          

                <table id="datatable-buttons" class="table table-striped dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>Titre ({{ $allmodule->count() }})</th>
                            <th>Prénom Professeur</th>
                            <th>Lien Vidéo</th>
                            <th>Créé le</th>
                            <th style="width:10%">Actions</th>
                        </tr>
                    </thead>
                    


                    <tbody>
                        @forelse ($allmodule as $allmodules )
                        <tr>

                       
                            <td><a href="{{ asset($allmodules->url_pdf) }}" target="_blank">{{ $allmodules->titre }}</a> </td>
                            <td> <a href="mailto:{{ $allmodules->emailUser }}" title="Contactez le professeur">{{  $allmodules->nomUser }}  {{  $allmodules->prenomUser }}</a> </td>
                           
                          
                            <td><a href="{{ asset($allmodules->url_video) }}" target="_blank"> Lien video</a></td>
                          
                            <td>{{ date('d/m/Y', strtotime($allmodules->created_at)) }} </td>
                            <td>
                                <div class="btn-group btn-group-sm" role="group">
                                    <button id="btnGroupDrop1" type="button"
                                        class="btn btn-outline-secondary dropdown-toggle " data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        Options <i class="mdi mdi-chevron-down"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                      
                                       
                                        <form action="{{ route('deleteModule', $allmodules->id) }}" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="dropdown-item" title="Supprimer le module" style="background-color:red;color:white"><i class="fas fa-trash-alt "></i> Supprimer
                                        </form>

                                    </div>
                                </div>

                            </td>


                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" align="center"> la liste des Cours est vide</td>
                        </tr>
                       
                        @endforelse
                    </tbody>
                </table>
            </div> <!-- end card body-->
        </div> <!-- end card -->
  

    @include('Backend.Cours.Modules.nouveau')
    @include('Backend.components.footer')
    <script src="{{ asset('backend/plugins/datatables/jquery.dataTables.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.bootstrap4.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.responsive.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.buttons.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.html5.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.flash.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.print.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.keyTable.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.select.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/pdfmake.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/vfs_fonts.js')}}"></script>
    <script src="{{ asset('backend/pages/datatables-demo.js')}}"></script>