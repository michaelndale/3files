<div class="modal fade" id="moduleModale" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">

    <form class="needs-validation" novalidate action="{{ route('saveModule.cours')}}" method="POST" enctype="multipart/form-data">
            @csrf
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>  Nouveau Module du cours</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

            <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Cours </label>
                    <input type="text"  value="{{ $cours->titre }}" class="form-control" placeholder="Titre" readonly >
                    <input type="hidden" name="idcours" value="{{ $cours->id }}" >
                   
                    <div class="invalid-tooltip">
                            Veuillez choisir le cours.
                    </div>
                </div>

            <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Titre Module </label>
                    <input type="text" name="moduletitre" class="form-control" id="validationTooltip01" placeholder="Titre" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le titre.
                        </div>
                </div>
               
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Url Video</label>
                    <input type="url" name="video" class="form-control" id="validationTooltip02" placeholder="Ponderation"  required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le volume.
                        </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Document PDF</label>
                    <input type="file" name="documentpdf" class="form-control" id="validationTooltip03" accept=".pdf" placeholder="Volume"  required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le document PDF.
                        </div>
                </div>


                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Description</label>
                    <textarea type="text" name="moduledescription" class="form-control" id="validationTooltip04" placeholder="description"  required style="height:200px">  </textarea>
                    <div class="invalid-tooltip">
                            Veuillez entrer le description.
                        </div>
                </div>
          
            </div>
           
           
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button class="btn btn-primary" name="saveDataModule"  type="submit">Enregistrer</button>
            </div>
        </div>
    </form>


    </div>
</div>