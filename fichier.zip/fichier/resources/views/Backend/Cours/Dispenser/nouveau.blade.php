<div class="modal fade" id="moduleModale" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">

    <form class="needs-validation" novalidate action="{{ route('save.dispenser')}}" method="POST">
            @csrf
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>  Nouveau</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

            <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Cours </label>
                    <select type="text" name="coursid" class="form-control" id="validationTooltip02" placeholder="Prenom"  required>
                        <option  value="" selected disabled>Choisie la cours</option>
                        @forelse ($allcour as $allcours)
                       <option value="{{ $allcours->id }}"> {{ $allcours->titre }} </option> 
                       @empty
                           La liste est vide
                       @endforelse
                    </select>
                   
                    <div class="invalid-tooltip">
                            Veuillez choisir le cours.
                    </div>
                </div>

            <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Personnel </label>
                    <select type="text" name="profid" class="form-control" id="validationTooltip02" placeholder="Prenom"  required>
                        <option  value="" selected disabled>Choisie un personnel</option>
                        @forelse ($allProf as $allProfs)
                       <option value="{{ $allProfs->idu }}"> {{ $allProfs->nom }}  {{ $allProfs->prenomp }} </option> 
                       @empty
                           La liste est vide
                       @endforelse
                    </select>
                    <div class="invalid-tooltip">
                            Veuillez entrer le personnel.
                        </div>
                </div>
               
               

              


          
            </div>
           
           
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button class="btn btn-primary" name="saveDataModule"  type="submit">Enregistrer</button>
            </div>
        </div>
    </form>


    </div>
</div>