<div class="modal fade" id="coursModale" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
    <form class="needs-validation" novalidate action="{{ route('save.cours')}}" method="POST">
            @csrf
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>  Nouveau Cours</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

            <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Titre </label>
                    <input type="text" name="titre" class="form-control" id="validationTooltip01" placeholder="Titre" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le titre.
                        </div>
                </div>
               
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Volume</label>
                    <input type="number" name="volume" class="form-control" id="validationTooltip02" placeholder="volume"  required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le volume.
                        </div>
                </div>

              
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Ponderation  (Heure)</label>
                    <input type="number" name="ponderation" class="form-control" id="validationTooltip03" placeholder="ponderation"  required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le ponderation.
                        </div>
                </div>


                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Description</label>
                    <textarea type="text" name="description" class="form-control" id="validationTooltip04" placeholder="description"  required style="height:200px">  </textarea>
                    <div class="invalid-tooltip">
                            Veuillez entrer le description.
                        </div>
                </div>
          
            </div>
           
           
            <div class="modal-footer">
                <button type="button" class="btn btn-denger" data-dismiss="modal">Annuler</button>
                <button class="btn btn-primary" name="saveData"  type="submit">Enregistrer</button>
            </div>
        </div>
    </form>


    </div>
</div>





<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>