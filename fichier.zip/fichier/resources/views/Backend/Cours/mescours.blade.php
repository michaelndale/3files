@include('Backend.components.header');
<!-- Plugins css -->
<link href="{{ asset('backend/plugins/datatables/dataTables.bootstrap4.css')}}')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/responsive.bootstrap4.css')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/buttons.bootstrap4.css')}}" rel="stylesheet" type="text/css" />
<link href="{{ asset('backend/plugins/datatables/select.bootstrap4.css')}}" rel="stylesheet" type="text/css" />
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

    @if (session()->has('success'))
    <div class="col-lg-12">
        <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
    </div>
    @endif

    <div class="col-12">
        <div class="card">
            <div class="card-body">

            <div class="row">
                    <div class="col-lg-6">
                        <h4 class="card-title"><i class="fa fa-list"></i> Liste des cours attribués </h4>
                    </div>
                    @if (Auth::user()->idfonction != 3)
                    <div class="col-lg-6">
                        <div class="text-lg-right mt-3 mt-lg-0">
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#coursModale">
                                <i class="mdi mdi-plus-circle mr-1"></i> Nouveau Cours
                            </button>
                        </div>
                    </div><!-- end col-->
                    @endif
                </div> <!-- end row -->


            

                <table id="datatable-buttons" class="table table-striped dt-responsive nowrap">
                    <thead>
                        <tr>
                            <th>Titre</th>
                            <th>Modules</th>
                            <th>Volume</th>
                            <th>Pondération</th>
                            <!--<th>Statut</th> -->
                            <th>Créé le</th>
                            <th style="width:10%">Actions</th>
                        </tr>
                    </thead>
                    


                    <tbody>
                        @forelse ($allcour as $allcours )
                        <tr>
                            <td><a href="{{ route('mes.modules.cours', $allcours->id) }}">{{ $allcours->titre }}</a> </td>
                            <td>
                                @php
                                    $countModule = DB::table('module_cours')
                                    ->where('cours_id', '=', $allcours->id)
                                    ->count();
                                @endphp

                                {{ $countModule }}
                            </td>
                            <td>{{ $allcours->volume }}</td>
                          
                            <td>{{ $allcours->pondelation }}</td>
                          
                            <td>{{ date('d/m/Y', strtotime($allcours->created_at)) }} </td>
                            <td>
                                <div class="btn-group btn-group-sm" role="group">
                                    <button id="btnGroupDrop1" type="button"
                                        class="btn btn-outline-secondary dropdown-toggle " data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        Options <i class="mdi mdi-chevron-down"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                        <a class="dropdown-item" href="{{ route('mes.modules.cours', $allcours->id) }}"><i class="fa fa-edit "></i> Listes de modules</a>
                                        @if (Auth::user()->idfonction != 3)
                                       
                                        <a class="dropdown-item" href="{{ route('edit.cours', $allcours->id) }}"><i class="fa fa-edit "></i> Modifier</a>

                                        <form action="{{ route('deleteCours', $allcours->id) }}" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="dropdown-item" title="Supprimer le personnel" style="background-color:red;color:white"><i class="fas fa-trash-alt "></i> Supprimer
                                        </form>

                                        @endif

                                    </div>
                                </div>

                            </td>


                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" aligne="center"> la liste des Cours est vide </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div> <!-- end card body-->
        </div> <!-- end card -->
    </div>

    @include('Backend.Cours.nouveau')
    @include('Backend.components.footer')
    <script src="{{ asset('backend/plugins/datatables/jquery.dataTables.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.bootstrap4.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.responsive.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.buttons.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.html5.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.flash.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/buttons.print.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.keyTable.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/dataTables.select.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/pdfmake.min.js')}}"></script>
    <script src="{{ asset('backend/plugins/datatables/vfs_fonts.js')}}"></script>
    <script src="{{ asset('backend/pages/datatables-demo.js')}}"></script>