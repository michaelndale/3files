@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

<div class="col-8" style="margin:auto">
<div class="card">
    <div class="card-body">
        <h4 class="card-title"><i class="fa fa-edit"></i> Modifier le Cours </h4>

    <form class="needs-validation" novalidate action="{{ route('update.cours', $cours->id)}}" method="POST">
            @csrf
            @method('PUT')
       
            <div class="modal-body">

            <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Titre </label>
                    <input type="text" name="titre" class="form-control" id="validationTooltip01" placeholder="Nom" value="{{ $cours->titre }}" required>
                    <!--<div class="invalid-tooltip">
                            Veuillez entrer le titre.
                        </div>-->
                </div>
               
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Volunme</label>
                    <input type="number" name="volume" class="form-control" id="validationTooltip02" placeholder="Volunme" value="{{ $cours->volume }}" required />
                    <!--<div class="invalid-tooltip">
                            Veuillez entrer le volume.
                        </div>-->
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Ponderation  (Heure)</label>
                    <input type="number" name="ponderation" class="form-control" id="validationTooltip03" placeholder="ponderation" value="{{ $cours->pondelation }}" required>
                    <!--<div class="invalid-tooltip">
                            Veuillez entrer le ponderation.
                        </div>-->
                </div>


                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Description</label>
                    <textarea type="text" name="description" class="form-control" id="validationTooltip04" placeholder="description"  required style="height:200px"> {{ $cours->description }}  </textarea>
                    <!--<div class="invalid-tooltip">
                            Veuillez entrer le description.
                        </div>-->
                </div>
          
            </div>
           
           
            <div class="modal-footer">
                <!--<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>-->
                <button class="btn btn-primary" name="saveData"  type="submit">Enregistrer</button>
            </div>
        </div>
    </form>


    </div>
</div>

@include('Backend.components.footer')
<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>