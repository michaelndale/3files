<div class="modal fade" id="classeModale" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">

    <form class="needs-validation" novalidate action="{{ route('save.faculte')}}" method="POST">
            @csrf
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i>  Nouvelle faculte</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Libelle </label>
                    <input type="text" name="libelle" class="form-control" id="validationTooltip01" placeholder="Libelle" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le libelle.
                        </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button class="btn btn-primary" name="saveData"  type="submit">Enregistrer</button>
            </div>
        </div>
    </form>


    </div>
</div>