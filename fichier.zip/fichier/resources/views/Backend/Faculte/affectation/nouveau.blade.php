<div class="modal fade" id="classeModale" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">

        <form class="needs-validation" novalidate action="{{ route('savefacultecours')}}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-circle"></i> Nouveau affectation cours</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                <div class="col-md-12 mb-12">
                        <label for="validationTooltip01">Facultes </label>
                        <input type="text" class="form-control" value="{{ $oneFaculte->libelle }} " required readonly>
                        <input type="hidden" name="faculte_id" class="form-control" value="{{ $oneFaculte->id }} " required readonly>
                     
                    </div>

                    <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Cours </label>
                    <select type="text" name="cours_id" class="form-control" id="validationTooltip02" placeholder="Prenom"  required>
                        <option  value="" selected disabled>Choisie la cours</option>
                        @forelse ($allcour as $allcours)
                       <option value="{{ $allcours->id }}"> {{ $allcours->titre }} </option> 
                       @empty
                           La liste est vide
                       @endforelse
                    </select>
                    <div class="invalid-tooltip">
                            Veuillez choisir la fonction.
                    </div>
                </div>

                <div class="col-md-12 mb-12">
                    <label for="validationTooltip02">Annee scolaire </label>
                    <select type="text" name="annee_id" class="form-control" id="validationTooltip02" placeholder="Prenom"  required>
                        <option  value="" selected disabled>Choisie l'annee</option>
                        @forelse ($allanne as $allannes)
                       <option value="{{ $allannes->id }}"> {{ $allannes->libelle }} </option> 
                       @empty
                           La liste est vide
                       @endforelse
                    </select>
                    <div class="invalid-tooltip">
                            Veuillez choisir l'annee scolaire.
                    </div>
                </div>
                   
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button class="btn btn-primary" name="saveData" type="submit">Enregistrer</button>
                </div>
            </div>
        </form>


    </div>
</div>