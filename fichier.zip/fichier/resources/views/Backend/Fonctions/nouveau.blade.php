@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')
<div class="col-8" style="margin:auto">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title"><i class="fa fa-plus-circle"></i> Nouvelle Fonction</h4>
            <form class="needs-validation" novalidate action="{{ route('save.fonction')}}" method="POST">
                @csrf
                
                <div class="form-row">
                    <div class="col-md-12 mb-12">
                        <label for="validationTooltip01">Titre </label>
                        <input type="text" name="titre" class="form-control" id="validationTooltip01" placeholder="Titre" required>
                        <div class="invalid-tooltip">
                                Veuillez entrer le transliterator_create.
                            </div>
                    </div>
                </div>
                <br>
                <button class="btn btn-primary" name="saveData"  type="submit">Enregistrer</button>
            </form>

        </div> <!-- end card-body-->
    </div> <!-- end card -->
</div>
@include('Backend.components.footer')
<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>