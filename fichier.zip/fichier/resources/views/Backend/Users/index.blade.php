@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')

@if (session()->has('success'))
    <div class="col-lg-12">
        <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
    </div>
    @endif

<div class="col-xl-12">
    <div class="card">
        <div class="card-body">

            <div class="row">
                <div class="col-lg-6">
                    <h4  class="card-title"><i class="fa fa-users "></i> Liste des Personnels </h4>
                </div>
              
                <div class="col-lg-6">
                    <div class="text-lg-right mt-3 mt-lg-0">
                        <a href="{{ route('nouveau.personnel') }}" type="button" class="btn btn-primary" >
                            <i class="mdi mdi-plus-circle mr-1"></i> Nouveau personnel
                        </a>
                    </div>
                </div><!-- end col-->
             
            </div> <!-- end row -->

            <br>

            <div class="table-responsive">
                <table class="table table-centered table-striped table-nowrap">
                    <thead>
                        <tr>
                            <th>Nom & Prénom</th>
                            <th>Fonction</th>
                            <th>Genre</th>
                            <th>Email</th>
                            <th>Téléphone</th>
                            <th>Statut</th>
                            <th>Créé le</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        @forelse ($allUser as $allUsers )
                        <tr>
                            <td class="table-user">
                                <img src="{{ asset( $allUsers->photo) }}" alt="table-user" class="mr-2 avatar-xs rounded-circle">
                                <a href="javascript:void(0);" class="text-body font-weight-semibold">{{ $allUsers->nomp }} {{ $allUsers->prenom }}</a>
                            </td>
                            <td>{{ $allUsers->titreFonction }}</td>
                            <td>{{ $allUsers->sexe }}</td>
                            <td>{{ $allUsers->email }}</td>
                            <td>{{ $allUsers->tel }}</td>
                            <td>{{ $allUsers->status }}</td>
                            <td>{{ date('d/m/Y', strtotime($allUsers->created_at)) }}
                            </td>
                            <td>

                                <div class="btn-group btn-group-sm" role="group">
                                    <button id="btnGroupDrop1" type="button"
                                        class="btn btn-outline-secondary dropdown-toggle " data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                        Options <i class="mdi mdi-chevron-down"></i>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                        <a class="dropdown-item" href="{{ route('voir.personnel', $allUsers->idu) }}"><i class="fas fa-eye "></i> Voir</a>
                                        <a class="dropdown-item" href="{{ route('afficher.personnel', $allUsers->idu) }}"><i class="fa fa-edit "></i> Modifier</a>

                                        <form action="{{ route('deletePersonnel', $allUsers->idu) }}" method="post">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="dropdown-item" title="Supprimer l'etudiant" style="background-color:red;color:white"><i class="fas fa-trash-alt "></i> Supprimer
                                        </form>

                                    </div>
                                </div>

                                <!-- <button type="button" class="btn btn-outline-success btn-rounded btn-sm"><i class="fa fa-edit"></i></button>
                        <button type="button" class="btn btn-outline-info btn-rounded btn-sm"><i class="fa fa-edit"></i></button>
                       

                        <form action="{{ route('deletePersonnel', $allUsers->id) }}" method="post">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit"  class="btn btn-outline-danger btn-rounded btn-sm" title="Supprimer le personnel"><i class="fa fa-edit "></i>
                    </form>-->

                            </td>


                        </tr>
                        @empty
                        la liste des personnels est vide
                        @endforelse



                    </tbody>
                </table>
            </div>

        </div> <!-- end card-body-->
    </div> <!-- end card-->
</div>



@include('Backend.components.footer')