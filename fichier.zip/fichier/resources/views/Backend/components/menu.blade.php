<body>

    <!-- Begin page -->
    <div id="layout-wrapper">

        <!-- ========== Left Sidebar Start ========== -->
        <div class="vertical-menu">

            <div data-simplebar class="h-100">

                <!-- LOGO -->
                <div class="navbar-brand-box">
                    <a class='logo' href="{{ route('tableaudebord') }}">
                        <span>
                            <img src="{{ asset('backend/images/logo-light.png') }}" alt="" height="35">
                        </span>
                        <i>
                            <img src="{{ asset('backend/images/logo-small.png') }}" alt="" height="35">
                        </i>
                    </a>
                </div>

                <!--- Sidemenu -->
                <div id="sidebar-menu">
                    <!-- Left Menu Start -->
                    <ul class="metismenu list-unstyled" id="side-menu">
                        <li class="menu-title">Menu</li>

                        <li>
                            <a href="{{ route('tableaudebord') }}"><i class="feather-home"></i><span>Tableau de bord</span></a>
                        </li>

                       

                        @if (Auth::user()->idfonction != 3)

                        <li>
                            <a href="{{ route('listes.etudiant') }}"><i class="fa fa-users"></i><span> Etudiant </span></a>
                        </li>


                        
                        <li>
                            <a href="{{ route('personnel') }}"><i class="feather-users"></i> <span> Personnel</span></a>
                        </li>

                     

                        @endif

                        <li>
                            <a href="javascript: void(0);" class="has-arrow"><i class="feather-book"></i> <span>Cours</span></a>
                            <ul class="sub-menu" aria-expanded="false">
                            @if (Auth::user()->idfonction != 3)
                                <li><a href="{{ route('listes.cours')}}">Liste</a></li>
                                <li><a href="{{ route('dispenser.cours')}}">Dispensations</a></li>
                                <li><a href="{{ route('mes.cours')}}">Mes cours</a></li>
                            @else
                              <li><a href="{{ route('mes.cours')}}">Mes cours</a></li>
                              @endif

                            </ul>
                        </li>

                        <li>
                            <a href="javascript: void(0);" class="has-arrow"><i class="feather-check-square"></i><span></span> Examen</a>
                            <ul class="sub-menu" aria-expanded="false">
                                <li><a href="{{ route('listes.examen') }}">Liste Examen</a></li>
                                <li><a href="{{ route('listes.resultat') }}">Resultat</a></li>
                            </ul>
                        </li>
                        @if (Auth::user()->idfonction != 3)
                        <li>
                            <a href="javascript: void(0);" class="has-arrow"><i class="feather-settings"></i> <span>Outils</span></a>
                            <ul class="sub-menu" aria-expanded="false">
                              
                                <li><a href="{{ route('fonction') }}">Fonctions</a></li>
                                <li><a href="{{ route('faculte')  }}">Facultes</a></li>
                                <li><a href="{{ route('annee') }}">Annee Scolaire</a></li>
                               
                            </ul>
                        </li>


                       

                        <li>
                            <a href="javascript: void(0);" class="has-arrow"><i class="feather-pocket"></i><span>Payement</span></a>
                            <ul class="sub-menu" aria-expanded="false">
                                <li><a href='{{ route('payement') }}'>Liste</a></li>
                                <li><a href="{{ route('facturations.index') }}">Facturations</a></li>
                               
                            </ul>
                        </li>

                        @php
                            $nombreBio = DB::table('bibliotheques')->where('status', '=', 'prive')->count();
                        @endphp

                            <li>
                                <a href="{{ route('listes.bibliotheque') }}">
                                    <i class="feather-layers"></i>
                                    @if ($nombreBio > 0)
                                        <span class="badge badge-pill badge-primary float-right">{{ str_pad($nombreBio, 2, '0', STR_PAD_LEFT) }}</span>
                                    @endif
                                    <span>Bibliothèque</span>
                                </a>
                            </li>

                            <li>
                                <a href="{{ route('listes.blog') }}"><i class="feather-message-square"></i> <span> Blog</span></a>
                            </li>

                            <li>
                                <a href="/"><i class="feather-message-square"></i> <span> Site</span></a>
                            </li>
    


                       

                       
                        @endif

                    </ul>
                </div>
                <!-- Sidebar -->
            </div>
        </div>