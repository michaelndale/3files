<div class="main-content">

    <header id="page-topbar">
        <div class="navbar-header">
            <div class="d-flex align-items-center">
                <button type="button" class="btn btn-sm mr-2 d-lg-none header-item" id="vertical-menu-btn">
                    <i class="fa fa-fw fa-bars"></i>
                </button>

                <div class="header-breadcumb">
                    <h6 class="header-pretitle d-none d-md-block">
                        ENSEIGNANT <i class="dripicons-arrow-thin-right"></i>
                        Examinateur <i class="dripicons-arrow-thin-right"></i> 
                        Comptable  <i class="dripicons-arrow-thin-right"></i> 
                        BIBLIOTHECAIRE <i class="dripicons-arrow-thin-right"></i> 
                        PUBLICITAIRE
                         </h6>
                    <h2 class="header-title"><i class="feather-database"></i>  Gestionnaire </h2>
                </div>
            </div>
            <div class="d-flex align-items-center">

          

                @include('Backend.components.notification')

                <div class="dropdown d-inline-block ml-2">
                    <button type="button" class="btn header-item" id="page-header-user-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img class="rounded-circle header-profile-user" src="{{  asset(Auth::user()->photo) }}" alt=" {{ ucfirst(Auth::user()->prenom) }}">
                        <span class="d-none d-sm-inline-block ml-1"> {{ ucfirst(Auth::user()->prenom) }}</span>
                        <i class="mdi mdi-chevron-down d-none d-sm-inline-block"></i>
                    </button>
                    <div class="dropdown-menu dropdown-menu-right">

                       
                        <a class="dropdown-item d-flex align-items-center justify-content-between" href="{{ route('profile.personnel', Auth::user()->id ) }}">
                            <span> <i class="fa fa-user"></i> Profile</span>
                        </a>
                      
                        <a class="dropdown-item d-flex align-items-center justify-content-between" href="{{ route('admindeconnexion') }}">
                            <span><i class="fa fa-logout"></i>  Se deconnecter</span>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </header>

    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
               