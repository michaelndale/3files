@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')
<div class="col-5" style="margin:auto">
<div class="card">
    <div class="card-body">
        <h4 class="card-title"><i class="fa fa-edit"></i> La Classe </h4>
       
        <form class="needs-validation" novalidate action="{{ route('update.classe', $oneClasse->id)}}" method="POST">
            @csrf
            @method('PUT')
            
            <div class="form-row">
                <div class="col-md-12 mb-12">
                    <label for="validationTooltip01">Libelle </label>
                    <input type="text" name="libelle" class="form-control" id="validationTooltip01" placeholder="Nom" value="{{ $oneClasse->libelle }}" required>
                    <div class="invalid-tooltip">
                            Veuillez entrer le libelle.
                     </div>
                </div>
               
            </div>
            
            <br>
            <button class="btn btn-primary" name="saveData"  type="submit">Sauvegarder </button>
        </form>

    </div> <!-- end card-body-->
</div> <!-- end card -->
</div>

@include('Backend.components.footer')
<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>