@include('Backend.components.header');
@include('Backend.components.menu')
@include('Backend.components.menu_vertical')
<div class="col-5" style="margin:auto">
<div class="card">
    <div class="card-body">
        <h4 class="card-title"><i class="fas fa-eye"></i> Modifier la Classe </h4>
       
        <form class="needs-validation" novalidate action="{{ route('update.classe')}}" method="POST">
            @csrf
            
            <div class="form-row">
                <div class="col-md-12 mb-12">
                  
                  Classe:  {{ $oneClasse->libelle }}
                  
                </div>
               
            </div>
            
          
        </form>

    </div> <!-- end card-body-->
</div> <!-- end card -->
</div>

@include('Backend.components.footer')
<!-- Validation custom js-->
<script src="{{ asset('backend/pages/validation-demo.js')}}"></script>