<body data-offset="200" data-spy="scroll" data-target=".ow-navigation">
    <!-- LOADER -->
    <div id="site-loader" class="load-complete">
        <div class="loader">
            <div class="loader-inner ball-clip-rotate">
                <div></div>
            </div>
        </div>
    </div><!-- Loader /- -->
    <!-- Header -->
    <header class="header-main container-fluid no-padding">
        <!-- Top Header -->
        <div class="top-header container-fluid no-padding">
            <div class="container">
                <div class="topheader-left">
                    <a href="tel:+257 79380018" title="257 79380018"><i class="fa fa-mobile" aria-hidden="true"></i>+257
                        79380018 </a>
                    <a href="initelematique.itel@gmail.com" title="initelematique.itel@gmail.com"><i
                            class="fa fa-envelope-o" aria-hidden="true"></i>initelematique.itel@gmail.com</a>
                </div>
                <div class="topheader-right">

                    @if (!session(Auth::id()))

                        @if (Auth::user()->idfonction != 7)
                            <a href="{{ route('tableaudebord') }}" ><i class="fa fa-home"
                                    aria-hidden="true"></i>Tableau de bord</a>
                            <a href="javascript::;" ><i class="fa fa-user"
                                        aria-hidden="true"></i>{{ ucfirst(Auth::user()->prenom) }} </a>
                            <a href="{{ route('admindeconnexion') }}" ><i class="fa fa-logout"
                                    aria-hidden="true"></i>Se déconnecter</a>
                        @else
                            <a href="{{ route('bienvenue') }}" ><i class="fa fa-home"
                                    aria-hidden="true"></i>Espace Etudiant</a>
                            <a href="{{ route('profile') }}" ><i class="fa fa-user"
                                    aria-hidden="true"></i>{{ ucfirst(Auth::user()->prenom) }} </a>
                            <a href="{{ route('admindeconnexion') }}" ><i class="fa fa-logout"
                                    aria-hidden="true"></i>Se déconnecter</a>
                        @endif
                    @else
                        <a href="{{ route('login') }}" title="Se Connecter"><i class="fa fa-user"
                                aria-hidden="true"></i>Portaille Administration</a>
                        <a href="{{ route('portailetudiant') }}" title="Se Connecter"><i class="fa fa-user"
                                aria-hidden="true"></i>Portaille Etudiant</a>
                    @endif

                </div>
            </div>
        </div><!-- Top Header /- -->

        <!-- Menu Block -->
        <div class="menu-block container-fluid no-padding">
            <!-- Container -->
            <div class="container">
                <div class="row">
                    <!-- Navigation -->
                    <nav class="navbar ow-navigation">
                        <div class="col-md-3">
                            <div class="navbar-header">
                                <button aria-controls="navbar" aria-expanded="false" data-target="#navbar"
                                    data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a title="Logo" href="/" class="navbar-brand"><img
                                        src="{{ asset('frontend/images/logo.png') }}"
                                        alt="logo" style="width:29%" />E-LEARNING<span>Education en ligne</span></a>
                                <a href="/" class="mobile-logo" title="Logo">
                                    <h3>E-Learning</h3>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="navbar-collapse collapse" id="navbar">
                                <ul class="nav navbar-nav menubar">
                                    <li class="dropdown 
                                    @if($active=='Accueil')
                                        active
                                    @endif
                                    ">
                                        <a aria-expanded="false" aria-haspopup="true" href="/" role="button"
                                            class="dropdown-toggle" title="Home">Accueil</a>
                                        <i class="ddl-switch fa fa-angle-down"></i>
                                    </li>
                                   
                                    <li class="dropdown 
                                    @if($active=='A-propos')
                                        active
                                    @endif
                                    "><a href="{{ route('appropos') }}" title="A Propos">A Propos</a></li>
                                    <li class="dropdown 
                                    @if($active=='Cours')
                                        active
                                    @endif
                                    " >
                                        <a href="{{ route('cours.public') }}" title="Cours">Cours</a></li>
                                    
                                    <li class="dropdown 
                                        @if($active=='Bibliotheque')
                                            active
                                        @endif
                                        ">    <a href="{{ route('bibliotheque.public') }}" title="Bibliotehque">Bibliotheque</a></li>


                                        <li class="dropdown 
                                        @if($active=='Blog')
                                            active
                                        @endif
                                        ">  
                                        <a href="{{ route('blog.public') }}" title="Evenement">Blog</a></li>
                                    @if (!session(Auth::id()))
                                       
                                    <li class="dropdown 
                                        @if($active=='Forum')
                                        active
                                    @endif ""><a title="Forum" href="{{ route('forum') }}">Forum</a></li>
                                    @endif

                                    <li class="dropdown 
                                    @if($active=='Contact')
                                        active
                                    @endif
                                    ">  <a href="{{ route('contact') }}" title="Contact">Contact</a></li>

                                </ul>
                            </div>
                        </div>
                    </nav><!-- Navigation /- -->
                    <div class="menu-search">
                        <div id="sb-search" class="sb-search">
                            <form>
                                <input class="sb-search-input" placeholder="Enter your search term..." type="text"
                                    value="" name="search" id="search" />
                                <button class="sb-search-submit"><i class="fa fa-search"></i></button>
                                <span class="sb-icon-search"></span>
                            </form>
                        </div>
                    </div>
                </div>
            </div><!-- Container /- -->
        </div><!-- Menu Block /- -->
    </header>

    <!-- Header /- -->