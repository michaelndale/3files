@php
$nombre_livre  = DB::table('bibliotheques')
     ->where('status', '=', 'public')
     ->count()
@endphp

<div class="col-md-3 col-sm-4 event-sidebar">
    <div class="courses-features">
    <div class="featuresbox"><a href="{{ route('bienvenue') }}"> <img src="{{ asset('frontend/images/user-ic.png')}}" alt="user-ic" width="22" height="22" />
                <h3>Accuiel </h3>
            </a></div>

    @if($me->libelle_classe !== 'Terminer')

        <div class="featuresbox"><a href="{{ route('mescours') }}"><img src="{{ asset('frontend/images/codepen-ic.png')}}" alt="codepen-ic" width="22" height="22" />
            <h3>Cours </h3> </a>
        </div>
        <div class="featuresbox"><a href="{{ route('mespayements') }}"><img src="{{ asset('frontend/images/dolar-ic.png')}}" alt="dolar-ic" width="27" height="27" />
            <h3>Payement </h3></a>
        </div>
        <div class="featuresbox"><a href="{{ route('mesexamens') }}"><img src="{{ asset('frontend/images/codepen-ic.png')}}" alt="codepen-ic" width="22" height="22" />
            <h3>Examens </h3> </a>
        </div>

        <div class="featuresbox"><a href="{{ route('forum') }}"><img src="{{ asset('frontend/images/codepen-ic.png')}}" alt="codepen-ic" width="22" height="22" />
            <h3>Forum </h3> </a>
        </div>
    @endif
        <div class="featuresbox"><a href="{{ route('mesbibliotheques') }}"><img src="{{ asset('frontend/images/cup-ic.png')}}" alt="cup-ic" width="24" height="23" />
            <h3>Bibliotrheque </h3> </a><span> ({{ $nombre_livre }})</span>
        </div>
        <div class="featuresbox"><a href="{{ route('profile') }}"> <img src="{{ asset('frontend/images/user-ic.png')}}" alt="user-ic" width="22" height="22" />
                <h3>Profile </h3>
            </a></div>

    </div>
    
</div>