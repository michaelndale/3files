<footer class="footer-main container-fluid no-padding">	
		<!-- Container -->
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<aside class="ftr-widget about_widget">
						<a class="footer-logo" href="#" title="Logo"><img alt="logo" src="{{ asset('frontend/images/logo.png') }}">E-LEARNING<span>Éducation des meilleurs</span></a>
						<ul>
							<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#" title="Google Plus"><i class="fa fa-google-plus"></i></a></li> 
							<li><a href="#" title="Instagram"><i class="fa fa-instagram"></i></a></li>
							<li><a href="#" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
							<li><a href="#" title="Rss"><i class="fa fa-rss"></i></a></li>
						</ul>
						<p>
							Apprendre des cours en ligne
							Seules la patience et la persévérance donnent Bon résultat
							
							Le plus grand centre de livres et de bibliothèques au monde se trouve ici où vous pourrez étudier les dernières tendances en matière d'éducation.
							
						</p>
					</aside>
				</div>
				<div class="col-md-6 col-sm-6">
					<aside class="ftr-widget newsletter_widget">
						<h3 class="widget-title">Lettres d'information</h3>
						 <div class="input-group">
							<input type="text" class="form-control" placeholder="Entrez votre email">
							<span class="input-group-btn"><button class="btn" type="button" title="Sign In">Se connecter</button></span>
						</div>
					</aside>
				</div>
				<div class="col-md-6 col-sm-6">
					<aside class="ftr-widget upcomingevent_widget">
						<h3 class="widget-title">Événements à venir</h3>
						<div id="upcomingevent_carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner" role="listbox">
								<div class="item active">
									<div class="upcoming-eventbox">
										<p>
											
										Les programmes des cours reprend en janvier

										</p>
										<ul>
											<li><a href="#" title="Time"><i class="fa fa-clock-o" aria-hidden="true"></i>8:00 Heure - 17:00 Heure</a></li>
											<li><a href="#" title="Date"><i class="fa fa-calendar" aria-hidden="true"></i>01 janvier 2016</a></li>
											<li><a href="#" title="Location"><i class="fa fa-map-marker" aria-hidden="true"></i>Burundi, Bujumbura</a></li>
										</ul>
										
									</div>
								</div>
								
							</div>
							<a class="left carousel-control" href="#upcomingevent_carousel" role="button" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							</a>
							<a class="right carousel-control" href="#upcomingevent_carousel" role="button" data-slide="next">
								<i class="fa fa-angle-right"></i>
							</a>
						</div>
						
					</aside>
				</div>
				<div class="col-md-6 col-sm-6">
					<aside class="ftr-widget flickr_widget">
						<h3 class="widget-title">Notre galerie</h3>
						<ul>
							<li><a href="#" title="Flickr"><img src="{{ asset('frontend/images/flickr1.jpg') }}" alt="flickr1" width="85" height="83"/></a></li>
							<li><a href="#" title="Flickr"><img src="{{ asset('frontend/images/flickr2.jpg') }}" alt="flickr2" width="85" height="83"/></a></li>
							<li><a href="#" title="Flickr"><img src="{{ asset('frontend/images/flickr3.jpg') }}" alt="flickr3" width="85" height="83"/></a></li>
							<li><a href="#" title="Flickr"><img src="{{ asset('frontend/images/flickr4.jpg') }}" alt="flickr4" width="85" height="83"/></a></li>
							<li><a href="#" title="Flickr"><img src="{{ asset('frontend/images/flickr5.jpg') }}" alt="flickr5" width="85" height="83"/></a></li>
							<li><a href="#" title="Flickr"><img src="{{ asset('frontend/images/flickr6.jpg') }}" alt="flickr6" width="85" height="83"/></a></li>
						</ul>
					</aside>
				</div>
			</div>
			<!-- Footer Bottom -->
			<div class="footer-bottom col-md-12 col-sm-12 no-padding">
				<div class="copyright no-padding">
					<span>Copyright &copy; {{ date('Y') }}. All Rights Reserved.</span>
				</div>
				<nav class="navbar ow-navigation">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar2" aria-expanded="false" aria-controls="navbar">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
					</div>
					<div id="navbar2" class="navbar-collapse collapse">
						<ul class="nav navbar-nav">
							<li><a href="{{ route('accueil') }}" title="Accueil">Accueil</a></li>
							<li><a href="{{ route('cours.public') }}" title="cours">Cours</a></li>
							<li><a href="{{ route('bibliotheque.public') }}" title="Bibliotheque">Bibliotheque</a></li>
							<li><a href="{{ route('blog.public') }}" title="Actu">Blog</a></li>
							<li><a href="{{ route('appropos') }}" title="A Propos">A Propos</a></li>
						</ul>
					</div>
				</nav>
			</div><!-- Footer Bottom /- -->
		</div><!-- Container /- -->
	</footer><!-- Footer /- -->
	
	<!-- JQuery v1.11.3 -->	
	<script src="{{ asset('frontend/js/jquery.min.js') }}"></script>
	<!--script src="js/jquery.knob.js"></script-->
	
	<!-- Library - Js -->
	<script src="{{ asset('frontend/libraries/lib.js') }}"></script><!-- Bootstrap JS File v3.3.5 -->
	<!-- Library - Google Map API -->
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp"></script>
	
	<!-- Library - Theme JS -->
	<script src="{{ asset('frontend/js/functions.js') }}"></script>
</body>
</html>