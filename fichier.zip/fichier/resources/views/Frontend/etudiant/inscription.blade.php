<!DOCTYPE html>
<html lang="fr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <meta charset="utf-8" />
    <title>Inscription - E-learning</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="{{ asset('backend/images/favicon.ico') }}">
    <link href="{{ asset('backend/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('backend/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
    <link href="{{ asset('backend/css/theme.min.css') }}" rel="stylesheet" type="text/css" />
</head>

<body>

    <div class="bg-primary">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="d-flex align-items-center min-vh-100">
                        <div class="w-100 d-block bg-white shadow-lg rounded my-5">
                            <div class="row">
                                <div class="col-lg-5 d-none d-lg-block bg-register rounded-left"></div>
                                <div class="col-lg-7">
                                    <div class="p-5">
                                        <div class="text-center">
                                            <a class='d-block mb-5' href='index.html'>
                                                <img src="{{ asset('backend/images/logo-dark.png')}}" alt="app-logo" height="18" />
                                            </a>
                                        </div>

                                        @if (session()->has('success'))
                                        <div class="col-lg-12">
                                            <div class="alert alert-success">
                                                <i class="fa fa-check-circle"></i>
                                                {{ session()->get('success') }}
                                                <a href="{{ route('portailetudiant')}}"> Se connecter. </a>
                                            </div>
                                        </div>
                                        @endif
                                        <h1 class="h5 mb-1">Créez un compte ! </h1>
                                        <p class="text-muted mb-4">Vous n'avez pas de compte ? Créez votre propre compte, cela prend moins d'une minute</p>
                                        <form id="registrationForm" class="needs-validation" novalidate action="{{ route('save.etudiant')}}" method="POST" autocomplete="off">
                                            @csrf
                                            <div class="form-group row">
                                                <div class="col-sm-6 mb-3 mb-sm-0">
                                                    <input type="text" name="nom" class="form-control form-control-user" placeholder="Nom" autofocus required autocomplete="off">
                                                    <div class="invalid-tooltip">Veuillez entrer le nom.</div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <input type="text" name="prenom" class="form-control form-control-user" placeholder="Prénom" required autocomplete="off">
                                                    <div class="invalid-tooltip">Veuillez entrer le prénom.</div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <input type="email" name="email" class="form-control form-control-user" placeholder="Adresse Email " autocomplete="off" required>
                                                <div class="invalid-tooltip">Veuillez entrer l'e-mail.</div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-sm-6 mb-3 mb-sm-0">
                                                    <input type="password" name="password" class="form-control form-control-user" placeholder="Mot de passe" required>
                                                    <div class="invalid-tooltip">Veuillez entrer le mot de passe.</div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <input type="password" name="cpassword" class="form-control form-control-user" placeholder="Confirme le mot de passe" required oninput="checkPasswordMatch()">
                                                    <div class="invalid-tooltip">Confirmer le mot de passe.</div>
                                                   
                                                </div>

                                              
                                                <div class="col-sm-12">
                                                <div id="passwordMatchError" class="text-danger" style="display: none; text-align: center;">
                                                    <i class="fa fa-info-circle"></i> Les mots de passe ne correspondent pas.
                                                </div>
                                                </div>
                                                
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-sm-12">
                                                    <input type="text" class="form-control form-control-user" value="Anne scolaire: {{ $anneScolaire->libelle }}" required readonly>
                                                    <input type="hidden" name="annee_id" value="{{ $anneScolaire->id }}" />
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-6 mb-12">
                                                    <select name="faculte_id" class="form-control" id="faculteid" required onchange="fetchClasses()">
                                                        <option value="" selected disabled>Choisie la faculte</option>
                                                        @forelse ($faculte as $facultes)
                                                        <option value="{{ $facultes->id }}"> {{ $facultes->libelle }} </option>
                                                        @empty
                                                        <option disabled>La liste est vide</option>
                                                        @endforelse
                                                    </select>
                                                </div>
                                                <div class="col-md-6 mb-12">
                                                    <select name="classe_id" class="form-control" id="classeid" required>
                                                        <option value="" selected disabled>Choisie la classe</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <button type="submit" id="submitButton" class="btn btn-success btn-block" disabled> Enregistrer le compte</button>
                                        </form>

                                        <div class="row mt-4">
                                            <div class="col-12 text-center">
                                                <p class="text-muted mb-0"> J'ai déjà un compte <a class='text-muted font-weight-medium ml-1' href="{{  route('portailetudiant') }}"><b>Se connecter</b></a></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function fetchClasses() {
            const faculteId = document.getElementById('faculteid').value;
            const classeSelect = document.getElementById('classeid');
            classeSelect.innerHTML = '<option value="" selected disabled>Chargement...</option>';

            const url = '{{ route("getFaculteClasse") }}?faculte_id=' + faculteId;

            fetch(url)
                .then(response => response.json())
                .then(data => {
                    classeSelect.innerHTML = '<option value="" selected disabled>Choisie la classe</option>';
                    if (data.length === 0) {
                        classeSelect.innerHTML += '<option disabled>Aucune classe disponible</option>';
                    } else {
                        data.forEach(classe => {
                            classeSelect.innerHTML += `<option value="${classe.id}">${classe.libelle}</option>`;
                        });
                    }
                })
                .catch(error => {
                    console.error('Error fetching classes:', error);
                    classeSelect.innerHTML = '<option disabled>Error loading classes</option>';
                });
        }

        function checkPasswordMatch() {
            const password = document.querySelector('input[name="password"]').value;
            const confirmPassword = document.querySelector('input[name="cpassword"]').value;
            const errorDiv = document.getElementById('passwordMatchError');
            const submitButton = document.getElementById('submitButton');
            
            if (password !== confirmPassword) {
                errorDiv.style.display = 'block';
                submitButton.disabled = true;
            } else {
                errorDiv.style.display = 'none';
                submitButton.disabled = false;
            }
        }

        function validateForm() {
            const form = document.getElementById('registrationForm');
            const inputs = form.querySelectorAll('input[required], select[required]');
            let allFilled = true;

            inputs.forEach(input => {
                if (!input.value) {
                    allFilled = false;
                }
            });

            document.getElementById('submitButton').disabled = !allFilled;
        }

        document.querySelectorAll('input[required], select[required]').forEach(input => {
            input.addEventListener('input', validateForm);
        });
    </script>

    <script src="{{ asset('backend/js/jquery.min.js') }}"></script>
    <script src="{{ asset('backend/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('backend/js/metismenu.min.js') }}"></script>
    <script src="{{ asset('backend/js/waves.js') }}"></script>
    <script src="{{ asset('backend/js/simplebar.min.js') }}"></script>
    <script src="{{ asset('backend/js/theme.js') }}"></script>
</body>

</html>