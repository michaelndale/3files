@include('Frontend.components.header')
@include('Frontend.components.menu')
<!-- PageBanner -->
<div class="container-fluid no-padding pagebanner">
	<div class="container">
		<div class="pagebanner-content" style="height:10px">
			<h3> Cours</h3>
			<ol class="breadcrumb">
				<li><a href="index.html">Code matricule</a></li>
				<li>{{ $me->code  }}</li>
				<li>Bienvenu</li>
			</ol>
		</div>
	</div>
</div><!-- PageBanner /- -->
<div class="container coursesdetail-section">
	<div class="section-padding"></div>
	<div class="row">

		@include('Frontend.components.menuetudiant')



		<div class="col-md-9 col-sm-8 event-contentarea">
			<div class="coursesdetail-block">

				<div class="courses-curriculum">
					<h3 class="course-title">Listes des cours</h3>

					<div class="courses-sections-block">
						@forelse ($coursetuadiant as $coursetuadiants)
						
						
						
						
						
						<div class="courses-lecture-box">
							<i class="fa fa-file-o" aria-hidden="true"></i>
							<span class="lecture-no"><b> <a href="{{ route('contenu.cours', $coursetuadiants->slug) }}" title="{{ $coursetuadiants->titre }}">
								{{ $coursetuadiants->titre }}
							</a></b> , </span>
							<span class="lecture-title"> Ponderation : {{ $coursetuadiants->pondelation }}</span>
							<span class="lecture-time">Heure : {{ $coursetuadiants->volume }} H</span>
						</div>
						</a>
						@empty
						<div class="col-lg-12">
                                            <div class="alert alert-success">
                                                <i class="fa fa-check-circle"></i>
                                             
                                                Pas des cours disponible pour cette Faculte, revener plus tard

                                            </div>
                                        </div>
						@endforelse
						

					</div>
				</div>

			</div>

		</div>

	</div>

</div>

@include('Frontend.components.footer')