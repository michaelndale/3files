@include('Frontend.components.header')
@include('Frontend.components.menu')

<!-- PageBanner -->
<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content" style="height:10px">
            <h3>Examens</h3>
            <ol class="breadcrumb">
                <li><a href="index.html">Code matricule</a></li>
                <li>{{ $me->code }}</li>
                <li>Bienvenu</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->

<div class="container coursesdetail-section">
    <div class="section-padding"></div>
    <div class="row">
        @include('Frontend.components.menuetudiant')

        <div class="col-md-9 col-sm-8 event-contentarea">
            <div class="coursesdetail-block">
                <div class="courses-curriculum">
                    <h3 class="course-title">Listes des examens</h3>
                    @include('Backend.components.messagre')

                    <div class="courses-sections-block">
                        @forelse ($examen as $examens)
                        <a href="{{ route('commencer.examen', $examens->id) }}" title="{{ $examens->titre_cours }}">
                            <div class="courses-lecture-box">
                                <i class="fa fa-file-o" aria-hidden="true"></i>
                                <span class="lecture-no"><b>{{ $examens->titre_cours }}</b> , </span>
                                <span class="lecture-title"> Nombre question: {{ $examens->nombreQuestion }} , Date  : {{ $examens->dateexamen }}</span>
                                <span class="lecture-time">{{ $examens->heuredebut }} - {{ $examens->heurefin }}</span>
                            </div>
                        </a>
                        @empty
                        <div class="col-lg-12">
                            <div class="alert alert-danger">
                                <i class="fa fa-times-circle"></i>
                                Pas d'examens disponibles pour l'instant, revenez plus tard.
                            </div>
                        </div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@include('Frontend.components.footer')
