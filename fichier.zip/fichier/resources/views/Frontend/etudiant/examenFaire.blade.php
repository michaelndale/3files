@include('Backend.components.header')

<div id="layout-wrapper">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8" style="margin:auto">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Examens du cours: {{ $examen->titre_cours }}</h4>
                            <p class="card-subtitle mb-4">
                               
								<p>Nombre de questions : {{ $questions->count() }}</p>
								<p>Question {{ $questionIndex + 1 }} sur {{ $questions->count() }}</p>
                            </p>

                            <!-- Formulaire pour afficher une question à la fois -->
							<form  action="{{ route('examen.repondre', ['id' => $examen->id, 'index' => $questionIndex + 1]) }}" method="POST">
								@csrf
								<div class="question-box">
									<h4>Question {{ $questionIndex + 1 }} : {{ $questionActuelle->titre }}</h4>
									@foreach ($questionActuelle->choixes as $choix)
										<div style="padding-left: 20px;">
											<input type="radio" name="reponse" value="{{ $choix->id }}" required>
											<label>{{ $choix->titre }}</label>
										</div>
									@endforeach
								</div>
								<BR>
								<button type="submit" class="btn btn-primary">Suivant</button>
							</form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@include('Backend.components.footer')












