@include('Frontend.components.header')
@include('Frontend.components.menu')
<!-- PageBanner -->
<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content" style="height:10px">
            <h3> {{ $me->nom }} {{ $me->prenom }}</h3>
            <ol class="breadcrumb">
                <ol class="breadcrumb">
                    <li><a href="index.html">Code matricule</a></li>
                    <li>{{ $me->code  }}</li>
                    <li>Profile</li>
                </ol>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->
<div class="container coursesdetail-section">
    <div class="section-padding"></div>
    <div class="row">

        @include('Frontend.components.menuetudiant')

        @if ($completionPercentage < 98)
                  
                        <div class="col-lg-9">
                            <div class="detail-review" style="width:100%; padding:5px">
                               
                                    <h4 class="card-title">Complétez votre compte</h4>

                                    <div class="container">
                                        <h5><i class="fa fa-user"></i> {{ $user->code }} : {{ $user->prenom }} </h5>

                                        <!-- Affichage de la barre de progression -->
                                        <div class="progress" style="width: 70%;">
                                            <div class="progress-bar" role="progressbar"
                                                style="width: {{ round($completionPercentage) }}%;"
                                                aria-valuenow="{{ round($completionPercentage) }}" aria-valuemin="0"
                                                aria-valuemax="100">
                                                {{ round($completionPercentage) }}% Complété
                                            </div>
                                        </div>

                                        <p class="card-text">Pour un profil complet, vous devez remplir toutes les
                                            informations de votre profil.</p>
                                      

                                </div>
                            </div>
                            <br><br>
                        </div>
                    

                @endif


        <div class="col-md-9 col-sm-8 event-contentarea">
            <div class="coursesdetail-block">

                @if (session()->has('success'))
                <div class="col-lg-12">
                    <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
                </div>
                @endif

                @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif

                <!-- Display Exception Errors -->
                @if ($errors->has('exception'))
                <div class="alert alert-danger">
                    <strong>{{ $errors->first('exception') }}</strong>
                </div>
                @endif



                <div class="col-md-10">

                    <div class="col-md-12 accordion-section">
                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="accordion_1">
                                    <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#accordion1" aria-expanded="true" aria-controls="accordion1">Information du compte</a>
                                    </h4>
                                </div>
                                <div id="accordion1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="accordion_1">
                                    <div class="panel-body">
                                        <div class="row">
                                            <div class="col-md-6 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Code matricule</label>
                                                    <input type="text" value="{{ $me->code }}" class="form-control" readonly>
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Email</label>
                                                    <input type="text" value="{{ $me->email }}" class="form-control" readonly>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Faculte </label>
                                                    <input type="text" value="{{ $me->titre_faculte }}" class="form-control" readonly>
                                                </div>
                                            </div>



                                            <div class="col-md-6 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Annee Scolaire</label>
                                                    <input type="text" value="{{ $me->libelleannee }}" class="form-control" readonly>
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Classe</label>
                                                    <input type="text" value="{{ $me->libelle_classe }}" class="form-control" readonly>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="accordion_2">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#accordion2" aria-expanded="false" aria-controls="accordion2"> Informations de l'etudiant</a>
                                    </h4>
                                </div>
                                <div id="accordion2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="accordion_2">
                                    <div class="panel-body">
                                        <form action="{{ route('update.etudiant.public',$me->ide )}}" method="POST">
                                            @csrf
                                            @method('PUT')



                                            <div class="col-md-6 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Nom</label>
                                                    <input type="text" value="{{ $me->nom }}" class="form-control" name="nom">
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Prenom</label>
                                                    <input type="text" value="{{ $me->prenom }}" class="form-control" name="prenom">
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Sexe</label>

                                                    <select type="text" name="genre" class="form-control" id="validationTooltip02" placeholder="Prenom" required>
                                                        <option value="{{ $me->sexe }}">{{ $me->sexe }}</option>
                                                        <option value="Homme"> Homme </option>
                                                        <option value="Femme"> Femme </option>
                                                    </select>


                                                </div>
                                            </div>

                                            <div class="col-md-6 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> date naissance</label>
                                                    <input type="date" value="{{ $me->dateNais }}" class="form-control" name="datenaissance">
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Adresse</label>
                                                    <input type="text" value="{{ $me->adresse }}" class="form-control" name="adresse">
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Nationaliote</label>
                                                    <input type="text" value="{{ $me->nationalite }}" class="form-control" name="nationalite">
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Telephone</label>
                                                    <input type="number" value="{{ $me->tel }}" class="form-control" name="tel">
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <button class="btn btn-primary" name="saveData" type="submit">Enregistrer</button>
                                                </div>
                                            </div>

                                        </form>


                                    </div>
                                </div>
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="accordion_3">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#accordion3" aria-expanded="false" aria-controls="accordion3">Document</a>
                                    </h4>
                                </div>
                                <div id="accordion3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="accordion_3">
                                    <div class="panel-body">

                                        <form class="needs-validation" novalidate action="{{ route('save.document.etudiant', $me->ide )}}" method="POST" enctype="multipart/form-data">
                                            @csrf

                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Carte Identite <small> (Format accepter PDF)</small>
                                                        @if ($me->piece)
                                                        <a href="{{ $me->piece }}" target="_blank"> Voir le document</a>
                                                        <br>
                                                        <small>Vous pouvez télécharger un nouveau fichier si nécessaire.</small>
                                                        @else
                                                        <span style="color: red;">Document non fourni</span>
                                                        @endif
                                                    </label>
                                                    <input type="file" name="carteIdentite" accept=".pdf" class="form-control" @if (!$me->piece) required @endif>
                                                    <div class="invalid-feedback" id="carteIdentiteFeedback" style="color: red;"></div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Diplome d'etat <small> (Format accepter PDF)</small>
                                                        @if ($me->diplomeDetat)
                                                        <a href="{{ $me->diplomeDetat }}" target="_blank"> Voir le document</a>
                                                        <br>
                                                        <small>Vous pouvez télécharger un nouveau fichier si nécessaire.</small>
                                                        @else
                                                        <span style="color: red;">Document non fourni</span>
                                                        @endif
                                                    </label>
                                                    <input type="file" name="diplomeetat" accept=".pdf" class="form-control" @if (!$me->diplomeDetat) required @endif>
                                                    <div class="invalid-feedback" id="diplomeetatFeedback" style="color: red;"></div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> CV <small> (Format accepter PDF)</small>
                                                        @if ($me->cv)
                                                        <a href="{{ $me->cv }}" target="_blank"> Voir le document</a>
                                                        <br>
                                                        <small>Vous pouvez télécharger un nouveau fichier si nécessaire.</small>
                                                        @else
                                                        <span style="color: red;">Document non fourni</span>
                                                        @endif
                                                    </label>
                                                    <input type="file" name="cv" accept=".pdf" class="form-control" @if (!$me->cv) required @endif>
                                                    <div class="invalid-feedback" id="cvFeedback" style="color: red;"></div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Lettre de motivation <small> (Format accepter PDF)</small>
                                                        @if ($me->lettre)
                                                        <a href="{{ $me->lettre }}" target="_blank"> Voir le document</a>
                                                        <br>
                                                        <small>Vous pouvez télécharger un nouveau fichier si nécessaire.</small>
                                                        @else
                                                        <span style="color: red;">Document non fourni</span>
                                                        @endif
                                                    </label>
                                                    <input type="file" name="lettremotivation" accept=".pdf" class="form-control" @if (!$me->lettre) required @endif>
                                                    <div class="invalid-feedback" id="lettremotivationFeedback" style="color: red;"></div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <button id="submitButton" class="btn btn-primary" name="saveData" type="submit">Enregistrer</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="accordion_1">
                                    <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#accordion4" aria-expanded="true" aria-controls="accordion4">Mot de passe</a>
                                    </h4>
                                </div>
                                <div id="accordion4" class="panel-collapse collapse" role="tabpane4" aria-labelledby="accordion_4">
                                    <div class="panel-body">

                                        <form class="needs-validation" novalidate action="{{ route('save.password', $me->idu) }}" method="POST" id="passwordForm">
                                            @csrf
                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Ancien mot de passe</label>
                                                    <input type="password" id="oldPassword" class="form-control" name="old_password" required autofocus>
                                                    <div class="invalid-feedback" id="oldPasswordFeedback" style="color: red;"></div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Nouveau mot de passe</label>
                                                    <input type="password" id="newPassword" class="form-control" name="new_password" required>
                                                    <div class="invalid-feedback" id="newPasswordFeedback" style="color: red;"></div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <label> Confirmer le mot de passe</label>
                                                    <input type="password" id="confirmPassword" class="form-control" name="new_password_confirmation" required>
                                                    <div class="invalid-feedback" id="confirmPasswordFeedback" style="color: red;"></div>
                                                </div>
                                            </div>

                                            <div class="col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-group">
                                                    <button id="submitpassword" class="btn btn-primary" name="saveData" type="submit" disabled>Enregistrer</button>
                                                </div>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>

                            <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="accordion_5">
        <h4 class="panel-title">
            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#accordion5" aria-expanded="true" aria-controls="accordion5">Suppression</a>
        </h4>
    </div>
    <div id="accordion5" class="panel-collapse collapse" role="tabpane5" aria-labelledby="accordion_5">
        <div class="panel-body">

            <form class="needs-validation" novalidate id="deleteAccountForm">
                @csrf
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <label for="password">Entrez votre mot de passe pour confirmer la suppression :</label>
                        <input type="password" id="password" class="form-control" name="password" required>
                        <div class="invalid-feedback" id="passwordFeedback" style="color: red;"></div>
                    </div>
                </div>

                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <center>
                            <button id="submitdeletecompte" class="btn btn-danger" type="button">Supprimer mon compte</button>
                        </center>
                    </div>
                </div>
            </form>

            <div id="confirmationMessage" class="alert alert-warning" style="display: none;">
                <strong>Attention !</strong> Voulez-vous vraiment supprimer votre compte ?
                <button id="confirmDelete" class="btn btn-danger">Oui, supprimer</button>
                <button id="cancelDelete" class="btn btn-secondary">Annuler</button>
            </div>

        </div>
    </div>
</div>




                        </div>
                    </div>





                </div>

                <div class="col-md-2">
                    <div class="getintouch">
                        <div class="col-md-2">
                            <div class="getintouch">
                                <form class="contactus-form" novalidate action="{{ route('save.image.etudiant', $me->idu )}}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <div class="row">

                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <img src="{{ asset(Auth::user()->photo) }}" alt="staff" width="275" height="288" />
                                                <input type="file" name="photopassport" required accept=".png, .jpg, .jpeg" class="form-control" id="photopassport">
                                                <div class="invalid-feedback" id="photoFeedback" style="color: red;"></div>
                                            </div>
                                        </div>

                                        <div class="col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-group">
                                                <input type="submit" name="post" title="Send" value="Envoyer" id="submitButton" >
                                            </div>
                                        </div>
                                        <div class="alert-msg" id="alert-msg"></div>
                                    </div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>

            </div>

        </div>

    </div>
    <div class="section-padding"></div>
</div>


<script>
    document.getElementById('submitdeletecompte').addEventListener('click', function() {
        const passwordInput = document.getElementById('password');
        const passwordFeedback = document.getElementById('passwordFeedback');

        // Vérification du mot de passe via AJAX
        fetch('/verify-password/{{ $me->idu }}', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ old_password: passwordInput.value })
        })
        .then(response => {
            if (response.ok) {
                // Mot de passe valide, demander confirmation
                document.getElementById('confirmationMessage').style.display = 'block';
                passwordFeedback.textContent = '';
            } else {
                // Mot de passe invalide
                passwordFeedback.textContent = 'Mot de passe incorrect.';
                document.getElementById('confirmationMessage').style.display = 'none';
            }
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    document.getElementById('confirmDelete').addEventListener('click', function() {
        // Soumettre le formulaire de suppression
        const form = document.getElementById('deleteAccountForm');
        form.action = '/delete-account/{{ $me->idu }}'; // Route pour supprimer le compte
        form.method = 'POST';
        form.submit(); // Soumet le formulaire
    });

    document.getElementById('cancelDelete').addEventListener('click', function() {
        // Fermer le message de confirmation
        document.getElementById('confirmationMessage').style.display = 'none';
    });
</script>

<script>
    const oldPasswordInput = document.getElementById('oldPassword');
    const newPasswordInput = document.getElementById('newPassword');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const submitButtons = document.getElementById('submitpassword');
    const userId = '{{ $me->idu }}'; // ID de l'utilisateur

    oldPasswordInput.addEventListener('input', function() {
        // Vérification de l'ancien mot de passe via AJAX
        fetch(`/verify-password/${userId}`, {
            method: 'POST', // Assurez-vous que c'est bien POST
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ old_password: oldPasswordInput.value })
        })
        .then(response => {
            if (response.ok) {
                // Ancien mot de passe valide
                document.getElementById('oldPasswordFeedback').textContent = '';
                validatePasswords();
            } else {
                // Ancien mot de passe invalide
                document.getElementById('oldPasswordFeedback').textContent = 'L\'ancien mot de passe est incorrect.';
                submitButtons.disabled = true;
            }
        })
        .catch(error => {
            console.error('Erreur:', error);
        });
    });

    function validatePasswords() {
        const newPasswordFeedback = document.getElementById('newPasswordFeedback');
        const confirmPasswordFeedback = document.getElementById('confirmPasswordFeedback');

        newPasswordFeedback.textContent = '';
        confirmPasswordFeedback.textContent = '';
        let valid = true;

        // Vérification que le nouveau mot de passe a au moins 8 caractères
        if (newPasswordInput.value.length < 8) {
            newPasswordFeedback.textContent = 'Attention : Le mot de passe doit contenir au moins 8 caractères.';
            valid = false;
        }

        // Vérification que le nouveau mot de passe et la confirmation correspondent
        if (newPasswordInput.value !== confirmPasswordInput.value) {
            confirmPasswordFeedback.textContent = 'Les mots de passe ne correspondent pas.';
            valid = false;
        }

        // Activation ou désactivation du bouton de soumission
        submitButtons.disabled = !valid;
    }

    // Écouteurs d'événements pour les nouveaux mots de passe
    newPasswordInput.addEventListener('input', validatePasswords);
    confirmPasswordInput.addEventListener('input', validatePasswords);
</script>



<script>
    const fileInputs = document.querySelectorAll('input[type="file"]');
    const maxSize = 2 * 1024 * 1024; // 2 Mo en octets

    fileInputs.forEach(input => {
        input.addEventListener('change', function() {
            const feedback = document.getElementById(input.name + 'Feedback');
            feedback.textContent = ''; // Réinitialise le message d'erreur
            if (input.files.length > 0) {
                const file = input.files[0];
                if (file.size > maxSize) {
                    feedback.textContent = 'Le fichier ne doit pas dépasser 2 Mo.';
                    input.value = ''; // Réinitialise le champ de fichier
                }
            }
        });
    });
</script>

<script>
    const fileInput = document.getElementById('photopassport');
    const submitButton = document.getElementById('submitButton');
    const feedback = document.getElementById('photoFeedback');
    const maxSizes = 2 * 1024 * 1024; // 2 Mo en octets

    fileInput.addEventListener('change', function() {
        feedback.textContent = ''; // Réinitialiser le message d'erreur
        submitButton.disabled = true; // Désactiver le bouton par défaut

        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            if (file.size > maxSizes) {
                feedback.textContent = 'La photo ne doit pas dépasser 2 Mo.';
                fileInput.value = ''; // Réinitialiser le champ de fichier
            } else {
                submitButton.disabled = false; // Activer le bouton si le fichier est valide
            }
        }
    });
</script>

@include('Frontend.components.footer')