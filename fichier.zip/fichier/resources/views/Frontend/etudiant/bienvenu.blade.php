@include('Frontend.components.header')
@include('Frontend.components.menu')
<!-- PageBanner -->
<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content">
            <h3> {{ $me->nom }} {{ $me->prenom }}</h3>
            <ol class="breadcrumb">
                <li><a href="index.html">Code matricule</a></li>
                <li>{{ $me->code }}</li>
                <li>Bienvenu</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->

<div class="container coursesdetail-section">
    <div class="section-padding"></div>
    <div class="row">
        @include('Frontend.components.menuetudiant')

        <div class="col-md-9 col-sm-8 event-contentarea">
            <div class="coursesdetail-block">
                @if ($completionPercentage < 98)
                    <div class="row">

                        <div class="col-lg-12">
                            <div class="detail-review" style="width:100%; padding:20px">
                                <div class="card card-body">
                                    <h4 class="card-title">Complétez votre compte</h4>

                                    <div class="container">
                                        <h3><i class="fa fa-user"></i> {{ $user->code }} : {{ $user->prenom }} </h3>

                                        <!-- Affichage de la barre de progression -->
                                        <div class="progress" style="width: 70%;">
                                            <div class="progress-bar" role="progressbar"
                                                style="width: {{ round($completionPercentage) }}%;"
                                                aria-valuenow="{{ round($completionPercentage) }}" aria-valuemin="0"
                                                aria-valuemax="100">
                                                {{ round($completionPercentage) }}% Complété
                                            </div>
                                        </div>

                                        <p class="card-text">Pour un profil complet, vous devez remplir toutes les
                                            informations de votre profil.</p>
                                        <a href="{{ route('profile') }}" class="btn btn-primary">Allez-y</a>

                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>
                    <br><br>
                @endif





                <div class="courses-review">

                    <div class="reviewbox">

                        <div class="average-review">
                            <h2> {{ $cours->count() }}</h2>
                            <ul>
                                <li><a href="#" title="1 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="2 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="3 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="4 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="5 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                            </ul>
                            <span>Cours</span>
                        </div>
                    </div>

                </div>


                <div class="courses-review">

                    <div class="reviewbox">

                        <div class="average-review">
                            <h2> {{ $examens->count() }}</h2>
                            <ul>
                                <li><a href="#" title="1 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="2 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="3 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="4 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="5 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                            </ul>
                            <span>Examens</span>
                        </div>
                    </div>

                </div>


                <div class="courses-review">

                    <div class="reviewbox">

                        <div class="average-review">
                            <h2> {{ $bibliotheque->count() }}</h2>
                            <ul>
                                <li><a href="#" title="1 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="2 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="3 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="4 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="#" title="5 Star"><i class="fa fa-star-o" aria-hidden="true"></i></a>
                                </li>
                            </ul>
                            <span>Bibliotheques</span>
                        </div>
                    </div>

                </div>
            </div>




            <div class="courses-curriculum"> <br>
                <h3 class="course-title">Les cours disponible </h3>
                @foreach ($cours as $cour)
                    <div class="courses-sections-block">
                        <h3>Titre du cours : <span> {{ $cour->titre_cours }}</span></h3>
                        <div class="courses-lecture-box">
                            <i class="fa fa-file-o" aria-hidden="true"></i>
                            <span class="lecture-title">{{ $cour->description_cours }}</span>
                            <span class="lecture-time">Vol:{{ $cour->volume_cours }} </span>
                        </div>
                        <!--<div class="courses-lecture-box">
          <i class="fa fa-file-o" aria-hidden="true"></i>
          <span class="lecture-no">Lecture 1.2</span>
          <span class="lecture-title">Software Training</span>
          <span class="lecture-tag"><a href="#">Free</a></span>
          <span class="lecture-time">00:50:00</span>
         </div>  -->
                    </div>
                @endforeach

                <a href="{{ route('mescours') }}" class="btn btn-warrning"> Voir tout les cours</a>

            </div>

        </div>

    </div>

</div>
<div class="section-padding"></div>
</div>

@include('Frontend.components.footer')
