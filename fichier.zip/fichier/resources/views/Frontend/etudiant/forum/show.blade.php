@include('Frontend.components.header')
@include('Frontend.components.menu')
<!-- PageBanner -->
<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content" style="height:10px">
            <h3>
                @if (Auth::user()->idfonction == 7)
                    {{ $forum->titre_forum }}
                @else
                    Forum
                @endif

            </h3>
            <ol class="breadcrumb">
                @if (Auth::user()->idfonction == 7)
                    <li><a href="/">Code matricule</a></li>
                    <li>{{ $me->code }}</li>
                @else
                    <li><a href="/">Accueil</a></li>
                @endif

                <li>Bienvenu</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->
<div class="container coursesdetail-section">
    <div class="section-padding"></div>
    <div class="row">

        @if (Auth::user()->idfonction == 7)
            @include('Frontend.components.menuetudiant')
        @endif

        <div class="col-md-9 col-sm-8 event-contentarea">

            @include('Backend.components.messagre')

            <div class="post-comments">

                <div class="col-md-9">
                    <h3 class="course-title">Réponse ({{ $reponses->count() }}) </h3>
                </div>




                <div class="col-md-3">
                    @if (Auth::user()->idfonction == 7)
                        <a href="{{ route('forum.nouveau') }}" class="btn btn-primary" style="width:100%">Nouveau
                            sujet <i class="fa fa-plus-circle"> </i>
                        </a>
                    @endif
                </div>

                <div class="media">
                    <div class="media-left">
                        <a title=" {{ $forum->nom }} {{ $forum->prenom }}" href="#">
                            <img width="112" height="112" class="media-object" src="{{ asset($forum->photo) }}"
                                alt=" {{ $forum->nom }} {{ $forum->prenom }}">
                        </a>
                    </div>
                    <div class="media-body">
                        <div class="media-content">
                            <h4 class="media-heading">
                                {{ $forum->nom }} {{ $forum->prenom }}<span>
                                    {{ $forum->created_at->diffForHumans() }}</span>
                            </h4>
                            <p>{{ $forum->titre_forum }}</p>
                            <p> {{ $forum->cours_title }} </p>


                        </div>
                        @if ($reponses->isEmpty())
                            <p>Aucune réponse pour le moment.</p>
                        @else
                            @foreach ($reponses as $reponse)
                                <div class="media">
                                    <div class="media-left">
                                        <a title=" {{ $reponse->user_prenom }})" href="#">
                                            <img width="112" height="112" class="media-object"
                                                src="{{ asset($reponse->photos) }}"
                                                alt=" {{ $reponse->user_prenom }}">
                                        </a>
                                    </div>
                                    <div class="media-body">
                                        <div class="media-content">
                                            <h4 class="media-heading">
                                                {{ $reponse->user_prenom }} ({{ $reponse->niveau }} )
                                                <span>{{ \Carbon\Carbon::parse($reponse->created_at)->diffForHumans() }}</span>
                                            </h4>
                                            <p>{{ $reponse->reponse_content }}</p>

                                        </div>
                                    </div>
                                </div>
                            @endforeach

                        @endif
                    </div>
                </div>

            </div>

            <div class="courses-curriculum">
                <div class="courses-sections-block">
                    <form class="needs-validation" novalidate action="{{ route('save.reponse') }}" method="POST">
                        @csrf
                        <h3 class="block-title">Votre message</h3>
                        <div class="form-row">
                            <div class="col-md-12 mb-12">
                                <input type="hidden" name="forum_id" value="{{ $forum->idfr }}" class="form-control">
                                <textarea type="text" name="content" class="form-control" id="validationTooltip01" placeholder="description" required
                                    style="height:250px"> </textarea>
                            </div>
                            <div class="col-md-12 mb-12">
                                <br><br>
                                <button class="btn btn-primary" name="saveData" type="submit">Repondre </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@include('Frontend.components.footer')
