@include('Frontend.components.header')
@include('Frontend.components.menu')
<!-- PageBanner -->
<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content" style="height:10px">
            <h3> {{ $me->nom }} {{ $me->prenom }}</h3>
            <ol class="breadcrumb">
                <li><a href="index.html">Code matricule</a></li>
                <li>{{ $me->code  }}</li>
                <li>Bienvenu</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->
<div class="container coursesdetail-section">
    <div class="section-padding"></div>
    <div class="row">

        @include('Frontend.components.menuetudiant')



        <div class="col-md-9 col-sm-8 event-contentarea">
            <div class="coursesdetail-block">
            @if (session()->has('success'))
            <div class="col-lg-12">
                <div class="alert alert-success"> <i class="fa fa-check-circle"></i> {{ session()->get('success') }} </div>
            </div>
            @endif


                <div class="courses-curriculum">


                    <h3 class="course-title">Créer un   sujet</h3>
                    <div class="courses-sections-block">

                        <div class="col-12" style="margin:auto">
                            <div class="card">
                                <div class="card-body">
                                  

                                    <form class="needs-validation" novalidate action="{{ route('save.forum')}}" method="POST" >
                                        @csrf

                                        <div class="form-row">

                                           
                                            <div class="col-md-6 mb-12">
                                                <label for="validationTooltip01">Titre </label>
                                               
                                                <input type="text" name="titre" class="form-control" id="validationTooltip01" placeholder="Titre" required>
                                             

                                            </div>

                                            <div class="col-md-6 mb-12">
                                                <label for="validationTooltip01">Tags le cours </label>
                                                <select class="form-control select" id="cours_is" name="cours_id">
                                                    <option value="">Sélectionner</option>
                                                    @forelse ($coursetuadiant as $coursetuadiants)
                                                        <option value="{{ $coursetuadiants->idcour }}">
                                                            {{ $coursetuadiants->titre }}
                                                        </option>
                                                    @empty
                                                    
                                                        <option value="">Aucun cours disponible</option>
                                                    @endforelse
                                                </select>
                                              
                                            </div>

                                            <div class="col-md-12 mb-12">
                                                <br>
                                                <label for="validationTooltip01">Description </label>
                                                <textarea type="text" name="description" class="form-control" id="validationTooltip01" placeholder="description" required style="height:250px"> </textarea>
                                              
                                            </div>

                                            <div class="col-md-12 mb-12">
                                            <br><br>
                                            <button class="btn btn-primary" name="saveData" type="submit">Créer le sujet </button>
                                            </div>






                                        </div>

                                       
                                        
                                    </form>

                                </div> <!-- end card-body-->
                            </div> <!-- end card -->
                        </div>



                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

@include('Frontend.components.footer')