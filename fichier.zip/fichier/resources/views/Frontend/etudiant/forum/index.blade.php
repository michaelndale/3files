@include('Frontend.components.header')
@include('Frontend.components.menu')
<!-- PageBanner -->
<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content" style="height:10px">
            <h3>
		
              
                    Forum
              

            </h3>
            <ol class="breadcrumb">
                @if (Auth::user()->idfonction==7)
                    <li><a href="/">Code matricule</a></li>
                    <li>{{ $me->code }}</li>
                @else
                    <li><a href="/">Accueil</a></li>
                @endif

                <li>Bienvenu</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->
<div class="container coursesdetail-section">
    <div class="section-padding"></div>
    <div class="row">

		@if (Auth::user()->idfonction==7)
            @include('Frontend.components.menuetudiant')
        @endif

        <div class="col-md-9 col-sm-8 event-contentarea">
            <div class="coursesdetail-block">

                <div class="post-comments">
                    <div class="row">

						@include('Backend.components.messagre')


                        <div class="col-md-9">
                            <h3 class="course-title">Forum ({{ $forum->count() }}) </h3>
                        </div>

                        


                        <div class="col-md-3">
							@if (Auth::user()->idfonction==7)  
								<a href="{{ route('forum.nouveau') }}" class="btn btn-primary" style="width:100%">Nouveau
									sujet <i class="fa fa-plus-circle"> </i>
								</a>
							@endif
                        </div>
						
                    </div>

                    @forelse ($forum as $forums)
					<div class="media">
						<div class="media-left">
							<a title=" {{ $forums->nom ?? 'Inconnu' }} {{ $forums->prenom ?? 'Inconnu' }}" href="#">
								<img width="112" height="112" class="media-object" src="{{ asset($forums->photo) }}" alt=" {{ $forums->nom ?? 'Inconnu' }} {{ $forums->prenom ?? 'Inconnu' }}">
							</a>
						</div>
						<div class="media-body">
							<div class="media-content">
								<h4 class="media-heading">
                                    {{ $forums->nom ?? 'Inconnu' }} {{ $forums->prenom ?? 'Inconnu' }}<span>{{ $forums->created_at ? $forums->created_at->diffForHumans() : 'Date inconnue' }}</span>
								</h4>
								<p>  {{ ucfirst($forums->titre_forum) }} </p> {{ $forums->course_title ?? 'Cours inconnu' }}<p></p>
								<a href="{{ route('forum.show', $forums->idfr) }}" title="Reply">Réponse</a>
							</div>
							
						</div>
					</div>
                    @empty
                    <div class="col-lg-12">
                        <div class="alert alert-danger">
                            <i class="fa fa-times-circle"></i>
                            Pas de Forums, revenez plus tard
                        </div>
                    </div>
                @endforelse
					
				</div>		




            </div>

        </div>

    </div>

</div>



@include('Frontend.components.footer')
