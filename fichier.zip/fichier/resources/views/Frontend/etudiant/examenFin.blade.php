@include('Backend.components.header')

<div id="layout-wrapper">
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-8" style="margin:auto">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-xl-8" style="margin:auto">
                                    <div class="card">
                                        <div class="card-body text-center">
                                            <h4>Bravo, vous avez terminé l'examen !</h4>
                                            <p>Score : {{ $resultat->score }}/{{ $resultat->total_questions }}</p>
                                            <p>Réponses correctes : {{ $resultat->correct_answers }}</p>
                                            <p>Réponses incorrectes : {{ $resultat->wrong_answers }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@include('Backend.components.footer')
