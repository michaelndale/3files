@include('Frontend.components.header')
@include('Frontend.components.menu')

<div class="container-fluid no-padding pagebanner">
    <div class="container">
        <div class="pagebanner-content">
            <h3>Blog</h3>
            <ol class="breadcrumb">
                <li><a href="/">Accueil</a></li>
                <li>Blog</li>
            </ol>
        </div>
    </div>
</div><!-- PageBanner /- -->

<div class="container-fulid no-padding latestblog-section">
    <div class="section-padding"></div>
    <div class="container">
        
        <div class="row">
            @forelse ($blog as $blogs)
            <div class="col-md-4 col-sm-6 col-xs-6">

                <article class="type-post">
                    <div class="entry-cover">
                        <a title="Cover" href="{{ route('voir.blog.public', $blogs->id )}}">
                            <img width="363" height="261" alt="latestnews" src="{{ asset('images/blogs/' . $blogs->photo) }}">
                        </a>
                        
                    </div>
                    <div class="entry-block">
                        <div class="entry-contentblock">
                            <div class="entry-meta">
                                <span class="postdate">{{ date('d-m-Y', strtotime($blogs->created_at)) }} </span>
                                <span class="postby">{{ $blogs->courte}}</span>
                            </div>
                            <div class="entry-block">
                                <div class="entry-title">
                                    <a title="{{ $blogs->titre}}" href="{{ route('voir.blog.public', $blogs->id )}}"><h3>{{ $blogs->titre}}</h3></a>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </article>
            </div>
            
            @empty
                
            @endforelse
            
            
        </div>
       
    </div>
    <div class="section-padding"></div>
</div>

	
@include('Frontend.components.footer')
