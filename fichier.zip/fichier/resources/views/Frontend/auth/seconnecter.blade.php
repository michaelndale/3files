
<!DOCTYPE html>
<html lang="en">

    
<!-- Mirrored from myrathemes.com/drezoc/vertical-dark/auth-login by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 13 Aug 2024 00:14:57 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="utf-8" />
        <title>E-Learning - Se Connecter</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="MyraStudio" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="{{ asset('backend/images/favicon.ico') }}">

        <!-- App css -->
        <link href="{{ asset('backend/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('backend/css/icons.min.css') }}" rel="stylesheet" type="text/css" />
        <link href="{{ asset('backend/css/theme.min.css') }}" rel="stylesheet" type="text/css" />

    </head>

    <body>

        <div class="bg-primary">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="d-flex align-items-center min-vh-100">
                            <div class="w-100 d-block bg-white shadow-lg rounded my-5">
                                <div class="row">
                                    <div class="col-lg-5 d-none d-lg-block bg-login rounded-left"></div>
                                    <div class="col-lg-7">
                                        <div class="p-5">
                                            <div class="text-center">
                                                <a class='d-block mb-5' href='/'>
                                                    <img src="{{ asset('backend/images/logo-dark.png')}}" alt="app-logo" height="" />
                                                </a>
                                            </div>

                                            @if ($errors->any())
                                                <div class="alert alert-danger">
                                                    <ul>
                                                        @foreach ($errors->all() as $error)
                                                            <li>{{ $error }}</li>
                                                        @endforeach
                                                    </ul>
                                                </div>
                                            @endif

                                            <!-- Display Exception Errors -->
                                            @if ($errors->has('exception'))
                                                <div class="alert alert-danger">
                                                    <strong>{{ $errors->first('exception') }}</strong>
                                                </div>
                                            @endif

                                            @if ($errors->has('login'))
                                                <div class="alert alert-danger">
                                                    {{ $errors->first('login') }}
                                                </div>
                                            @endif
                                           

                                            <h1 class="h5 mb-1">Portaille Administration</h1>
                                            <p class="text-muted mb-4">Entrer votre adresse email et mot de passe pour avoir  acces sur la page d'adminstration.</p>
                                            <form class="user" action="{{ route('adminconnexion') }}">
                                                <div class="form-group">
                                                    <input 
                                                        type="email" 
                                                        class="form-control form-control-user" 
                                                        name="email" 
                                                        value="{{ old('email') }}"  
                                                        placeholder="Adresse Email" 
                                                        required 
                                                        autocomplete="off">

                                                </div>
                                                <div class="form-group">
                                                    <input type="password" class="form-control form-control-user" name="password"  placeholder="Mot de passe" required autocomplete="new-password">
                                                </div>
                                                <button name="Secconnecter" class="btn btn-success btn-block"> Se Connecter </button>
                                            </form>

                                            <div class="row mt-4">
                                                <div class="col-12 text-center">
                                                    <p class="text-muted mb-2"><a class='text-muted font-weight-medium ml-1' href="{{ route('auth-recoverpw')}}">Mot de pass oublier ?</a></p>
                                                    <!--<p class="text-muted mb-0">J'ai ne pas un compte ? <a class='text-muted font-weight-medium ml-1' href='auth-register.html'><b>Creer </b></a></p> -->
                                                </div> 
                                            </div>
                                            <!-- end row -->
                                        </div> <!-- end .padding-5 -->
                                    </div> <!-- end col -->
                                </div> <!-- end row -->
                            </div> <!-- end .w-100 -->
                        </div> <!-- end .d-flex -->
                    </div> <!-- end col-->
                </div> <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end page -->

        <!-- jQuery  -->
        <script src="{{ asset('backend/js/jquery.min.js') }}"></script>
        <script src="{{ asset('backend/js/bootstrap.bundle.min.js') }}"></script>
        <script src="{{ asset('backend/js/metismenu.min.js') }}"></script>
        <script src="{{ asset('backend/js/waves.js') }}"></script>
        <script src="{{ asset('backend/js/simplebar.min.js') }}"></script>

        <!-- App js -->
        <script src="{{ asset('backend/js/theme.js') }}"></script>

    </body>


<!-- Mirrored from myrathemes.com/drezoc/vertical-dark/auth-login by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 13 Aug 2024 00:14:57 GMT -->
</html>