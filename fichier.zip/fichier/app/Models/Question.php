<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    public function choixes()
    {
        return $this->hasMany(Choix::class); // Assurez-vous que le modèle Choix existe
    }
    

    use HasFactory;
}
