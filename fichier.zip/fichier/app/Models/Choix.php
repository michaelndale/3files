<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Choix extends Model
{
    protected $table = 'choixes'; // Indique le nom de la table

    public function question()
    {
        return $this->belongsTo(Question::class);
    }
    use HasFactory;
}
