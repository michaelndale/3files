<?php

namespace App\Http\Controllers;

use App\Models\cours;
use App\Models\Etudiants;
use App\Models\Facultecours;
use App\Models\forum;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ForumController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $me = Etudiants::join('users','etudiants.user_id','users.id')
            ->join('transite_faculte_etudiants', 'etudiants.user_id', 'transite_faculte_etudiants.users_id')
            ->join('facultes', 'transite_faculte_etudiants.faculte_id','facultes.id')
            ->join('annees', 'transite_faculte_etudiants.annescolaire_id','annees.id')
            ->join('classes','transite_faculte_etudiants.classe_id', 'classes.id')
            ->select('etudiants.*', 'etudiants.id as ide', 'users.id as idu', 'facultes.id as idfac', 'annees.id as idannee', 'classes.id as idclass')
            ->where('users.id', Auth::id())
            ->first();
    
        // Si aucun étudiant n'est trouvé, on peut continuer sans problème.
        // On peut gérer un cas particulier si nécessaire.
        
        $coursetuadiant = Facultecours::join('cours', 'cours.id', 'facultecours.cours_id')
            ->join('facultes', 'facultes.id', 'facultecours.faculte_id')
            ->join('annees', 'annees.id', 'facultecours.annescolaire_id')
            ->join('classes', 'classes.id', 'facultecours.classe_id')
            ->select('cours.*', 'cours.id as idcour')
            ->where('facultes.id', $me ? $me->idfac : null)  // Vérifiez si $me existe
            ->where('classes.id', $me ? $me->idclass : null)  // Vérifiez si $me existe
            ->where('annees.id', $me ? $me->idannee : null)   // Vérifiez si $me existe
            ->get();

        $coursproffeur = DB::table('dispenser_cours')
            ->join('cours', 'dispenser_cours.cours_id','cours.id')
            ->join('users', 'dispenser_cours.user_id', 'users.id')
            ->select('cours.*','cours.id as idcour')
            ->where('dispenser_cours.user_id','=', Auth::id())
            ->get();
       
        
        $coursIdsProf = $coursproffeur->pluck('idcour')->toArray();
    
        // Extraire tous les ID des cours
        $coursIds = $coursetuadiant->pluck('idcour')->toArray();
    
        // Utilisez une jointure externe (LEFT JOIN) pour afficher les forums même si certaines jointures échouent
        $forum = Forum::leftJoin('etudiants', 'forums.users_id', '=', 'etudiants.user_id')  // Jointure externe avec etudiants
            ->leftJoin('cours', 'forums.cours_id', '=', 'cours.id')  // Jointure externe avec cours
            ->leftJoin('users', 'forums.users_id', '=', 'users.id')  // Jointure externe avec users
            ->select(
                'forums.titre as titre_forum',    // Texte de la question
                'etudiants.nom',         // Prénom de l'étudiant
                'etudiants.prenom',      // Nom de l'étudiant
                'users.photo',
                'cours.titre as course_title', // Titre du cours
                'forums.created_at',         // Date de création du forum
                'forums.status',
                'forums.id as idfr'
            )
            ->whereIn('forums.cours_id', $coursIds)  // Filtrer par ID de cours
            ->orWhereIn('forums.cours_id', $coursIdsProf)
            ->orderby('forums.id', 'desc')
            ->get();

           $title_= $active= 'Forum';
    
        return view('Frontend.etudiant.forum.index', compact('me', 'coursetuadiant', 'forum','active','title_'));
    }
    
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $me = Etudiants::join('users','etudiants.user_id','users.id')
        ->join('transite_faculte_etudiants', 'etudiants.user_id', 'transite_faculte_etudiants.users_id')
        ->join('facultes', 'transite_faculte_etudiants.faculte_id','facultes.id')
        ->join('annees', 'transite_faculte_etudiants.annescolaire_id','annees.id')
        ->join('classes','transite_faculte_etudiants.classe_id', 'classes.id')
        ->select('etudiants.*', 'etudiants.id as ide', 'users.id as idu', 'facultes.id as idfac', 'annees.id as idannee', 'classes.id as idclass')
        ->where('users.id', Auth::id())
        ->first();
        $active = "Forum";

    $coursetuadiant = Facultecours::join('cours', 'cours.id', 'facultecours.cours_id')
        ->join('facultes', 'facultes.id', 'facultecours.faculte_id')
        ->join('annees', 'annees.id', 'facultecours.annescolaire_id')
        ->join('classes', 'classes.id', 'facultecours.classe_id')
        ->select('cours.*', 'cours.id as idcour')
        ->where('facultes.id', $me->idfac)
        ->where('classes.id', $me->idclass)
        ->where('annees.id', $me->idannee)
        ->get();


    return view('Frontend.etudiant.forum.new', compact('me', 'coursetuadiant','active'));
        //
    }

    /**
     * Store a newly created resource in storage.
     */

    public function store(Request $request)
    {
        // Validation des données
        $validated = $request->validate([
            'titre' => 'required|string|max:255',
            'cours_id' => 'required|exists:cours,id', // Assurez-vous que l'id du cours est valide
            'description' => 'required|string', // Utilisation de 'description' comme question_text
        ]);

        // Créer une nouvelle entrée dans la table "forums" avec le statut "pending"

        $forum = new forum();


     
        $forum->titre = $request->titre; 
        $forum->users_id = Auth::id();
        $forum->cours_id = $request->cours_id;
        $forum->question_text = $request->description;  
        $forum->status = 'pending';
        $forum->save();
  

        // Redirection vers la page de la question nouvellement créée
        return redirect()->route('forum.show', ['forum' => $forum->id])
                        ->with('success', 'Le sujet a été créé avec succès.');
    }


    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        // Récupérer le forum (question) en fonction de l'ID
        $forum =
                Forum::leftJoin('etudiants', 'forums.users_id', '=', 'etudiants.user_id')  // Jointure externe avec etudiants
                    ->leftJoin('cours', 'forums.cours_id', '=', 'cours.id')  // Jointure externe avec cours
                    ->leftJoin('users', 'forums.users_id', '=', 'users.id')  // Jointure externe avec users
                    ->select(
                        'forums.titre  as titre_forum',    // Texte de la question
                        'etudiants.nom',         // Prénom de l'étudiant
                        'etudiants.prenom',      // Nom de l'étudiant
                        'users.photo',
                        'cours.titre as cours_title', // Titre du cours
                        'forums.created_at',         // Date de création du forum
                        'forums.status',
                        'forums.id as idfr'
                    )
                    ->where('forums.id', $id)  // Filtrer par ID de cours
                    ->first();

                    $title_ =  $forum->titre_forum;


        $me = Etudiants::join('users','etudiants.user_id','users.id')
        ->join('transite_faculte_etudiants', 'etudiants.user_id', 'transite_faculte_etudiants.users_id')
        ->join('facultes', 'transite_faculte_etudiants.faculte_id','facultes.id')
        ->join('annees', 'transite_faculte_etudiants.annescolaire_id','annees.id')
        ->join('classes','transite_faculte_etudiants.classe_id', 'classes.id')
        ->select('etudiants.*', 'etudiants.id as ide', 'users.id as idu', 'facultes.id as idfac', 'annees.id as idannee', 'classes.id as idclass')
        ->first();
        
        $cours = cours::find($forum->cours_id);

         // Récupérer les réponses associées au forum
            $reponses = DB::table('reponse_forums')
            ->join('users', 'reponse_forums.user_id', '=', 'users.id') // Relier les réponses aux utilisateurs
            ->join('fonctions','users.idfonction', 'fonctions.id')
            ->where('reponse_forums.forum_id', $id) // Filtrer par forum_id
            ->select(
                'reponse_forums.content as reponse_content', // Le contenu de la réponse
                'reponse_forums.created_at', // Date de la réponse
                'users.code as user_code', // Nom de l'utilisateur ayant posté la réponse
                'users.photo as photos',
                'users.prenom as user_prenom', // Email de l'utilisateur
                'fonctions.titre as niveau'
            )
            ->get();
            $active = 'Forum';

        return view('Frontend.etudiant.forum.show', compact('forum', 'me', 'cours','reponses','active','title_'));
    }


    /**
     * Show the form for editing the specified resource.
     */
    public function edit(forum $forum)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, forum $forum)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(forum $forum)
    {
        //
    }
}
