<?php

namespace App\Http\Controllers;

use App\Models\annee;
use App\Models\Facturations;
use Illuminate\Http\Request;

class FacturationController extends Controller
{
   

   /* public function index()
    {
     $Allfacturation = Facturations::all();
     $anneScolaire = annee::where('statut', '=', 'ACTIF')->first();
     return view('Backend.Facturations.index',compact('Allfacturation', 'anneScolaire'));
    } */

    public function index()
    {
        // Récupérer toutes les années scolaires actives
        $anneScolaires = Annee::all();
        $anneActif = annee::where('statut', '=', 'ACTIF')->first();
        return view('Backend.Facturations.index', compact('anneScolaires','anneActif'));
    }

    // Méthode AJAX pour récupérer les facturations pour une année spécifique
    public function FacturationsForAnnee(Request $request, $annee_id)
    {
        // Récupérer les facturations pour une année scolaire spécifique
        $facturations = Facturations::where('annee_id', $annee_id)->get();
        return response()->json($facturations);
    }

    public function deleteFacturation($facturation_id)
    {
        try {
            $facturation = Facturations::findOrFail($facturation_id);
            $facturation->delete();

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Une erreur est survenue.']);
        }
    }

    public function updateFacturation(Request $request)
{
    $facturation = Facturations::findOrFail($request->facturation_id);
    $facturation->update([
        'libelle' => $request->libelle,
        'montant' => $request->montant,
        'periode' => $request->periode,
    ]);

    return redirect()->back()->with('success', 'Facturation mise à jour avec succès.');
}



    /**
     * Show the form for creating a new resource.
     */
   
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validation des données d'entrée
        $request->validate([
            'annee_id' => 'required|exists:annees,id', // Assurez-vous que `annees` est une table valide
            'libelle' => 'required|string|max:255',
            'montant' => 'required|numeric|min:0', // Assurez-vous que le montant est un nombre positif
            'periode' => 'required|string|max:150',
        ]);

        // Création de la nouvelle facturation
        $fac = new Facturations();
        $fac->annee_id = $request->annee_id;
        $fac->libelle = $request->libelle;
        $fac->montant = $request->montant;
        $fac->periode = $request->periode;

        // Sauvegarde de la facturation dans la base de données
        $fac->save();

        // Redirection avec message de succès
        return redirect()->back()->with('success', 'Facturation créée avec succès');
    }


    

   

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $Classe =  Facturations::find($id);
        $Classe->delete();
        return redirect()->back()->with('success','Facturation suprimer avec succes'); //
    }

}
