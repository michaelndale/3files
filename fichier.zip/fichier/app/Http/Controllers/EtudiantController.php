<?php

namespace App\Http\Controllers;

use App\Models\annee;
use App\Models\Classe;
use App\Models\Etudiants;
use App\Models\Faculte;
use App\Models\TransiteFaculteEtudiant;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class EtudiantController extends Controller
{
    public function listeetudiant()
    {
        $alletudiant = Etudiants::join('users', 'etudiants.user_id', 'users.id')
            ->select('etudiants.*', 'users.id as idu', 'users.email', 'users.code', 'users.status')
            ->get();

        $faculte = Faculte::all();
        $anneScolaire = annee::where('statut', '=', 'ACTIF')->first();
        $classe = Classe::all();

        $generatepassword = Str::random(8);

        return view('Backend.Etudiants.index', compact('alletudiant', 'faculte', 'anneScolaire', 'classe', 'generatepassword'));
    }

    /**
     * Store a newly created resource in storage.
     */

    public function storePrive(Request $request)
    {
        // Validate the incoming request
        $request->validate([
            'prenom' => 'required|string|max:255',
            'nom' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'genre' => 'required|string|max:10',
            'datenaissance' => 'required|date',
            'adresse' => 'nullable|string|max:255',
            'nationalite' => 'nullable|string|max:100',
            'tel' => 'nullable|string|max:15',
            'date_enr' => 'required|date',
            'annee_id' => 'required|integer',
            'faculte_id' => 'required|integer',
            'classe_id' => 'required|integer',
        ]);

        DB::beginTransaction();

        try {
           $password= $request->password;

            // Create the user
            $user = new User();
            $user->prenom = $request->prenom;
            $user->email = $request->email;
            $user->idfonction = 7;
            $user->password =  $password;
            $user->code = $this->generateCodeMatricule();
            $user->save();

            if ($user) {

                // Create the Etudiant record
                $etudiant = new Etudiants();
                $etudiant->nom = $request->nom;
                $etudiant->prenom = $request->prenom;
                $etudiant->sexe = $request->genre;
                $etudiant->dateNais = $request->datenaissance;
                $etudiant->adresse = $request->adresse;
                $etudiant->nationalite = $request->nationalite;
                $etudiant->tel = $request->tel;
                $etudiant->dateEnregitre = $request->date_enr;
                $etudiant->user_id = $user->id;
                $etudiant->save();

                // Create the TransiteFaculteEtudiant record
                $transite = new TransiteFaculteEtudiant();
                $transite->users_id = $user->id;
                $transite->annescolaire_id = $request->annee_id;
                $transite->faculte_id = $request->faculte_id;
                $transite->classe_id = $request->classe_id;
                $transite->save();
            }



            DB::commit();

            return redirect()->back()->with('success', 'Le compte de l\'étudiant a été créé avec succès. Vous pouvez vous connecter en utilisant soit votre compte email ' . $user->email . ', soit votre code matricule ' . $user->code . '. et votre mot de  :'. $password);
        } catch (\Exception $e) {
            DB::rollBack();
            // Log the error for debugging
            Log::error('Error creating user: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Une erreur est survenue lors de la création de l\'utilisateur: ' . $e->getMessage());
        }
    }


    

    // Helper method to generate the unique matricule code
    private function generateCodeMatricule()
    {
        $count = Etudiants::count();
        return "INIT" . str_pad($count + 1, 3, "0", STR_PAD_LEFT);
    }





    public function storePublic(Request $request)
    {


        DB::beginTransaction();

        try {

            $request->validate([
                'prenom' => 'required|string|max:255',
                'nom' => 'required|string|max:255',
                'email' => 'required|email|unique:users,email',
                'annee_id' => 'required|integer',
                'faculte_id' => 'required|integer',
                'classe_id' => 'required|integer',
            ]);



            $user = new User();

            $user->prenom = $request->prenom;
            $user->email = $request->email;
            $user->idfonction = 7;
            $user->password = $request->password;
            // Génération du code matricule unique

            $user->code =  $this->generateCodeMatricule();;

            $user->save();

            if ($user) {
                $dateEn = date('Y-m-d');
                $Etudiants = new Etudiants();
                $Etudiants->nom = $request->nom;
                $Etudiants->prenom = $request->prenom;
                $Etudiants->dateEnregitre = $dateEn;
                $Etudiants->user_id = $user->id;
                $Etudiants->save();


                $transite = new TransiteFaculteEtudiant();
                $transite->users_id = $user->id;
                $transite->annescolaire_id = $request->annee_id;
                $transite->faculte_id  = $request->faculte_id;
                $transite->classe_id  = $request->classe_id;
                $transite->save();
            }

            DB::commit();

            return redirect()->back()->with('success', 'Votre compte a été créé avec succès. Vous pouvez vous connecter en utilisant soit votre compte email ' . $user->email . ', soit votre code matricule ' . $user->code . ', ');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Une erreur est survenue lors de la création de l\'utilisateur.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $Etudiants = Etudiants::join('users', 'etudiants.user_id', 'users.id')
        ->join('transite_faculte_etudiants', 'etudiants.user_id', 'users.id')
        ->join('facultes', 'transite_faculte_etudiants.faculte_id', 'facultes.id')
        ->join('annees', 'transite_faculte_etudiants.annescolaire_id', 'annees.id')
        ->select('etudiants.*', 'etudiants.id as ide', 'users.id as idu', 'users.photo as photos' ,'users.email', 'users.code', 'users.status', 'facultes.libelle as titre_faculte', 'annees.libelle as libelleannee', 'users.status')
        ->where('users.id', $id)
        ->first(); //
        return view('Backend.Etudiants.voir', compact('Etudiants'));  //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $Etudiants = Etudiants::join('users', 'etudiants.user_id', 'users.id')
            ->join('transite_faculte_etudiants', 'etudiants.user_id', 'users.id')
            ->join('facultes', 'transite_faculte_etudiants.faculte_id', 'facultes.id')
            ->join('annees', 'transite_faculte_etudiants.annescolaire_id', 'annees.id')
            ->select('etudiants.*', 'etudiants.id as ide', 'users.id as idu', 'users.photo as photos', 'users.email', 'users.code', 'users.status', 'facultes.libelle as titre_faculte', 'annees.libelle as libelleannee',)
            ->where('users.id', $id)
            ->first(); //


        return view('Backend.Etudiants.modifier', compact('Etudiants'));  //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)

    {
        // Validate the incoming request
        $request->validate([
            'prenom' => 'required|string|max:255',
            'nom' => 'required|string|max:255',
            'email' => 'required',
            'genre' => 'required|string|max:10',
            'datenaissance' => 'required|date',
            'adresse' => 'nullable|string|max:255',
            'nationalite' => 'nullable|string|max:100',
            'tel' => 'nullable|string|max:15',
            'date_enr' => 'required|date',
        ]);

        DB::beginTransaction();

        try {


            // Create the user
            $user = User::find($id);
            $user->prenom = $request->prenom;
            $user->email = $request->email;
            $user->status = $request->statut;
            $user->save();

            if ($user) {

                // Create the Etudiant record
                $etudiant = Etudiants::where('user_id', $id)->first();
                
                $etudiant->nom = $request->nom;
                $etudiant->prenom = $request->prenom;
                $etudiant->sexe = $request->genre;
                $etudiant->dateNais = $request->datenaissance;
                $etudiant->adresse = $request->adresse;
                $etudiant->nationalite = $request->nationalite;
                $etudiant->tel = $request->tel;
                $etudiant->dateEnregitre = $request->date_enr;
                $etudiant->save();
            }


            DB::commit();

            return redirect()->back()->with('success', 'Le compte de l\'étudiant a été Modifier avec succès.');
        } catch (\Exception $e) {
            DB::rollBack();
            // Log the error for debugging
            Log::error('Error creating user: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Une erreur est survenue lors de la modification de l\'etudiant: ' . $e->getMessage());
        }
    }

    public function updatePublic(Request $request, string $id)

    {
        // Validate the incoming request
        $request->validate([
            'prenom' => 'required|string|max:255',
            'nom' => 'required|string|max:255',
            'genre' => 'required|string|max:10',
            'datenaissance' => 'required|date',
            'adresse' => 'nullable|string|max:255',
            'nationalite' => 'nullable|string|max:100',
            'tel' => 'nullable|string|max:15',
        ]);

        DB::beginTransaction();

        try {
                // Create the Etudiant record
                $etudiant = Etudiants::find($id);
                
                $etudiant->nom = $request->nom;
                $etudiant->prenom = $request->prenom;
                $etudiant->sexe = $request->genre;
                $etudiant->dateNais = $request->datenaissance;
                $etudiant->adresse = $request->adresse;
                $etudiant->nationalite = $request->nationalite;
                $etudiant->tel = $request->tel;
                $etudiant->save();
          
            DB::commit();

            return redirect()->back()->with('success', 'Votre compte étudiant a été Modifier avec succès.');
        } catch (\Exception $e) {
            DB::rollBack();
            // Log the error for debugging
            Log::error('Error creating user: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Une erreur est survenue lors de la modification de l\'etudiant: ' . $e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $Etudiants = Etudiants::find($id);
        $Etudiants->delete();
        return redirect()->route('listes.etudiant')->with('success', 'compte étudiant a été supprimer avec succès.'); //
    }

    public function getClasses(Request $request)
    {
        $faculteId = $request->input('faculte_id');
        $classes = Classe::where('faculte_id', $faculteId)->get(['id', 'libelle']);
        return response()->json($classes);
    }

    public function storeDocumentEtudiant(Request $request, $id)
    {
        // Validation des fichiers, en leur permettant d'être optionnels
        $request->validate([
            'carteIdentite' => 'nullable|file|max:2048',
            'diplomeetat' => 'nullable|file|max:2048',
            'cv' => 'nullable|file|max:2048',
            'lettremotivation' => 'nullable|file|max:2048',
        ]);
    
        // Récupération de l'étudiant
        $etudiant = Etudiants::find($id);
    
        // Traitement des fichiers
        if ($request->hasFile('carteIdentite')) {
            $etudiant->piece = $this->uploadFile($request->carteIdentite, 'carteidentite');
        }
        
        if ($request->hasFile('diplomeetat')) {
            $etudiant->diplomeDetat = $this->uploadFile($request->diplomeetat, 'diplomeetat');
        }
        
        if ($request->hasFile('cv')) {
            $etudiant->cv = $this->uploadFile($request->cv, 'cv');
        }
        
        if ($request->hasFile('lettremotivation')) {
            $etudiant->lettre = $this->uploadFile($request->lettremotivation, 'lettremotivation');
        }
    
        // Sauvegarde des modifications
        $etudiant->save();
    
        return redirect()->back()->with('success', 'Documents mis à jour avec succès');
    }

    public function storeImangeEtudiant(Request $request, $id)
    {
        // Validation des fichiers, en leur permettant d'être optionnels
        $request->validate([
            'photopassport' => 'required|file|max:2048',
        ]);
    
        // Récupération de l'étudiant
        $users = User::find($id);
    
        // Traitement des fichiers photo passport
        if ($request->hasFile('photopassport')) {
            $users->photo = $this->uploadFile($request->photopassport, 'profile');
        }
        
        // Sauvegarde des modifications
        $users->save();
    
        return redirect()->back()->with('success', 'Photo mis à jour avec succès');
    }
    
    /**
     * Fonction pour gérer le téléchargement de fichiers
     */
    private function uploadFile($file, $folder)
    {
        $filename = time() . '.' . $file->extension();
        $file->move(public_path("images/{$folder}/"), $filename);
        return "images/{$folder}/{$filename}";
    }

 
}
