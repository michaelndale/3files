<?php

namespace App\Http\Controllers;

use App\Models\Choix;
use App\Models\cours;
use App\Models\Etudiants;
use App\Models\Resultats;
use App\Models\examen;
use App\Models\Question;
use App\Models\Resultat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Examencontroller extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $examens= examen::join('cours', 'examens.cours_id', 'cours.id')
                  ->select('examens.*','cours.titre as titre_cours')
                 ->get();
        $allcour= cours::all();

        return view('Backend.Examens.index', compact('examens','allcour'));
    }

    public function storeexamen(Request $request)
    {
        // Validate the incoming request data with custom messages
        $request->validate([
            'coursid' => 'required|exists:cours,id',
            'titre' => 'required|string|max:255',
            'nombrequestion' => 'required|integer|min:1',
            'point' => 'required|numeric|min:0',
            'dateexamen' => 'required|date',
            'debut' => 'required|date_format:H:i',
            'fin' => 'required|date_format:H:i|after:debut',
        ], [
            'coursid.required' => 'Le champ cours est requis.',
            'coursid.exists' => 'Le cours sélectionné n\'existe pas.',
            'titre.required' => 'Le titre est requis.',
            'titre.string' => 'Le titre doit être une chaîne de caractères.',
            'titre.max' => 'Le titre ne doit pas dépasser 255 caractères.',
            'nombrequestion.required' => 'Le nombre de questions est requis.',
            'nombrequestion.integer' => 'Le nombre de questions doit être un entier.',
            'nombrequestion.min' => 'Le nombre de questions doit être au moins 1.',
            'point.required' => 'Le point est requis.',
            'point.numeric' => 'Le point doit être un nombre.',
            'point.min' => 'Le point doit être au moins 0.',
            'dateexamen.required' => 'La date de l\'examen est requise.',
            'dateexamen.date' => 'La date fournie n\'est pas valide.',
            'debut.required' => 'L\'heure de début est requise.',
            'debut.date_format' => 'L\'heure de début doit être au format H:i.',
            'fin.required' => 'L\'heure de fin est requise.',
            'fin.date_format' => 'L\'heure de fin doit être au format H:i.',
            'fin.after' => 'L\'heure de fin doit être après l\'heure de début.',
        ]);
    
        // Create a new examen instance and assign values
        $examen = new Examen();
        $examen->cours_id = $request->coursid;
        $examen->titre = $request->titre;
        $examen->nombreQuestion = $request->nombrequestion;
        $examen->pointQuestion = $request->point;
        $examen->dateexamen = $request->dateexamen;
        $examen->heuredebut = $request->debut;
        $examen->heurefin = $request->fin;
    
        // Save the examen instance
        if ($examen->save()) {
            return redirect()->back()->with('success', 'Enregistrement réussi avec succès');
        } else {
            return redirect()->back()->with('error', 'Une erreur est survenue lors de l\'enregistrement');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function deleteexamen(string $id)
    {
        // Rechercher l'examen par ID
        $examen = Examen::find($id);
    
        // Vérifier si l'examen existe
        if (!$examen) {
            return redirect()->back()->with('error', 'Examen non trouvé');
        }
    
        // Supprimer l'examen
        $examen->delete();
    
        // Supprimer les questions associées si l'examen a été supprimé avec succès
        Question::where('examen_id', $id)->delete();
    
        return redirect()->back()->with('success', 'Examen supprimé avec succès');
    }

    public function deletequestion(string $id)
    {
        // Rechercher l'examen par ID
        $question = Question::find($id);
    
        // Vérifier si l'examen existe
        if (!$question) {
            return redirect()->back()->with('error', 'Question non trouvé');
        }
    
        // Supprimer l'examen
        $question->delete();
    
        // Supprimer les questions associées si l'examen a été supprimé avec succès
        Choix::where('question_id', $id)->delete();
    
        return redirect()->back()->with('success', 'Question supprimé avec succès');
    }

    // CONTROLLER POUR LE QUESTIONS

    public function listequestion(string $id)
    {
        $questions = Question::join('examens', 'questions.examen_id', 'examens.id')
                    ->select('questions.*', 'examens.titre as titre_examens')
                    ->get();

        $examens = examen::join('cours', 'examens.cours_id', 'cours.id')
        ->select('examens.*','cours.titre as titre_cours')
        ->first();
       
  
        return view('Backend.Examens.Questions.index', compact('questions','examens'));
    }


    public function faireExamen(string $id)
    {
        $questions = Question::join('examens', 'questions.examen_id', 'examens.id')
                    ->select('questions.*', 'examens.titre as titre_examens')
                    ->get();

        $examens = examen::join('cours', 'examens.cours_id', 'cours.id')
        ->select('examens.*','cours.titre as titre_cours')
        ->where('examens.id', $id)
        ->first();

        $me = Etudiants::join('users','etudiants.user_id','users.id')
        ->select('etudiants.*', 'users.email', 'users.code', 'users.status')
        ->where('users.id', Auth::id())
        ->first();
       
    
  
        return view('Frontend.etudiant.examenFaire', compact('questions','examens','me'));
    }

    public function commencerExamen($id, $questionIndex = 0)
    {
        $me = Etudiants::join('users', 'etudiants.user_id', 'users.id')
            ->select('etudiants.*', 'users.email', 'users.code', 'users.status')
            ->where('users.id', Auth::id())
            ->first();

        // Récupère l'examen
        $examen = Examen::join('cours', 'examens.cours_id', '=', 'cours.id')
            ->select('cours.titre as titre_cours', 'examens.*')
            ->findOrFail($id);

        if (!$examen) {
            return redirect()->back()->with('error', 'Examen introuvable');
        }

        // Récupérer les questions avec leurs choix associés
        $questions = Question::where('examen_id', $examen->id)->with('choixes')->get();

        // Vérifier que l'indice de question est valide
        if ($questionIndex >= $questions->count()) {
           // $resultat->status = 'complete';
           // $resultat->finished_at = now();
           // $resultat->save();
            return redirect()->route('examen.fin', $id)->with('message', 'Examen terminé');
        }
        

        // Obtenez la question actuelle
        $questionActuelle = $questions[$questionIndex];

        // Créer ou récupérer un enregistrement de résultat pour cet étudiant et cet examen
        $resultat = Resultat::firstOrCreate([
            'user_id' => Auth::id(),
            'examen_id' => $examen->id,
        ], [
            'score' => 0,
            'total_questions' => $questions->count(),
            'correct_answers' => 0,
            'wrong_answers' => 0,
            'status' => 'incomplete',
            'started_at' => now(),
        ]);

        // Rediriger vers la vue avec une question spécifique
        return view('Frontend.etudiant.examenFaire', compact('examen', 'questionActuelle', 'questions', 'resultat', 'me', 'questionIndex'));
    }

    public function storequestions(Request $request, $id)
    {
        $request->validate([
            'titre' => 'required|string|max:1000',
            'point' => 'required|integer|min:1',
            'temps' => 'required|integer|min:5',
            'choices' => 'required|array|min:1',
            'choices.*.text' => 'required|string|max:100',
            'choices.*.is_correct' => 'boolean',
        ]);
    
        $question = new Question();
        $question->examen_id = $id;
        $question->titre = $request->titre;
        $question->point = $request->point;
        $question->temps_limite = $request->temps;
        $question->save();
    
        foreach ($request->choices as $choice) {
            $choix = new Choix();
            $choix->question_id = $question->id;
            $choix->titre = $choice['text'];
            $choix->is_correct = isset($choice['is_correct']) ? (bool)$choice['is_correct'] : false; // S'assure que c'est un booléen
            $choix->save();
        }
    
        return redirect()->back()->with('success', 'Question ajoutée avec succès.');
    }

    public function finExamen($id)
    {
        $resultat = Resultat::where('user_id', Auth::id())
            ->where('examen_id', $id)
            ->first();

        if (!$resultat) {
            return redirect()->route('home')->with('error', 'Aucun résultat trouvé.');
        }

        return view('Frontend.etudiant.resultat', compact('resultat'));
    }


    public function resultat()
    {
        

        return view('Backend.Examens.resultat.index');
    }

    public function submitQuestion(Request $request)
    {
       
        // Enregistrer la réponse de l'étudiant
        $userId = Auth::id();
        foreach ($request->input('questions') as $questionId => $choixId) 
        {
            $resultat = Resultat::firstOrCreate([
                'user_id' => $userId,
                'question_id' => $questionId,
            ]);
            $resultat->choix_id = $choixId;
            $resultat->save();
        }

        // Récupérer l'index de la question suivante
        $nextQuestionIndex = request()->query('question') + 1;

        return redirect()->route('commencer.examen', [
            'id' => $request->input('examen_id'),
            'question' => $nextQuestionIndex,
        ]);
    }





}
