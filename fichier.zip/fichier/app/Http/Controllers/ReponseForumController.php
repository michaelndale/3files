<?php

namespace App\Http\Controllers;

use App\Models\reponse_forum;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ReponseForumController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Vérifiez si l'utilisateur a un idfonction de 7
      /*  if (Auth::user()->idfonction == 7) {
            // Redirigez avec un message d'erreur
            return redirect()->back()->withErrors([
                'error' => "Vous n'avez pas l'habilité de répondre à la place d'un professeur.",
            ]);
        }  */

        // Valider les données reçues
        $request->validate([
            'forum_id' => 'required|exists:forums,id', // Vérifie que le forum existe
            'content' => 'required|string|max:5000', // Limite le contenu à 5000 caractères
        ]);

        // Créer une nouvelle réponse au forum
        $reponse_forum = new reponse_forum();
        $reponse_forum->forum_id = $request->forum_id;
        $reponse_forum->content = $request->content;
        $reponse_forum->user_id = Auth::id();
        $reponse_forum->save();

        // Rediriger vers le forum avec un message de confirmation
        return redirect()->back()
            ->with('success', 'Votre réponse a été ajoutée avec succès.');
    }


    /**
     * Display the specified resource.
     */
    public function show(reponse_forum $reponse_forum)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(reponse_forum $reponse_forum)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, reponse_forum $reponse_forum)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(reponse_forum $reponse_forum)
    {
        //
    }
}
