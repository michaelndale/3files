<?php

namespace App\Http\Controllers;

use App\Models\Etudiants;
use App\Models\Fonction;
use App\Models\Personnel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class Users extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
     $allUser = DB::table('users')
     ->join('personnels','users.id','personnels.user_id')
     ->join('fonctions', 'users.idfonction', 'fonctions.id')
     ->select('personnels.*', 'fonctions.titre as titreFonction', 'users.email', 'users.status','users.photo','users.id as idu')
     ->get();

     return view('Backend.Users.index',compact('allUser'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $fonction = Fonction::all();
      return view('Backend.Users.nouveau',compact('fonction'));  //
    }

    /**
     * Store a newly created resource in storage.
     */

   
     
     public function store(Request $request)
     {
         DB::beginTransaction();
     
         try {
             $user = new User();
             $user->prenom = $request->prenom;
             $user->email = $request->email;
             $user->idfonction = $request->fonction;
             $user->password = $request->password;
             
             // Génération du code matricule unique
             $codematricule = Personnel::all()->count();
             $codematricule = "INITADMIN" . str_pad($codematricule + 1, 3, "0", STR_PAD_LEFT);
             $user->code = $codematricule;
             
             $user->save();
             
             if($user){
                 $personnel = new Personnel();
                 $personnel->nomp = $request->nom;
                 $personnel->prenom = $request->prenom;
                 $personnel->sexe = $request->genre;
                 $personnel->tel = $request->tel;
                 $personnel->user_id = $user->id;
                 $personnel->save();
             }
             
             DB::commit();
             
             return redirect()->route('personnel')->with('success', 'Utilisateur créé avec succès');
         } catch (\Exception $e) {
             DB::rollBack();
             return redirect()->back()->with('error', 'Une erreur est survenue lors de la création de l\'utilisateur.');
         }
     }

  

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $user = DB::table('users')
        ->join('personnels','users.id','personnels.user_id')
        ->join('fonctions', 'users.idfonction', 'fonctions.id')
        ->select('personnels.*', 'fonctions.titre as titreFonction', 'users.email', 'users.status','users.photo','users.id as idu', 'users.code')   
        ->where('users.id', $id)
        ->first();

   
     return view('Backend.Users.voir',compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
       
        $user = DB::table('users')
        ->join('personnels','users.id','personnels.user_id')
        ->join('fonctions', 'users.idfonction', 'fonctions.id')
        ->select('personnels.*', 'fonctions.titre as titreFonction',  'users.email', 'users.status','users.photo','users.id as idu','users.idfonction as idfonction')   
        ->where('users.id', $id)
        ->first();
      
        $fonction = Fonction::all();
        return view('Backend.Users.modifier',compact('user','fonction'));
    }


    public function monprofileadmin(string $id)
    {
       
        $user = DB::table('users')
        ->join('personnels','users.id','personnels.user_id')
        ->join('fonctions', 'users.idfonction', 'fonctions.id')
        ->select('personnels.*', 'fonctions.titre as titreFonction',  'users.email', 'users.status','users.photo','users.id as idu','users.idfonction as idfonction')   
        ->where('users.id', $id)
        ->first();
      
        $fonction = Fonction::all();
        return view('Backend.Users.monprofile',compact('user','fonction'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        DB::beginTransaction();
    
        try {
            $user = User::findOrFail($id);
            $user->prenom = $request->prenom;
            $user->email = $request->email;
            $user->idfonction = $request->fonction;
            $user->status = $request->statut;
            $user->update();
    
            if($user){
                $personnel = Personnel::where('user_id', $id)->first();
                $personnel->nomp = $request->nom;
                $personnel->prenom = $request->prenom;
                $personnel->sexe = $request->genre;
                $personnel->tel = $request->tel;
                $personnel->update();
            }
    
            DB::commit();
    
            return redirect()->back()->with('success', 'Mise à jour de l\'utilisateur effectuée avec succès');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->with('error', 'Une erreur est survenue lors de la mise à jour de l\'utilisateur.');
        }
    }

    /*
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $user = User::findOrFail($id);
        $user->delete();
        return redirect()->route('personnel')->with('success','utilisateur suprimer avec succes'); //
    }


    public function verifyPassword(Request $request, $id)
    {
        $request->validate([
            'old_password' => 'required|string',
        ]);

        $user = User::findOrFail($id); // Vérifiez que l'utilisateur existe

        if (Hash::check($request->old_password, $user->password)) {
            return response()->json(['valid' => true]);
        } else {
            return response()->json(['valid' => false], 403);
        }
    }

    public function updatePassword(Request $request, $id)
    {
        // Validation des mots de passe
        $request->validate([
            'old_password' => 'required|string',
            'new_password' => 'required|string|min:8|confirmed',
        ]);

        $user = User::findOrFail($id); // Récupère l'utilisateur par ID

        // Vérification de l'ancien mot de passe
        if (!Hash::check($request->old_password, $user->password)) {
            return redirect()->back()->withErrors(['old_password' => 'L\'ancien mot de passe est incorrect.']);
        }

        // Mise à jour du mot de passe
        $user->password = Hash::make($request->new_password);
        $user->save();

        return redirect()->back()->with('success', 'Mot de passe mis à jour avec succès');
    }

    public function deleteAccount(Request $request, $id)
    {
        // Trouver l'utilisateur par ID
        $user = User::findOrFail($id);
    
        // Utiliser une transaction pour garantir l'intégrité des données
        DB::transaction(function () use ($user) {
            // Supprimer l'utilisateur de la base de données
            $user->delete();
    
            // Supprimer les informations associées dans la table etudiants
            // Note : La suppression de l'utilisateur doit être faite après
            // avoir récupéré les informations nécessaires à partir de l'objet $user.
            Etudiants::where('user_id', $user->id)->delete();
        });
    
        // Déconnexion de l'utilisateur
        Auth::logout(); // Déconnecte l'utilisateur
        $request->session()->invalidate(); // Invalide toutes les sessions
        $request->session()->regenerateToken(); // Régénère le token CSRF
    
        return redirect()->route('accueil')->with('success', 'Votre compte a été supprimé avec succès.');
    }
}
