<?php

namespace App\Http\Controllers;

use App\Models\Bibliotheque;
use App\Models\cours;
use App\Models\Etudiants;
use App\Models\Faculte;
use App\Models\User;

abstract class Controller
{
    
    public function index()
    {
     $User = User::join('etudiants', 'etudiants.user_id','users.id')
                             ->select('etudiants.*','users.*')->get();
     
     $utilisateursLimites = User::join('etudiants', 'etudiants.user_id','users.id')
                            ->select('etudiants.*','users.*')
                            ->orderBy('etudiants.created_at', 'desc')
                            ->limit(5)
                            ->get();

     $faculte = Faculte::all();
     $cours = cours::all();
     $bibliotheque= Bibliotheque::all();
     return view('Backend.Home.index',compact('User','faculte','cours', 'bibliotheque','utilisateursLimites'));
    }
}
