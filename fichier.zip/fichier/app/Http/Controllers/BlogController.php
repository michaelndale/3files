<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;




class BlogController extends Controller
{
    public function index()
    {
     $allBlog = Blog::join('personnels','blogs.user_id','personnels.user_id')
     ->select('blogs.*' , 'personnels.nomp as nom', 'personnelss.prenom as prenom')
     ->get();
     
     return view('Backend.Blogs.index',compact('allBlog'));
    }

    public function liste()
    {
        $allBlog = Blog::join('personnels','blogs.user_id','personnels.user_id')
        ->select('blogs.*' , 'personnels.nomp as nom', 'personnels.prenom as prenom')
        ->get();
        
     return view('Backend.Blogs.index',compact('allBlog'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
      return view('Backend.Blogs.nouveau');  //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validate input data
        $request->validate([
            'titre' => 'required|string|max:255',
            'courte' => 'required|string|max:500',
            'description' => 'required|string',
            'photo' => 'required|image|mimes:jpeg,png,jpg,gif,webp|max:4096', // Allowing up to 4MB and WebP format
        ]);
        
    
        try {
            // Handle the photo upload
            $image = $request->file('photo');
            $imageName = time().'.'.$image->extension();
    
            // Move the original image without resizing or compressing
            $image->move(public_path('images/blogs/'), $imageName);
    
            // Create a new blog instance and save it
            $blog = new Blog();
            $blog->titre = $request->titre;
            $blog->slug = Str::slug($request->titre, "-");
            $blog->courte = $request->courte;
            $blog->description = $request->description;
            $blog->photo = $imageName;
            $blog->user_id = Auth::id();
    
            $blog->save();
    
            // Redirect with a success message
            return redirect()->route('listes.blog')->with('success', 'Blog créé avec succès');
    
        } catch (Exception $e) {
            // Log the error message
            Log::error('Error creating blog: '.$e->getMessage());
    
            // Redirect back with an error message
            return redirect()->back()->with('error', 'Une erreur est survenue lors de la création du blog.');
        }
    }
    

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
     $blog = Blog::findOrFail($id);   //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $blog = Blog::findOrFail($id);
        return view('Backend.Blogs.modifier',compact('blog'));  //
    }

    public function update(Request $request, $id)
    {
        // Validate input data
        $request->validate([
            'titre' => 'required|string|max:255',
            'courte' => 'nullable|string|max:500',
            'description' => 'nullable|string',
            'photo' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp|max:4096', // Optional image update
        ]);

        try {
            // Find the blog post by ID
            $blog = Blog::findOrFail($id);

            // Update only the fields provided in the request
            $blog->titre = $request->titre;
            $blog->slug = Str::slug($request->titre, "-");
            $blog->courte = $request->courte ?? $blog->courte;
            $blog->description = $request->description ?? $blog->description;

            // Check if a new image is uploaded
            if ($request->hasFile('photo')) {
                // Delete the old image if it exists
                if ($blog->photo && file_exists(public_path('images/blogs/' . $blog->photo))) {
                    unlink(public_path('images/blogs/' . $blog->photo));
                }

                // Save the new image
                $image = $request->file('photo');
                $imageName = time() . '.' . $image->extension();
                $image->move(public_path('images/blogs/'), $imageName);
                $blog->photo = $imageName;
            } else {
                // Retain the old image if no new image is uploaded
                $blog->photo = $request->input('oldImage');
            }

            // Save the updated blog
            $blog->update();

            // Redirect with a success message
            return redirect()->back()->with('success', 'Blog mis à jour avec succès');

        } catch (Exception $e) {
            
            return redirect()->back()->with('error', 'Une erreur est survenue lors de la mise à jour du blog.');
        }
    }

    

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            // Récupérer le blog
            $blog = Blog::findOrFail($id);
    
            // Vérifier et supprimer le fichier photo associé
            $imagePath = public_path('images/blogs/' . $blog->photo);
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }
    
            // Supprimer l'enregistrement du blog
            $blog->delete();
    
            // Rediriger avec un message de succès
            return redirect()->back()->with('success', 'Blog supprimé avec succès');
        } catch (Exception $e) {
            // Enregistrer l'erreur
            Log::error('Erreur lors de la suppression du blog : ' . $e->getMessage());
    
            // Rediriger avec un message d'erreur
            return redirect()->back()->with('error', 'Une erreur est survenue lors de la suppression du blog.');
        }
    }
    
}
