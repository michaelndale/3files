<?php

namespace App\Http\Controllers;

use App\Models\annee;
use Illuminate\Database\Events\TransactionBeginning;
use Illuminate\Http\Request;

class AnneController extends Controller
{
    public function index()
    {
     $allAnnee = annee::all();
     return view('Backend.Annees.index',compact('allAnnee'));
    }
    
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
      return view('Backend.Annees.nouveau');  //
    }
    
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
       
        try {
            $update = Annee::where('statut', 'ACTIF')->first();
            if($update){
                // Mettre à jour le statut de l'année active en inactif
                $update->statut = 'INACTIF';
                $update->save();
                // Ensuite, procédez à l'insertion des détails fournis pour la nouvelle année
                $Annee = new Annee();
                $Annee->libelle =$request->libelle;
                $Annee->datedebut =$request->datedebut;
                $Annee->datefin =$request->datefin;
                $Annee->save();//
            }
            return redirect()->back()->with('success','Annee creer avec succes');
        } catch (\Throwable $th) {
            //throw $th;
        }
      
    
    }
    
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
     $Annee = Annee::find($id); 
     return view('Backend.Annees.voir',compact('Annee'));  //
    }
    
    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $Annee =Annee::find($id);  //
        return view('Backend.Annees.modifier',compact('Annee'));  //
    }
    
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
     $Annee = Annee::findOrFail($id);
     $Annee->libelle =$request->libelle;
     $Annee->datedebut =$request->datedebut;
     $Annee->datefin =$request->datefin;
     $Annee->Update();//
    return redirect()->route('annee')->with('success','annee modifier avec succes');//
    }
    
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $Annee = Annee::find($id);
        $Annee->delete();
        return redirect()->route('annee')->with('success','Annee suprimer avec succes'); //
    }
}
