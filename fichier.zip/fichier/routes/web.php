<?php

use App\Http\Controllers\Accueil;
use App\Http\Controllers\AnneController;
use App\Http\Controllers\Annees;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\BibliothequeController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\Clases;
use App\Http\Controllers\CoursController;
use App\Http\Controllers\EtudiantController;
use App\Http\Controllers\Examencontroller;
use App\Http\Controllers\FacturationController;
use App\Http\Controllers\Faculte;
use App\Http\Controllers\Fonction;
use App\Http\Controllers\ForumController;
use App\Http\Controllers\Home;
use App\Http\Controllers\InscriptionController;
use App\Http\Controllers\PayementController;
use App\Http\Controllers\ReponseForumController;
use App\Http\Controllers\Users;

use Illuminate\Support\Facades\Route;


Route::get('',[Accueil::class,'index'])->name('accueil');

Route::get('a-ppropos',[Accueil::class,'appropos'])->name('appropos');

Route::get('cours-public',[Accueil::class,'cours_pup'])->name('cours.public');

Route::get('bibliothec-public',[Accueil::class,'bibliot'])->name('bibliotheque.public');

Route::get('blog-public',[Accueil::class,'blogs'])->name('blog.public');
Route::get('blog/{id}/',[Accueil::class,'showblog'])->name('voir.blog.public');

Route::get('contact',[Accueil::class,'contacts'])->name('contact');
Route::post('/send-message', [Accueil::class, 'sendMessage']);








Route::get('seconnecter', function () {
    return view('Frontend.auth.seconnecter');
})->name('login');

Route::get('portail/etudiant', function () {
    return view('Frontend.etudiant.seconnecter');
})->name('portailetudiant');


Route::get('service/inscription',[InscriptionController::class,'index'])->name('inscription');
Route::post('saveetudiant', [EtudiantController::class, 'storePublic'])->name('save.etudiant');
Route::get('/getFaculteClasse', [EtudiantController::class, 'getClasses'])->name('getFaculteClasse');

Route::get('auth-recoverpw', function () {
    return view('Frontend.auth.passoublier');
})->name('auth-recoverpw');


// ROUTE DE CONNECTION
Route::get('authenticate',[AuthController::class,'authenticate'])->name('adminconnexion');

/*
Route::get('appropos', function () {
    return view('Frontend/appropos');
})->name('appropos');

Route::get('service', function () {
    return view('Frontend/service');
})->name('service'); */


//  LIEN PROTER 
Route::middleware(['auth'])->group(function () {

Route::get('deconnection',[AuthController::class,'logout'])->name('admindeconnexion');
Route::get('tableaudebord',[Home::class,'index'])->name('tableaudebord');

// DEBUT PERSONNE 
Route::get('personnel',[Users::class,'index'])->name('personnel');
Route::get('/personnel/nouveau',[Users::class,'create'])->name('nouveau.personnel');
Route::post('savePersonnel', [Users::class, 'store'])->name('save.personnel');
Route::get('/personnel/{id}/afficher', [Users::class, 'edit'])->name('afficher.personnel');
Route::get('/Personnel/{id}/profile', [Users::class, 'monprofileadmin'])->name('profile.personnel');
Route::get('/personnel/{id}/voir', [Users::class, 'show'])->name('voir.personnel');
Route::put('/{id}/updatePersonnel', [Users::class, 'update'])->name('update.personnel');
Route::delete('deletePersonnel/{id}', [Users::class, 'destroy'])->name('deletePersonnel');
// FIN PERSONNE

// DEBUT FONCTION 
Route::get('Outils/fonction',[Fonction::class,'index'])->name('fonction');
Route::get('Outils/fonction/nouvelle',[Fonction::class,'create'])->name('nouvelle.fonction');
Route::post('saveFonction', [Fonction::class, 'store'])->name('save.fonction');
Route::delete('deleteFonction/{id}', [Fonction::class, 'destroy'])->name('deletefonction');
// FIN FONCTION


    
//DEBUT FACULTE
Route::get('Outils/faculte',[Faculte::class,'index'])->name('faculte');
Route::post('saveFaculte', [Faculte::class, 'store'])->name('save.faculte');
Route::get('Outils/editfaculte/{id}',[Faculte::class,'index'])->name('edit.faculte');
Route::delete('deleteFaculte/{id}', [Faculte::class, 'destroy'])->name('deletefaculte');

        //DEBUT CLASSE
    Route::get('faculte/{id}/classes/',[Clases::class,'liste'])->name('classe');
    Route::get('faculte/{id}/classe/edit/',[Clases::class,'edit'])->name('edit.classe');
    Route::get('faculte/{id}/classe/voir',[Clases::class,'show'])->name('voir.classe');
    Route::post('saveClasse', [Clases::class, 'store'])->name('save.classe');
    Route::put('updateClasse/{id}', [Clases::class, 'update'])->name('update.classe');
    Route::delete('deleteClasse/{id}', [Clases::class, 'destroy'])->name('deleteclasse');
    // FIN CLASSE


    // AFFECTATION COURS DANS FACULTE ET CLASSE

    Route::get('faculte/classe/{id}/cour/',[Faculte::class,'liste_cours_classe'])->name('couus_classe');
    Route::post('save_couus_classe', [Faculte::class, 'store_cours_classe'])->name('save_couus_classe');


 // FIN FACULTE


    // AFFECTATION COURS
    Route::post('savefacultecours', [CoursController::class, 'storeaffectation'])->name('savefacultecours');
    Route::get('affectationcours/{id}',[CoursController::class,'listeaffectation'])->name('facultecours');
// FIN FACULTE

//DEBUT ANNEE
Route::get('Outils/annee',[AnneController::class,'index'])->name('annee');
Route::post('saveAnnee', [AnneController::class, 'store'])->name('save.annee');
Route::get('Outils/editannee/{id}',[AnneController::class,'index'])->name('edit.annee');
Route::delete('deleteAnnee/{id}', [AnneController::class, 'destroy'])->name('deleteannee');

Route::get('Outils/voirannee/{id}',[AnneController::class,'show'])->name('voir.annee');
Route::put('updateAnnee/{id}', [AnneController::class, 'update'])->name('update.annee');
// FIN ANNEE

// FACTURATION
Route::get('payement',[PayementController ::class,'index'])->name('payement');

Route::get('payement/facturations', [FacturationController::class, 'index'])->name('facturations.index');
Route::get('payement/facturations/{annee_id}',[FacturationController::class,'FacturationsForAnnee'])->name('facturations');
Route::post('saveFacturation', [FacturationController::class, 'Store'])->name('save.Facturation');
Route::delete('/facturation/{facturation_id}', [FacturationController::class, 'deleteFacturation'])->name('delete.facturation');
Route::post('/facturation/update', [FacturationController::class, 'updateFacturation'])->name('update.facturation');


//DEBUT COURS
Route::get('cours',[CoursController::class,'listecours'])->name('listes.cours');
Route::get('/cours/{id}/edit',[CoursController::class,'edit'])->name('edit.cours');
Route::get('/cours/{id}/voir',[CoursController::class,'show'])->name('voir.cours');
Route::post('savecours', [CoursController::class, 'store'])->name('save.cours');
Route::put('updatecours/{id}', [CoursController::class, 'update'])->name('update.cours');
Route::delete('deletecours/{id}', [CoursController::class, 'destroy'])->name('deleteCours');

    // Modules cours
    Route::post('saveModule', [CoursController::class, 'storeModule'])->name('saveModule.cours');
    Route::get('/cours/{id}/modules/',[CoursController::class,'listemodules'])->name('modules.cours');
    Route::delete('deleteModule/{id}', [CoursController::class, 'destroyModule'])->name('deleteModule');

    // DISPASSER COURS
    Route::get('/cours/dispensations',[CoursController::class,'listecoursdispenser'])->name('dispenser.cours');
    Route::get('/cours/dispensations/{id}/edit',[CoursController::class,'editdispense'])->name('edit.dispenser');
    Route::post('saveDispenser', [CoursController::class, 'storeDispenser'])->name('save.dispenser');
    Route::put('updateDispenser/{id}', [CoursController::class, 'updatedispense'])->name('update.dispenser');
    Route::delete('deleteDispenser/{id}', [CoursController::class, 'destroyDispenser'])->name('deleteDispenser');

    // MENU PROFFESSEUR
    Route::get('/cours/attribues',[CoursController::class,'mescours'])->name('mes.cours');
    Route::get('cours/{id}/mesmodules/',[CoursController::class,'meslistemodules'])->name('mes.modules.cours');

// FIN COURS

//DEBUT ETUDIANT
Route::get('etudiant',[EtudiantController::class,'listeetudiant'])->name('listes.etudiant');
Route::get('/etudiant/{id}/edit',[EtudiantController::class,'edit'])->name('edit.etudiant');
Route::get('/etudiant/{id}/voir',[EtudiantController::class,'show'])->name('voir.etudiant');
Route::post('saveEtudiantBack', [EtudiantController::class, 'storePrive'])->name('saveetudiantinterne');
Route::put('updateetudiant/{id}', [EtudiantController::class, 'update'])->name('update.etudiant');
Route::delete('deleteetudiant/{id}', [EtudiantController::class, 'destroy'])->name('deleteEtudiant');
// FIN ETUDIANT

//DEBUT blog
Route::get('listeblogs',[BlogController::class,'liste'])->name('listes.blog');
Route::get('nouveaublog', [BlogController::class, 'create'])->name('nouveau.blog');
Route::post('saveblog', [BlogController::class, 'store'])->name('save.blog');
Route::get('blog/{id}/edit',[BlogController::class,'edit'])->name('edit.blog');
Route::get('blog/{id}/voir',[BlogController::class,'show'])->name('voir.blog');
Route::put('updateblog/{id}', [BlogController::class, 'update'])->name('update.blog');
Route::delete('deleteblog/{id}', [BlogController::class, 'destroy'])->name('deleteblog');
// FIN blog

//DEBUT bibliotheque
Route::get('bibliotheque/liste',[BibliothequeController::class,'liste'])->name('listes.bibliotheque');
Route::get('service/bibliotheque/nouveau', [BibliothequeController::class, 'create'])->name('nouveaubibliotheque');
Route::post('savebibliotheque', [BibliothequeController::class, 'store'])->name('save.bibliotheque');
Route::post('savebibliothequeprive', [BibliothequeController::class, 'storeprive'])->name('save.bibliotheque.prive');
Route::get('bibliotheque/{id}/edit/',[BibliothequeController::class,'edit'])->name('edit.bibliotheque');
Route::get('bibliotheque/{id}/voir/',[BibliothequeController::class,'show'])->name('voir.bibliotheque');
Route::put('updatebibliotheque/{id}', [BibliothequeController::class, 'update'])->name('update.bibliotheque');
Route::delete('deletebibliotheque/{id}', [BibliothequeController::class, 'destroy'])->name('deletebibliotheque');
Route::put('publierbiblio/{id}', [BibliothequeController::class, 'publierbiblio'])->name('publierbiblio');
Route::put('bloquerbiblio/{id}', [BibliothequeController::class, 'bloquerbiblio'])->name('bloquerbiblio');
Route::delete('deletebibliotheque/{id}', [BibliothequeController::class, 'destroy'])->name('deleteBibliotheque');
// FIN blog

// ETUDIANT ROUTE
Route::get('bienvenue',[Home::class,'bienvenue'])->name('bienvenue');
Route::get('profile',[Home::class,'profile'])->name('profile');
Route::put('updateetudiantpublic/{id}', [EtudiantController::class, 'updatePublic'])->name('update.etudiant.public');
Route::post('/verify-password/{id}', [Users::class, 'verifyPassword'])->name('verify.password');
Route::post('/update-password/{id}', [Users::class, 'updatePassword'])->name('save.password');
Route::post('/delete-account/{id}', [Users::class, 'deleteAccount'])->name('delete.account');



Route::get('cours/documentation',[Home::class,'cours'])->name('mescours');
Route::get('cours/{slug}',[Home::class, 'contenucours'])->name('contenu.cours');

Route::get('service/payement',[Home::class,'payement'])->name('mespayements');
// Route pour enregistrer un paiement
Route::post('/payment/store', [PayementController::class, 'store'])->name('payment.store');
Route::post('/check-reference', [PayementController::class, 'checkReference'])->name('check.reference');
Route::post('/check-payment', [PayementController::class, 'checkPayment'])->name('check.payment');


Route::get('mesexamens',[Home::class,'examens'])->name('mesexamens');
Route::get('/examen/{id}/commencer', [ExamenController::class, 'commencerExamen'])->name('commencer.examen');
Route::post('/examen/submit', [ExamenController::class, 'submitQuestion'])->name('examen.repondre');



Route::get('forum',[ForumController::class,'index'])->name('forum');
Route::get('forum/nouveau',[ForumController::class,'create'])->name('forum.nouveau');
Route::post('forum/saveforum',[ForumController::class,'store'])->name('save.forum');
Route::get('forum/{forum}', [ForumController::class, 'show'])->name('forum.show');
Route::post('forum/reponses', [ReponseForumController::class, 'store'])->name('save.reponse');



Route::get('bliotheques/documentation',[Home::class,'bibliotheque'])->name('mesbibliotheques');
Route::get('bibliotheque/nouveau',[Home::class,'nouveaubibliothequeetudiant'])->name('nouveaubibliothequeetudiant');
Route::post('savedocumentetudiant/{id}', [EtudiantController::class, 'storeDocumentEtudiant'])->name('save.document.etudiant');
Route::post('saveimageetudiant/{id}', [EtudiantController::class, 'storeImangeEtudiant'])->name('save.image.etudiant');

// DEBUT EXAMEN 
Route::get('examen/liste',[Examencontroller::class,'index'])->name('listes.examen');
Route::get('examen/nouveauexamen',[Examencontroller::class,'creerexamen'])->name('nouveau.examen');
Route::post('storeexamen',[Examencontroller::class,'storeexamen'])->name('save.examen');
Route::post('/delete-examen/{id}', [Examencontroller::class, 'deleteexamen'])->name('deleteExamen');

Route::get('examen/{id}/listequestion',[Examencontroller::class,'listequestion'])->name('listes.question');
Route::post('storequestion/{id}',[Examencontroller::class,'storequestions'])->name('save.question');
Route::post('/delete-question/{id}', [Examencontroller::class, 'deletQuestion'])->name('deleteQuestion');

Route::get('examen/resultat',[Examencontroller::class,'resultat'])->name('listes.resultat');

});






